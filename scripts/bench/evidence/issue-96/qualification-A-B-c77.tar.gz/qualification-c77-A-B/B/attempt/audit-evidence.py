"""Read-only multi-pair audit. Imports no application, runner or tested parser."""
import copy
import hashlib
import json
import math
import statistics
import time
from pathlib import Path

FIELDS = {'rchar','wchar','syscr','syscw','read_bytes','write_bytes','cancelled_write_bytes'}
PARENT = '610c931b7b22920cce59cf03e49c0de15ebaf2a2'
COUNTS = [1,100]
SAMPLES = 7
SIZE = 10240
OWNER = '__html-inbox/ownership.json'
MANIFEST = 'i/AAAAAAAAAAAAAAAAAAAAAA/snapshot-manifest.json'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def snapshot(raw):
    values = {}
    for line in raw.splitlines():
        pair = line.split(':')
        assert len(pair)==2 and pair[0] in FIELDS and pair[0] not in values
        digits = pair[1].strip()
        assert digits and all('0'<=c<='9' for c in digits)
        values[pair[0]] = int(digits)
    assert set(values)==FIELDS
    return values

def plan():
    result = []
    def add(kind,label,count,role=None,sample=None,fixture=None):
        result.append(dict(kind=kind,label=label,count=count,role=role,sample=sample,fixture=fixture))
    def control(count,fixture):
        for role in ['baseline','candidate']:
            add('api',f'behavior/{fixture}/{role}/api-export',count,role,fixture=fixture)
            add('control-batch',f'behavior/{fixture}/{role}/batch',count,role,fixture=fixture)
    for count in COUNTS:
        add('seed',f'setup/managed-read/{count}',count,fixture=f'owned-{count}')
        control(count,f'owned-{count}')
        if count==COUNTS[0]:
            add('seed','setup/managed-read/mixed',2,fixture='mixed-origins-terminal-suppressed')
            control(2,'mixed-origins-terminal-suppressed')
        for sample in range(SAMPLES):
            for role in (['baseline','candidate'] if sample%2==0 else ['candidate','baseline']):
                add('cli',f'managed-read/cli-export/{role}/{count}',count,role,sample,f'owned-{count}')
                add('batch',f'managed-read/batch/{role}/{count}',count,role,sample,f'owned-{count}')
        for role in ['baseline','candidate']:
            for op in ['cli-export','batch']:
                add('io-cli' if op=='cli-export' else 'io-batch',f'count-probe/{op}/{role}/{count}',count,role,fixture=f'owned-{count}')
    return result

def spread(values):
    values = list(values)
    assert values and all(isinstance(v,(int,float)) and math.isfinite(v) for v in values)
    quartiles = statistics.quantiles(values,n=4,method='inclusive') if len(values)>1 else [values[0]]*3
    return dict(raw=values,min=min(values),median=statistics.median(values),max=max(values),
                range=max(values)-min(values),q1=quartiles[0],q3=quartiles[2],iqr=quartiles[2]-quartiles[0])

def audit_runtime(runtime,input_root,audit_root,source_pin,absolute_deadline):
    root = Path(input_root)
    def checkpoint(phase, **identity):
        if time.monotonic()>=absolute_deadline:
            raise TimeoutError('Shared application/audit deadline exhausted')
        (Path(audit_root)/(runtime+'-audit-progress.json')).write_text(json.dumps(dict(runtime=runtime,source_pin=source_pin,phase=phase,**identity),indent=2)+'\n')
    checkpoint('starting')
    output = root/(runtime+'-paired')
    rows = [json.loads(s) for s in (output/'samples.jsonl').read_text().splitlines()]
    expected = plan()
    assert len(rows)==len(expected)
    env = json.loads((output/'environment.json').read_text())
    assert env['counts']==COUNTS and env['sizes']==[SIZE] and env['samples']==SAMPLES
    assert env['expected_baseline_commit']==env['compared_builds']['baseline']['commit']==PARENT
    assert env['compared_builds']['candidate']['commit']==source_pin and env['dirty']==''
    behavior = [json.loads(s) for s in (output/'behavior.jsonl').read_text().splitlines()]
    documents = {}
    for value in behavior:
        assert value['label'] not in documents
        documents[value['label']] = value['documents']
    assert set(documents)=={f'owned-{count}' for count in COUNTS}|{'mixed-origins-terminal-suppressed'}
    for count in COUNTS:
        docs = documents[f'owned-{count}']
        assert len(docs)==count and all(d['bytes']==SIZE and not d['metadata'].get('origin') for d in docs)
        assert len({d['sha256'] for d in docs})==count
    assert len(documents['mixed-origins-terminal-suppressed'])==2
    assert sum(bool(d['metadata'].get('origin')) for d in documents['mixed-origins-terminal-suppressed'])==1

    executable='/home/agent/.local/share/fnm/node-versions/'+('v20.20.2' if runtime=='node20' else 'v24.19.0')+'/installation/bin/node'
    assert env['node']==('v20.20.2' if runtime=='node20' else 'v24.19.0')
    assert env['invocation'][env['invocation'].index('--node')+1]==executable
    fixture_paths={}
    indexed = {}
    exports = {}
    export_keys = {}
    groups = {}
    for index,(row,desc) in enumerate(zip(rows,expected)):
        checkpoint('row',row_index=index,descriptor=desc)
        assert row['label']==desc['label'] and row['exit_code']==0 and row['stderr']==''
        assert all(isinstance(row[k],(int,float)) and math.isfinite(row[k]) and row[k]>=0
                   for k in ['wall_ms','cpu_ms','peak_rss_kib','input_blocks','output_blocks'])
        key = (desc['kind'],desc['fixture'],desc['count'],desc['sample'],desc['role'])
        assert key not in indexed
        value = json.loads(row['stdout'])
        assert row['command'][0]==executable
        if desc['kind'] in ['cli','io-cli']:
            assert row['command'][1]==str(Path(env['compared_builds'][desc['role']]['repo'])/'packages/cli/bundle/index.js')
            assert row['command'][2:4]==['export','--json']
            assert row['command'][row['command'].index('--out')+1]==value['outputDir']
            assert row['command'][row['command'].index('--home')+1]==str(Path(fixture_paths[desc['fixture']])/'library')
        else:
            assert row['command'][1]==str(Path(env['compared_builds']['candidate']['repo'])/'scripts/bench/managed-read.cjs')
            mode='seed' if desc['kind']=='seed' else ('api-export' if desc['kind']=='api' else 'batch')
            role=desc['role'] or 'baseline'
            assert row['command'][2]==mode and row['command'][3]==str(Path(env['compared_builds'][role]['repo'])/'packages/cli/dist')
            if desc['kind']=='seed':
                assert desc['fixture'] not in fixture_paths
                fixture_paths[desc['fixture']]=row['command'][4]
            else:
                assert row['command'][4]==fixture_paths[desc['fixture']] and row['command'][5]==desc['role']
            if desc['kind']=='api':assert row['command'][6]==value['outputDir']
        indexed[key] = (index,row,value)
        groups.setdefault(row['label'],[]).append(row['wall_ms'])
        for line in row['stdout'].splitlines():
            try:
                nested=json.loads(line)
                if isinstance(nested,dict) and 'wall_ms' in nested:
                    groups.setdefault('operation/'+row['label'],[]).append(nested['wall_ms'])
            except ValueError:
                pass
        if desc['kind'].startswith('io-'):
            probe_env=row['explicit_probe_environment']
            assert set(probe_env)=={'NODE_OPTIONS','HTML_INBOX_BENCH_HOME','HTML_INBOX_BENCH_IO'}
            assert probe_env['NODE_OPTIONS']=='--require='+str(Path(env['compared_builds']['candidate']['repo'])/'scripts/bench/managed-read-io.cjs')
            assert probe_env['HTML_INBOX_BENCH_HOME']==str(Path(fixture_paths[desc['fixture']])/'library')
            op='cli-export' if desc['kind']=='io-cli' else 'batch'
            assert probe_env['HTML_INBOX_BENCH_IO']==str(output/f"io-{desc['count']}-{desc['role']}-{op}.json")
        else:
            assert not row.get('explicit_probe_environment'), 'Instrumentation in primary/control sample'
        if desc['kind']=='seed':
            at=row['command'].index('seed')
            assert int(row['command'][at+3])==desc['count'] and int(row['command'][at+4])==SIZE
            assert value['visible']==len(documents[desc['fixture']])
        if desc['kind'] in ['batch','control-batch','io-batch']:
            assert value['documents']==documents[desc['fixture']]
            assert value['usesView']==(desc['role']=='candidate')
        if desc['kind'] in ['api','cli','io-cli']:
            identity=value['outputDir']
            assert identity not in exports
            if desc['kind']=='cli':
                assert Path(identity).name==f"cli-{desc['count']}-{desc['sample']}-{desc['role']}"
            elif desc['kind']=='io-cli':
                assert Path(identity).name==f"io-export-{desc['count']}-{desc['role']}"
            else:
                assert Path(identity).name==f"{desc['fixture']}-{desc['role']}-api"
            exports[identity] = dict(row_index=index,descriptor=desc,result=value)
            export_keys[key] = identity

    summary=json.loads((output/'summary.json').read_text())
    assert summary['success'] is True
    independent_groups={label:dict(n=len(values),min_ms=min(values),median_ms=statistics.median(values),max_ms=max(values)) for label,values in groups.items()}
    assert summary['groups']==independent_groups
    inventory={}
    for filename in sorted((output/'outputs').rglob('snapshot-manifest.json')):
        checkpoint('export',manifest_path=str(filename))
        tree=filename.parents[2]
        matches=[identity for identity in exports if Path(identity).name==tree.name]
        assert len(matches)==1
        item=exports[matches[0]]
        assert 'tree' not in item
        manifest=json.loads(filename.read_text())
        assert manifest==item['result']['manifest']
        owner=json.loads((tree/OWNER).read_text())
        assert owner=={'schemaVersion':1,'ownerId':item['result']['ownerId']}
        files={}
        for file in sorted(tree.rglob('*')):
            assert not file.is_symlink()
            if file.is_file():
                data=file.read_bytes();name=str(file.relative_to(tree))
                files[name]=dict(sha256=sha(data),size=len(data))
                inventory[str(file.relative_to(output))]=files[name]
        assert set(files)=={entry['path'] for entry in manifest['files']}|{MANIFEST}
        assert [f['path'] for f in manifest['files']]==sorted({f['path'] for f in manifest['files']})
        digest=hashlib.sha256()
        for entry in manifest['files']:
            assert not Path(entry['path']).is_absolute() and '..' not in Path(entry['path']).parts
            assert files[entry['path']]==dict(sha256=entry['sha256'],size=entry['size'])
            for component in [entry['path'],entry['sha256'],str(entry['size'])]:digest.update(component.encode()+b'\0')
        assert digest.hexdigest()==manifest['snapshotHash']
        owned=[d for d in documents[item['descriptor']['fixture']] if not d['metadata'].get('origin')]
        assert manifest['documentCount']==len(owned)
        bodies={f"i/AAAAAAAAAAAAAAAAAAAAAA/documents/{d['metadata']['id']}/content/index.html":dict(sha256=d['sha256'],size=d['bytes']) for d in owned}
        assert {name:info for name,info in files.items() if name.endswith('/content/index.html')}==bodies
        item.update(tree=tree,files=files,manifest=manifest)
    assert len(exports)==sum(d['kind'] in ['api','cli','io-cli'] for d in expected)
    assert all('tree' in item for item in exports.values())
    assert set(inventory)=={str(p.relative_to(output)) for p in (output/'outputs').rglob('*') if p.is_file()}
    comparisons=[]
    for identity,first in exports.items():
        desc=first['descriptor']
        if desc['role']!='baseline':continue
        key=(desc['kind'],desc['fixture'],desc['count'],desc['sample'],'candidate')
        second=exports[export_keys[key]]
        assert set(first['files'])==set(second['files'])
        exact=desc['kind']=='api';differences=[]
        for name in first['files']:
            a=(first['tree']/name).read_bytes();b=(second['tree']/name).read_bytes()
            if not exact and name in [OWNER,MANIFEST]:
                if a!=b:differences.append(name)
            else:assert a==b,(desc,name)
        if exact:
            assert first['result']['ownerId']==second['result']['ownerId']=='11111111-1111-4111-8111-111111111111'
            assert first['manifest']['generatedAt']==second['manifest']['generatedAt']=='2026-11-07T00:00:00.000Z'
        if not exact:
            a=copy.deepcopy(first['manifest']);b=copy.deepcopy(second['manifest'])
            for m in [a,b]:
                m.pop('generatedAt');m.pop('snapshotHash')
                for f in m['files']:
                    if f['path']==OWNER:f['sha256']='<verified-owner-hash>'
            assert a==b,'Manifest difference beyond specified nonce/derived fields'
        comparisons.append(dict(count=desc['count'],fixture=desc['fixture'],sample=desc['sample'],kind=desc['kind'],
            baseline_row=first['row_index'],candidate_row=second['row_index'],baseline_output=identity,
            candidate_output=second['result']['outputDir'],exact_all_bytes=exact,differing_nonce_files=differences,
            baseline_owner=first['result']['ownerId'],candidate_owner=second['result']['ownerId'],
            baseline_generated_at=first['manifest']['generatedAt'],candidate_generated_at=second['manifest']['generatedAt']))

    stored_pairs=[json.loads(s) for s in (output/'pairs.jsonl').read_text().splitlines()]
    assert len(stored_pairs)==len(COUNTS)*SAMPLES
    pairs={}
    for pair in stored_pairs:
        checkpoint('pair',count=pair['count'],sample=pair['sample'])
        count=pair['count'];sample=pair['sample'];key=(count,sample)
        assert count in COUNTS and 0<=sample<SAMPLES and key not in pairs
        assert pair['order']==(['baseline','candidate'] if sample%2==0 else ['candidate','baseline'])
        metrics={}
        for metric,kind,field,operation in [
            ('cli_export_process_ms','cli','wall_ms',False),('cli_export_process_cpu_ms','cli','cpu_ms',False),
            ('cli_export_process_peak_rss_kib','cli','peak_rss_kib',False),('cli_export_input_blocks','cli','input_blocks',False),
            ('cli_export_output_blocks','cli','output_blocks',False),('batch_process_ms','batch','wall_ms',False),
            ('batch_process_cpu_ms','batch','cpu_ms',False),('batch_process_peak_rss_kib','batch','peak_rss_kib',False),
            ('batch_operation_ms','batch','wall_ms',True),('batch_operation_cpu_ms','batch','cpu_ms',True),('batch_operation_rss_bytes','batch','rss_bytes',True)]:
            values=[]
            for role in ['baseline','candidate']:
                _,row,value=indexed[(kind,f'owned-{count}',count,sample,role)]
                values.append(value[field] if operation else row[field])
            baseline,candidate=values
            metrics[metric]=dict(baseline=baseline,candidate=candidate,delta=candidate-baseline,
                                 percent=(candidate/baseline-1)*100 if baseline else None)
        assert pair['metrics']==metrics
        pairs[key]=metrics
    paired_summary=[json.loads(s) for s in (output/'paired-summary.jsonl').read_text().splitlines()]
    assert len(paired_summary)==len(COUNTS)
    statistics_by_count={}
    for count in COUNTS:
        metrics={}
        for name in pairs[(count,0)]:
            samples=[pairs[(count,s)][name] for s in range(SAMPLES)]
            percents=[p['percent'] for p in samples if p['percent'] is not None]
            metrics[name]=dict(baseline=spread(p['baseline'] for p in samples),candidate=spread(p['candidate'] for p in samples),
                               paired_delta=spread(p['delta'] for p in samples),paired_percent=spread(percents) if percents else None)
        emitted=next(p for p in paired_summary if p['count']==count)
        assert emitted['n']==SAMPLES
        assert emitted['metrics']=={name:dict(delta_min=v['paired_delta']['min'],delta_median=v['paired_delta']['median'],delta_max=v['paired_delta']['max'],
            percent_median=v['paired_percent']['median'] if v['paired_percent'] else None) for name,v in metrics.items()}
        statistics_by_count[str(count)]=metrics

    io=[];ledger_sizes={count:set() for count in COUNTS}
    for count in COUNTS:
        docs=documents[f'owned-{count}']
        for role in ['baseline','candidate']:
            for op in ['cli-export','batch']:
                checkpoint('io',count=count,role=role,operation=op)
                file=output/f'io-{count}-{role}-{op}.json';profile=json.loads(file.read_text());raw=profile['proc_io']
                before=snapshot(raw['raw_before']);after=snapshot(raw['raw_after']);delta={f:after[f]-before[f] for f in FIELDS}
                assert before==raw['before'] and after==raw['after'] and delta==raw['delta']==profile['io'] and all(v>=0 for v in delta.values())
                native=profile['counts'];reads=count+(2 if op=='cli-export' else 1)
                assert profile['exitCode']==0 and native['ledgerOpens']==reads and native['bodyOpens']==len(docs)
                assert native['bodyBytes']==sum(d['bytes'] for d in docs) and native['checkedLedgerBytes']>0 and native['checkedLedgerBytes']%reads==0
                ledger_sizes[count].add(native['checkedLedgerBytes']//reads)
                assert delta['rchar']>=native['checkedLedgerBytes']+native['bodyBytes'] and delta['syscr']>=reads+len(docs)
                io.append(dict(count=count,role=role,operation=op,raw_before=raw['raw_before'],raw_after=raw['raw_after'],before=before,after=after,delta=delta,native=native))
    assert len(list(output.glob('io-*.json')))==len(COUNTS)*4 and all(len(v)==1 for v in ledger_sizes.values())
    assert json.loads((output/'cleanup.json').read_text())=={'fixture_root_removed':True,'children_reaped':True}
    assert not Path(env['fixture_root']).exists()
    result=dict(runtime=runtime,source_pin=source_pin,parent=PARENT,rows=len(rows),row_identities=[dict(row_index=n,**d) for n,d in enumerate(expected)],
        export_trees=len(exports),file_inventory=inventory,paired_outputs=comparisons,paired_raw_metrics=[dict(count=c,sample=s,metrics=v) for (c,s),v in pairs.items()],
        metrics=statistics_by_count,summary_recomputed_from_every_raw_row=independent_groups,io=io,
        ledger_size_derived_consistency_only={str(c):list(v) for c,v in ledger_sizes.items()},independently_retained_stat=False,
        runtime_stat_check='Source-pinned unchanged harness checked live ledger.stat size for each count/profile; no retained/recovered ledger.',
        pids=[row['pid'] for row in rows],groups=[row['process_group'] for row in rows],fixture_root=env['fixture_root'],
        limits='Seven pairs per count/runtime. No pooling/p95/cache-cold/early gain stopping/cross-runtime normalization. Raw timing is not an automatic benefit verdict.')
    (Path(audit_root)/(runtime+'-independent-audit.json')).write_text(json.dumps(result,indent=2)+'\n')
    checkpoint('complete')
    return result
