import ctypes
import argparse
import re
import stat
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
NODE24 = Path('/home/agent/.local/share/fnm/node-versions/v24.19.0/installation/bin/node')
NODE20 = Path('/home/agent/.local/share/fnm/node-versions/v20.20.2/installation/bin/node')
PNPM = NODE24.parent.parent / 'lib/node_modules/corepack/dist/pnpm.js'
parser = argparse.ArgumentParser()
parser.add_argument('--expected-head', required=True)
parser.add_argument('--grant', required=True)
options = parser.parse_args()
if not re.fullmatch(r'[0-9a-fA-F]{40}', options.expected_head):
    parser.error('--expected-head requires a full40-hex immutable pin')
EXPECTED = options.expected_head.lower()
BINDING_SHA256 = '92f5c423b67fa4ed0f737dbb896eb67013490c7f2a25740658fd91e5c94c219c'
binding_bytes = (ROOT/'binding.json').read_bytes()
assert hashlib.sha256(binding_bytes).hexdigest() == BINDING_SHA256
BINDING = json.loads(binding_bytes)
assert EXPECTED == BINDING['head'] and str(ROOT) == BINDING['attempt_root'], 'Prepared head/path binding differs'
assert os.environ['PATH'] == BINDING['launch_path'], 'Prepared launch PATH differs'
LEGACY_BYTES = Path(BINDING['baseline_build_receipt']['path']).read_bytes()
assert hashlib.sha256(LEGACY_BYTES).hexdigest() == BINDING['baseline_build_receipt']['sha256']
LEGACY = json.loads(LEGACY_BYTES)
SMOKE_PRIOR = REPO/'artifacts/issue-96/actual-parent-b249-caf2d6f-attempt1'
SMOKE_SHA256 = '6f63d5888f3e7771a185dec1e9d08620c9cc3328a111908db16273d9b8653866'
SMOKE = json.loads((SMOKE_PRIOR/'receipt.json').read_text())
BASE = Path('/home/agent/.t3/worktrees/html-inbox/perf-89-bench')
PARENT = '610c931b7b22920cce59cf03e49c0de15ebaf2a2'
APP_BUDGET = 900
CLEANUP_ALLOWANCE = 120
commands = []
app_started = None
app_deadline = None
hard_deadline = None
cleanup_used = 0.0
receipt = {'head': EXPECTED, 'base': PARENT, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'application_budget_seconds': APP_BUDGET, 'separate_cleanup_allowance_seconds': CLEANUP_ALLOWANCE, 'commands': commands, 'grant': options.grant}
assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0

def save():
    receipt['cleanup_used_seconds'] = cleanup_used
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def tracked(repo=REPO):
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0')
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in names if name and (repo / name).is_file()}

def compiled(repo=REPO):
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((repo / 'packages/cli/dist').rglob('*.js'))}

def own_children():
    filename = Path(f'/proc/self/task/{os.getpid()}/children')
    return [int(value) for value in filename.read_text().split()]

def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False

def drain_group(record):
    global cleanup_used
    started = time.monotonic()
    deadline = min(hard_deadline, started + max(0, CLEANUP_ALLOWANCE - cleanup_used))
    record['cleanup_absolute_deadline_monotonic'] = deadline
    reaped = []
    actions = []
    for child_pid in own_children():
        try:
            os.kill(child_pid, signal.SIGTERM)
            actions.append({'pid': child_pid, 'signal': 'SIGTERM'})
        except ProcessLookupError:
            pass
    if group_exists(record['pgid']):
        os.killpg(record['pgid'], signal.SIGTERM)
        actions.append({'pgid': record['pgid'], 'signal': 'SIGTERM'})
    while True:
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if pid == 0:
                break
            reaped.append({'pid': pid, 'status': status})
        children = own_children()
        live_group = group_exists(record['pgid'])
        if not children and not live_group:
            break
        if time.monotonic() >= deadline:
            raise RuntimeError('Cleanup allowance exhausted; preserve fixtures')
        if time.monotonic() - started >= 1:
            if live_group:
                os.killpg(record['pgid'], signal.SIGKILL)
            for pid in children:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        time.sleep(min(0.01, max(0, deadline-time.monotonic())))
    cleanup_used += time.monotonic() - started
    record['cleanup'] = {'group_absent': True, 'children_remaining': [], 'adopted_reaped': reaped, 'signals': actions, 'seconds': time.monotonic() - started}

def observe_tree(record):
    found = set([record['pid'], *own_children()])
    table = {}
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().split(') ', 1)[1].split()
            table[int(proc.name)] = dict(ppid=int(fields[1]), pgid=int(fields[2]), start=fields[19], state=fields[0])
        except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, IndexError):
            pass
    previous = None
    while previous != len(found):
        previous = len(found)
        found.update(pid for pid, info in table.items() if info['ppid'] in found)
    for pid in found:
        if pid in table:
            record.setdefault('observed_processes', {})[str(pid)] = table[pid]



def file_map(directory, repo=REPO):
    return {str(p.relative_to(repo)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(directory.rglob('*')) if p.is_file()}

def aggregate(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def directory_metadata(directory):
    return [{'path': str(p.relative_to(directory)), 'mode': p.lstat().st_mode, 'uid': p.lstat().st_uid,
             'size': p.lstat().st_size} for p in sorted(directory.rglob('*'))]


def postflight(record, owned, home, evidence):
    groups = {record['pgid'], *(info['pgid'] for info in record.get('observed_processes', {}).values())}
    record['observed_groups_after_drain'] = {str(group): group_exists(group) for group in groups}
    assert not any(record['observed_groups_after_drain'].values()), 'Observed owned group remains; preserve roots'
    captures = [json.loads(line) for p in sorted(evidence.glob('teardown-*.jsonl')) for line in p.read_text().splitlines()]
    for capture in captures:
        assert not capture.get('captureError') and not capture.get('cleanupError') and capture.get('removalCompleted'), capture
        assert not Path(capture['fixture']).exists(), 'Observed fixture remains'
        destination = evidence / f"fixture-{capture['pid']}-{capture['sequence']:02d}"
        for output in capture['outputs']:
            for item in output['files']:
                data = (destination/output['name']/item['path']).read_bytes()
                assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    record['output_capture'] = {'fixtures': len(captures), 'files': sum(len(output['files']) for c in captures for output in c['outputs']),
                                'shapes': {shape: sum(c['shape']==shape for c in captures) for shape in sorted({c['shape'] for c in captures})}}
    text = (ROOT/(record['label']+'.stdout.log')).read_text() + (ROOT/(record['label']+'.stderr.log')).read_text()
    import re
    diagnostic_roots = re.findall(r'"fixtureRoot":"([^"\n]+)"', text)
    record['diagnostic_fixture_roots'] = diagnostic_roots
    assert all(not Path(p).exists() for p in diagnostic_roots), 'Wrapper fixture root remains'
    record['remaining_tmp_entries'] = directory_metadata(owned)
    record['synthetic_home_entries'] = directory_metadata(home)
    if record['remaining_tmp_entries']:
        raise RuntimeError('Unexpected synthetic fixture remains after joined groups; preserve roots')
    owned.rmdir()
    shutil.rmtree(home)
    record['owned_tmpdir_absent'] = not owned.exists()
    record['isolated_home_absent'] = not home.exists()

def run(label, command, timeout, observed=False, cwd=REPO):
    global app_started, app_deadline, hard_deadline, cleanup_used
    if app_started is None:
        app_started = time.monotonic()
        app_deadline = app_started + APP_BUDGET
        hard_deadline = app_deadline + CLEANUP_ALLOWANCE
        receipt['application_absolute_deadline_monotonic'] = app_deadline
        receipt['hard_absolute_deadline_monotonic'] = hard_deadline
    remaining = app_deadline-time.monotonic()
    if remaining < timeout:
        raise RuntimeError('Insufficient remaining aggregate budget for full command scope: '+label)
    owned = ROOT/(label+'-tmp')
    home = ROOT/(label+'-home')
    evidence = ROOT/(label+'-outputs')
    for directory in [owned, home, evidence]: directory.mkdir(mode=0o700)
    (home/'catalog').mkdir(mode=0o700)
    env = {'PATH': str(NODE24.parent)+os.pathsep+os.environ['PATH'], 'LANG':'C.UTF-8', 'LC_ALL':'C.UTF-8', 'TZ':'UTC',
           'HOME':str(home), 'TMPDIR':str(owned), 'XDG_CONFIG_HOME':str(home/'config'), 'XDG_STATE_HOME':str(home/'state'),
           'XDG_DATA_HOME':str(home/'data'), 'HTML_INBOX_CATALOG_HOME':str(home/'catalog'),
           'COREPACK_HOME':'/home/agent/.cache/node/corepack', 'COREPACK_ENABLE_NETWORK':'0', 'COREPACK_ENABLE_AUTO_PIN':'0',
           'COREPACK_ENABLE_DOWNLOAD_PROMPT':'0'}
    if observed:
        env.update(HTML_INBOX_CONTRACT_EVIDENCE=str(evidence), NODE_OPTIONS='--require='+str(OBSERVER))
    record = {'label':label, 'command':list(map(str,command)), 'cwd':str(cwd), 'environment':env, 'limit_seconds':timeout,
              'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pre_spawn_catalog_empty':not any((home/'catalog').iterdir()),
              'observation_overhead':bool(observed), 'isolated_home':str(home), 'isolated_tmpdir':str(owned)}
    root_identity = owned.lstat()
    record['owned_tmpdir_identity'] = {'dev': root_identity.st_dev, 'ino': root_identity.st_ino, 'uid': root_identity.st_uid, 'mode': stat.S_IMODE(root_identity.st_mode)}
    assert stat.S_ISDIR(root_identity.st_mode) and root_identity.st_uid==os.getuid() and stat.S_IMODE(root_identity.st_mode)==0o700
    commands.append(record)
    print('START '+label, flush=True)
    started = time.monotonic()
    command_deadline = min(app_deadline,started+timeout)
    record['absolute_deadline_monotonic'] = command_deadline
    with (ROOT/(label+'.stdout.log')).open('wb') as stdout, (ROOT/(label+'.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        record.update(pid=child.pid,pgid=child.pid)
        record['proc_start'] = Path(f'/proc/{child.pid}/stat').read_text().split(') ',1)[1].split()[19]
        save()
        try:
            while child.poll() is None:
                observe_tree(record)
                if time.monotonic() >= command_deadline:
                    raise subprocess.TimeoutExpired(command,timeout)
                time.sleep(min(0.1,max(0,command_deadline-time.monotonic())))
            record['exit_code'] = child.wait()
            observe_tree(record)
        except subprocess.TimeoutExpired:
            record['timed_out'] = True
            os.killpg(child.pid,signal.SIGKILL)
            cleanup_started = time.monotonic()
            until = min(hard_deadline,cleanup_started+max(0,CLEANUP_ALLOWANCE-cleanup_used))
            try: record['exit_code'] = child.wait(timeout=max(0,until-time.monotonic()))
            finally: cleanup_used += time.monotonic()-cleanup_started
        record['application_elapsed_seconds'] = time.monotonic()-started
    drain_group(record)
    cleanup_started=time.monotonic()
    try:
        assert cleanup_started < hard_deadline and cleanup_used < CLEANUP_ALLOWANCE
        postflight(record,owned,home,evidence)
    finally: cleanup_used += time.monotonic()-cleanup_started
    record['source_unchanged'] = tracked()==receipt['source_before']
    record['git_head_unchanged'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==EXPECTED
    record['git_clean'] = not subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)
    if 'compiled_candidate_full' in receipt:
        record['compiled_unchanged'] = file_map(REPO/'packages/cli/dist')==receipt['compiled_candidate_full']
    record['base_source_unchanged'] = tracked(BASE)==receipt['base_source_before']
    record['base_head_unchanged'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()==PARENT
    record['base_clean'] = not subprocess.check_output(['git','status','--porcelain=v1'],cwd=BASE,text=True)
    if 'base_compiled_candidate_full' in receipt:
        record['base_compiled_unchanged'] = file_map(BASE/'packages/cli/dist',BASE)==receipt['base_compiled_candidate_full']
    if 'bundles_candidate' in receipt:
        record['bundles_unchanged'] = {str(repo):file_map(repo/'packages/cli/bundle',repo) for repo in [REPO,BASE]}==receipt['bundles_candidate']
    save()
    print('END '+label+' exit='+str(record['exit_code']),flush=True)
    assert record['exit_code']==0 and not record.get('timed_out') and record['source_unchanged'] and record['git_head_unchanged'] and record['git_clean'] and record.get('compiled_unchanged',True) and record['base_source_unchanged'] and record['base_head_unchanged'] and record['base_clean'] and record.get('base_compiled_unchanged',True) and record.get('bundles_unchanged',True), 'STOP first failed command/pin: '+label

OBSERVER=REPO/'artifacts/issue-96/correctness-fc858a5-attempt1/capture-outputs.cjs'
try:
    assert hashlib.sha256((SMOKE_PRIOR/'receipt.json').read_bytes()).hexdigest()==SMOKE_SHA256
    assert SMOKE['head']=='caf2d6f7b3376538539c8bff92ce7e962d7a5ed7' and SMOKE['base']=='b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad'
    assert LEGACY['base']==PARENT
    legacy_builds=[c for c in LEGACY['commands'] if c['label'] in ['base-build','base-bundle']]
    assert len(legacy_builds)==2 and all(c['exit_code']==0 for c in legacy_builds)
    assert hashlib.sha256((ROOT/'audit-evidence.py').read_bytes()).hexdigest()==BINDING['auditor_sha256']
    assert all(c['exit_code']==0 for c in SMOKE['commands']) and not SMOKE['not_run']
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==EXPECTED
    assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()==PARENT
    assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=BASE,text=True)
    receipt['source_before']=tracked()
    receipt['base_source_before']=tracked(BASE)
    reusable_names={name for name in set(SMOKE['source_after'])|set(receipt['source_before'])
                    if not name.startswith(('docs/','scripts/bench/evidence/')) or name.endswith(('.ts','.tsx','.mts','.cts'))}
    assert all(receipt['source_before'].get(n)==SMOKE['source_after'].get(n) for n in reusable_names)
    assert receipt['base_source_before']==BINDING['baseline_tracked']==LEGACY['base_source_after']
    receipt['reused_typecheck']=SMOKE['reused_typecheck']
    receipt['accepted_smoke_receipt_sha256']=SMOKE_SHA256
    receipt['accepted_baseline_build_receipt']=BINDING['baseline_build_receipt']
    receipt['baseline_artifact_reuse_limit']=BINDING['baseline_reuse_limit']
    receipt['compiled_candidate']=compiled()
    receipt['compiled_candidate_full']=file_map(REPO/'packages/cli/dist')
    receipt['base_compiled_candidate_full']=file_map(BASE/'packages/cli/dist',BASE)
    assert receipt['compiled_candidate_full']==SMOKE['compiled_after_full']
    assert receipt['base_compiled_candidate_full']==BINDING['baseline_generated_full']
    assert compiled(BASE)==BINDING['baseline_runtime_js']==LEGACY['base_compiled_candidate']
    receipt['bundles_candidate']={str(repo):file_map(repo/'packages/cli/bundle',repo) for repo in [REPO,BASE]}
    assert receipt['bundles_candidate']=={str(REPO):SMOKE['bundles_candidate'][str(REPO)],str(BASE):BINDING['baseline_bundle']}
    receipt['bundle_before_full']=receipt['bundles_candidate'][str(REPO)]
    receipt['runtime_hashes']={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in SMOKE['runtime_hashes_after']}
    assert receipt['runtime_hashes']==SMOKE['runtime_hashes_after']
    receipt['tool_files']={n:{'bytes':Path(n).stat().st_size,'sha256':hashlib.sha256(Path(n).read_bytes()).hexdigest()} for n in SMOKE['tool_files_after']}
    receipt['bundle_parent_tool_files']={n:{'bytes':Path(n).stat().st_size,'sha256':hashlib.sha256(Path(n).read_bytes()).hexdigest()} for n in SMOKE['bundle_parent_tool_files_after']}
    assert receipt['tool_files']==SMOKE['tool_files_after'] and receipt['bundle_parent_tool_files']==SMOKE['bundle_parent_tool_files_after']
    receipt['runner_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    receipt['auditor_sha256']=hashlib.sha256((ROOT/'audit-evidence.py').read_bytes()).hexdigest()
    receipt['scope']={'counts':[1,100],'size':10240,'samples':7,'child_timeout':30,'per_runtime_outer_limit':420,
        'expected_children_per_runtime':79,'expected_export_trees_per_runtime':38,'expected_profiles_per_runtime':8,
        'expected_pairs_per_count':7,'primary':'complete release-bundle CLI export process wall_ms',
        'supporting':'complete actual callback batch/process/operation CPU/RSS and separate I/O',
        'stopping':'first correctness/audit/provenance/cleanup failure or deadline only; never gain-based'}
    receipt['planned_checks']=['node20-paired','node24-paired']
    receipt['observation_limits']='Preselected outer100ms /proc-only sampling may miss short-lived descendants; runner records every child PID/group. No hot fixture-directory traversal. Monitoring overhead remains, identical for both roles; primary child metrics are not an uninstrumented-host claim. Primary samples do not preload I/O probes; probes separate. No cache-cold/p95/pooling/interruption guarantee or automatic benefit verdict.'
    save()
    run('node20-version',[NODE20,'--version'],15)
    assert (ROOT/'node20-version.stdout.log').read_text().strip()=='v20.20.2'
    run('node24-version',[NODE24,'--version'],15)
    assert (ROOT/'node24-version.stdout.log').read_text().strip()=='v24.19.0'
    import runpy
    audit=runpy.run_path(str(ROOT/'audit-evidence.py'))
    for runtime,node in [('node20',NODE20),('node24',NODE24)]:
        run(runtime+'-paired',['python3','scripts/bench/run.py','managed-read','--baseline-repo',BASE,
            '--expected-baseline-commit',PARENT,'--node',node,'--counts','1,100','--sizes','10240',
            '--samples','7','--timeout','30','--out',ROOT/(runtime+'-paired')],420)
        audit['audit_runtime'](runtime,ROOT,ROOT,EXPECTED,app_deadline)
        assert time.monotonic()<app_deadline, 'Application/audit deadline exhausted'
    assert receipt['tool_files']=={n:{'bytes':Path(n).stat().st_size,'sha256':hashlib.sha256(Path(n).read_bytes()).hexdigest()} for n in receipt['tool_files']}
    assert receipt['bundle_parent_tool_files']=={n:{'bytes':Path(n).stat().st_size,'sha256':hashlib.sha256(Path(n).read_bytes()).hexdigest()} for n in receipt['bundle_parent_tool_files']}
    assert receipt['runtime_hashes']=={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in receipt['runtime_hashes']}
    receipt['result']='combined610 paired matrix completed and independently audited; timing/benefit verdict requires separate review of all results'

except BaseException as error:
    if commands and 'pgid' in commands[-1] and 'cleanup' not in commands[-1]:
        record=commands[-1]
        try: os.killpg(record['pgid'],signal.SIGKILL)
        except ProcessLookupError: pass
        drain_group(record)
    receipt['result']='stopped'
    receipt['error']=repr(error)
    raise
finally:
    receipt['base_source_after']=tracked(BASE)
    receipt['base_compiled_after_full']=file_map(BASE/'packages/cli/dist',BASE)
    receipt['base_bundle_after_full']=file_map(BASE/'packages/cli/bundle',BASE)
    receipt['source_after']=tracked()
    receipt['compiled_after']=compiled()
    receipt['compiled_after_full']=file_map(REPO/'packages/cli/dist')
    receipt['bundle_after_full']=file_map(REPO/'packages/cli/bundle')
    receipt['runtime_hashes_after']={str(n):hashlib.sha256(n.read_bytes()).hexdigest() for n in [NODE20,NODE24]}
    receipt['tool_files_after']={p:{'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in receipt.get('tool_files',{})}
    receipt['source_unchanged']=receipt.get('source_before')==receipt['source_after']
    receipt['candidate_bundle_changed_from_accepted_smoke']=receipt.get('bundle_before_full')!=receipt['bundle_after_full']
    receipt['bundles_match_qualified_smoke_inputs']=receipt.get('bundles_candidate')=={str(repo):file_map(repo/'packages/cli/bundle',repo) for repo in [REPO,BASE]}
    receipt['bundle_parent_tool_files_after']={p:{'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in receipt.get('bundle_parent_tool_files',{})}
    receipt['git_status']=subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)
    receipt['application_elapsed_seconds']=time.monotonic()-app_started if app_started else 0
    receipt['application_within_deadline']=time.monotonic()<=app_deadline if app_deadline else True
    receipt['final_group_checks']={str(g):group_exists(g) for item in commands for g in {item.get('pgid',0),*(info['pgid'] for info in item.get('observed_processes',{}).values())} if g}
    receipt['owned_children_at_exit']=own_children()
    receipt['not_run']=[label for label in receipt.get('planned_checks',[]) if label not in {c['label'] for c in commands}]
    receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({k:receipt.get(k) for k in ['result','error','application_elapsed_seconds','cleanup_used_seconds','owned_children_at_exit']}),flush=True)
