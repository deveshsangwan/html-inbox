# Read-only shared protocol LENGTH triage

Cause remains unconfirmed. This is source/log triage, not a reproduction, repair, review, qualification or new performance claim. Written by issue94 owner without delegation. No application, build, test, browser, install, CI retry, source/fixture/assertion change, checkout switch or watch operation ran. Issue96 retains its exclusive execution slot.

PR119 remains at clean 53dd8fd5ef4282acbc6304fac89028d695562d7b against immediate parent610c931b7b22920cce59cf03e49c0de15ebaf2a2. Readiness, reviewed/measured pins and the standing owner watch are unchanged. This sole new file is ignored by .gitignore:4 (artifacts/). No committed diff.

## Original evidence and exact source identities

Original96 log, read as all364620 original bytes /4317 decoded lines and independently rehashed:
/home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/ci-42507158253/ubuntu-source-128812155216.log

SHA256:032b3ff9cf3d98f7f0e4ccf4b22bea4b7d7a860595ac98203e490f089e3bf225.
Run42507158253, attempt1, job128812155216, Source(ubuntu-latest,20,1/2):
https://github.com/deveshsangwan/html-inbox/actions/runs/42507158253/job/128812155216

Declared PR122 head dc28e39bd4b691661d02af3ea6e3c58c48fbf450; actual base b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad. Log91/118/121 proves the executable source checkout was GitHub merge c3b24e50b5cf07909e31ff51300d8529da7996f4, with message “Merge dc28e39bd4b691661d02af3ea6e3c58c48fbf450 into b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad”.

The merge object is not available in this checkout (git cat-file -t exited128). A read-only GitHub connector fetch_commit confirmed that exact SHA/message; compare_commits(dc28,c3b24e50) returned status=ahead, ahead_by=1, behind_by=0, total_commits=1, merge_base=dc28, files=[], too_large=null. Thus the fetched compare shows no source-file differences from dc28; no merge tree or compiled artifact was invented locally. Remote calls did not modify refs or files.

Log129-198: Ubuntu24.04.5 x64, runner2.338.2/image20261101.360.1; buildNode24.22.2, pnpm11.7.0, tsc-rs0.7.0; pnpm install --frozen-lockfile, pnpm typecheck and pnpm build completed before switching to testNode20.20.2. Build removed dist and compiled it afresh. Exact failed command: node scripts/run-unit-tests.mjs --test-shard=1/2. These are archived CI commands, NOT commands executed for this triage. Dist bytes are not in the supplied job artifacts, so this receipt supplies source hashes and logged compilation provenance, not a newly verified binary hash.

Adjacent originals independently read/rehashed; pinned source compared byte-for-byte to git show dc28:

- ubuntu-source-job.json: 4015 bytes; SHA256 c746a66920a6d9d453a6969e17f17f5c410e1028812b2dc87a6e7df55aa647bd.
- ubuntu-source-observation.json: 2189 bytes; SHA256 a917b759aaeed6442b7f67138a2ecd047ba944b9769a82ffe8a2a1c451eb0fa6.
- pinned-sync-protocol-faults.test.ts: 52730 bytes; SHA256 0bb954d8c72ad9294c8c9ed342fa7308a9f054d7be5c59d3e9d725d773c7b571.
- pinned-backend.ts: 9229 bytes; SHA256 6724999d14997e3e630e977fffedd4c8734b36aa518aa2a776e3386233b1dcdb.

The observation JSON is corroborating metadata, not a substitute for the original log. Job metadata says only unit/integration failed; later local-retention/harness/package/site steps were skipped. Original log4292-4301 reports732 tests,729 pass,1 fail,2 skipped,0 cancelled and exit1. Full-line classification accounted for all4317 lines (218 setup/epilogue,3680 TAP,403 diagnostics,16 failure-detail lines; no unclassified line). Other tests' admission/finalization/ownership diagnostics are not measurements of this LENGTH request.

Source pins inspected without switching refs:

- 610c931b7b22920cce59cf03e49c0de15ebaf2a2 (original shared benchmark base).
- b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad (actual96 parent).
- dc28e39bd4b691661d02af3ea6e3c58c48fbf450 (failing historical candidate).
- c4914196d275b0dac2a60e9dc09353a29da49f01 (later candidate).

Every file below is in packages/cli/src/. ColumnA is identical at610 andb249. ColumnB is identical atdc28 andc491. Same SHA in both columns means exact unchanged bytes across all four; no claim about unchanged runtime behavior follows from that alone.

| File | A SHA256 | B SHA256 |
| --- | --- | --- |
| sync-protocol-faults.test.ts | 0bb954d8c72ad9294c8c9ed342fa7308a9f054d7be5c59d3e9d725d773c7b571 | 0bb954d8c72ad9294c8c9ed342fa7308a9f054d7be5c59d3e9d725d773c7b571 |
| sync-protocol-fault-child.ts | 40b0bbc888e15c93676da1434f69c3578665b050116650864bdc1ce738b6ed05 | 40b0bbc888e15c93676da1434f69c3578665b050116650864bdc1ce738b6ed05 |
| sync-protocol-fixture.ts | 463ba26f5edcb30ec4578841d73e5304a9086aa46cfc1b09305f46ec8e078614 | 463ba26f5edcb30ec4578841d73e5304a9086aa46cfc1b09305f46ec8e078614 |
| sync-client.ts | 1d3ec68f1ed2701a06cd6db7538a3984cb9a2069626c2f49a96fa8c8a57dc460 | 1d3ec68f1ed2701a06cd6db7538a3984cb9a2069626c2f49a96fa8c8a57dc460 |
| sync-http-server.ts | aae2456047b8b5476949fe144f3839fc4d23e3a4f1c023cb41b576038519c515 | aae2456047b8b5476949fe144f3839fc4d23e3a4f1c023cb41b576038519c515 |
| sync-reconciliation.ts | 388b9775d794076234e41201166b4b4f74afbaddf97f36de8b98e2b65830179f | 388b9775d794076234e41201166b4b4f74afbaddf97f36de8b98e2b65830179f |
| sync-store.ts | 99d218b8c5230a532139868738f09bb4e60ef3d2806c9eac0aa0497c2612d48f | 8d9ca086ac9ef8b29fd7bcbffc5f61b6a03cdc6f3873febc8bec721ceb6d3f09 |
| sync-failure.ts | 0f4967ed3b7007ca38e977d9bb288a771e53f6b393eded1d23d8c50211d11d89 | 0f4967ed3b7007ca38e977d9bb288a771e53f6b393eded1d23d8c50211d11d89 |
| sync-files.ts | 68aec36a32cf04f84f8e37e52ccb64cd07183cea49996f383fb9d81c93603230 | 68aec36a32cf04f84f8e37e52ccb64cd07183cea49996f383fb9d81c93603230 |
| sync-model.ts | 994800604dd0b3d997d0b7f4f0bf664b749973729ff12c598a9b28c0e5cd0422 | 994800604dd0b3d997d0b7f4f0bf664b749973729ff12c598a9b28c0e5cd0422 |
| backend.ts | 8292e8e2a3b47ce3231ff73879f851e8ad769b5b6d3494c7ba475d682a99bef3 | 6724999d14997e3e630e977fffedd4c8734b36aa518aa2a776e3386233b1dcdb |
| documents.ts | 527cb09b1ce7f75a4d723b59492b7652976f77556809081aaedf80e5fa12e6b8 | 9ff9f26ed5f0d4b3fef6a3111331b604b6588ea285a1562fb56cf7795b746d4c |
| local-document-source.ts | 3246fc6d2625a18af06add4b8bab2fc99295995a98f230f06b2d17f3e4244e27 | a486923b0e77eeab35dd59bd19501b5aaa044b913e88c8887d0c2a0e8b650a1e |
| document-read-view.ts | absent | 79387035ac835c7d08a80080cf747a3cca22937d4bf9e68bfa9a826e85aa86a9 |

The entire dc28..c491 diff contains only docs/performance/96-integration-120.md, scripts/bench/evidence/issue-96/README.md, paired-performance-request.md and paired-performance-source.tar.gz. No production change resolves this failure there. A later green result does not establish its cause or resolution.

## Exact failed assertion and what ran before it

The LENGTH case is test373, not a redirect case. Original excerpt:

```text
2273: 2026-11-08T17:53:50.7830752Z # Subtest: actual client rejects length identity response and leaves recoverable work
2274: 2026-11-08T17:53:50.7831447Z not ok 373 - actual client rejects length identity response and leaves recoverable work
2275: 2026-11-08T17:53:50.7831926Z   ---
2276: 2026-11-08T17:53:50.7832229Z   duration_ms: 1323.048916
2277: 2026-11-08T17:53:50.7832854Z   location: '/home/runner/work/html-inbox/html-inbox/packages/cli/dist/sync-protocol-faults.test.js:281:5'
2278: 2026-11-08T17:53:50.7833472Z   failureType: 'testCodeFailure'
2279: 2026-11-08T17:53:50.7833823Z   error: |-
2280: 2026-11-08T17:53:50.7834162Z     redirects must not be followed
2281: 2026-11-08T17:53:50.7834510Z     
2282: 2026-11-08T17:53:50.7834794Z     0 !== 1
2283: 2026-11-08T17:53:50.7835077Z     
2284: 2026-11-08T17:53:50.7835363Z   code: 'ERR_ASSERTION'
2285: 2026-11-08T17:53:50.7835697Z   name: 'AssertionError'
2286: 2026-11-08T17:53:50.7836018Z   expected: 1
2287: 2026-11-08T17:53:50.7836307Z   actual: 0
2288: 2026-11-08T17:53:50.7836606Z   operator: 'strictEqual'
2289: 2026-11-08T17:53:50.7836936Z   stack: |-
2290: 2026-11-08T17:53:50.7837560Z     TestContext.<anonymous> (/home/runner/work/html-inbox/html-inbox/packages/cli/dist/sync-protocol-faults.test.js:294:26)
2291: 2026-11-08T17:53:50.7838267Z     async Test.run (node:internal/test_runner/test:797:9)
2292: 2026-11-08T17:53:50.7838984Z     async Test.processPendingSubtests (node:internal/test_runner/test:526:7)
2293: 2026-11-08T17:53:50.7839455Z   ...
2294: 2026-11-08T17:53:50.7839842Z # fault proxy child 5588: reaped; loopback port rebound
2295: 2026-11-08T17:53:50.7840472Z # application child 5577: reaped; loopback port rebound
```

All four source pins have the exact same test setup/order at sync-protocol-faults.test.ts:281-299. The test constructs pair({proxy:true}), publishes one “malformed-response” original, awaits arm({pathname:"/sync/v1/identity",method:"POST",kind:"length"}), then calls f.run with requestMs500. Pair defaults deadlineMs8000; the overall node:test timeout is20000.

Source288-294 completed: route status is not confirmed; historyReady is false; source delivery is not committed; exactly one outbox entry is non-retired; source receipts are empty; receiver records are empty. These are retained safety observations. They do not identify where the first request failed. The test does not require a specific pending/blocked/aborted status at this point, and its JSON.stringify(result) assertion message is only emitted if that earlier assertion fails.

Source295 fails: receiver network.requests is0, expected1. The generic assertion message “redirects must not be followed” is shared by all nine variants. It supplies no evidence of redirects or following. Source296 faultProof(proxy), source297 retry, source298 confirmed recovery and source299 one receiver document were not executed. Thus this log does not prove that the intended LENGTH response was emitted, reached the client or was rejected. Adjacent fault-proxy5588/application5577 “reaped; loopback port rebound” diagnostics are remote fixture cleanup claims; they are not independent local process inspection.

The1323.048916ms case duration includes credential generation, enrollment, subprocess startup, route setup, publication, reconciliation and assertions. No f.run duration, client request duration, exact stage/error, timer firing or remaining deadline is logged. TAP timestamps are reporter output times, not a request trace. requestMs500 is configuration, not measured elapsed time. Neither the case duration nor surrounding passing variants identifies timeout or host load as cause.

## Static path map and accounting boundaries

References below are line numbers atb249 unless a dc28 line is specified. Unchanged files have the same lines at all four pins.

1. sync-protocol-faults.test.ts:27-99 creates source/receiver ManagedSyncStore directly and enrolls them. It starts a receiver TLS application child and a separate TLS fault-proxy child; the client runs in the parent test process. Both use freshly generated trusted test credentials. No source listener is selected. Both children return ready only after listener startup (sync-protocol-fixture.ts:148-185; sync-protocol-fault-child.ts:209 onward/last ready send), and arm is an IPC request/reply acknowledged after storing the selector. This is a listener/arm barrier, not proof of client admission or a request crossing either TLS leg. Receiver application requestMs is3000 (test53-54); proxy socket/upstream timeout is4000 (child292/302). Neither is the client's500ms deadline.

2. reconcileSyncRoutes at71-99 snapshots the source, selects the configured route, may return for detached/blocked/aborted/blocked-lastError state, and opens an outer route attempt using the8000ms pass deadline. push at178-179 first calls identity; inventory, manifest activation and body transfer are later. A return from f.run proves the outer attempt did not escape uncaught; it does not prove identity was sent. Exceptions inside push are caught at108-127, classified to a sanitized lastError and may be followed by store mutations, outbox recordFailure, watcher close and final snapshots before returning routes/client counters at158. historyReady becomes true only at230, well after identity and manifest activation. An identity success followed by a later failure can also leave historyReadyfalse; zero receiver admissions at the observed time is the sharper boundary here.

3. SyncClient.json at32-50 constructs the nonce envelope, checks the response type/status, reads a bounded body and parses the identity. request at99-101 creates its absolute min(passDeadline,now+500) deadline BEFORE its own openRouteAttempt. This inner admission calls startCommunication through the store, so it can consume the budget without creating native HTTPS. Only StoreLockQueueDeadlineError from this first inner open is mapped to503/local-acquisition-deadline with cause; other acquisition, validation, cleanup and authorization errors can propagate differently.

4. dc28 sync-store.ts:588-620 startCommunication authorizes the route via mutate, checks persistent pause, flushes the baseline and invokes the start callback under the mutation lock. dc28:623-687 openRouteAttempt itself calls startCommunication, installs the attempt/parent abort link and starts50ms authorization watchers. Client then calls startCommunication again atsync-client118; callback119-121 checks abort and deadline BEFORE credentials/binding/native HTTPS. dc28 mutate1347-1375 acquires the lock, may recover, freshly reads/parses/verifies the ledger and checks anchor/barrier/reader identity. sync-files208-256 separately waits the process-local queue and native ownership; acquired operations and lock cleanup are awaited (404-417). Queue-deadline failure, native acquisition/validation failure, watcher/parent cancellation, callback deadline rejection and lock-release failure are distinct source-supported alternatives. No one of them is established here.

5. Native https.request is created atsync-client136, with agent:false, certificate verification and the attempt abort signal. Client counters.requests increments at142 AFTER that constructor returns, BEFORE any evidence of remote arrival. The one request timer is installed after the inner open (116) using the remaining original deadline; request.setTimeout also uses remaining time (143). Request error handling maps cancellation/certificate/transport failures at144-149; streaming failures with incomplete response can become503/response-truncated at138-140. Credentials or native constructor failure can precede the client increment. These raw errors/cause chains are not printed by this test.

6. Proxy incoming HTTP callback atsync-protocol-fault-child220-234 increments starts["POST /sync/v1/identity"], consumes armed, increments hits, and emits type:"fault",kind:"length" BEFORE creating/finishing the upstream request. Its status reply at317-329 exposes starts,hits,armed,sockets. Therefore hits1/armedfalse plus one fault message proves selector consumption, NOT LENGTH response delivery. The HTTPS upstream request at236 forwards the incoming request with copied headers/host and trusted CA, reads its full response into a bounded32MiB buffer (238-253), then sets Content-Length to body.length+1 at283, writes headers and ends with the shorter body at284-285. Upstream errors, client abort or outgoing close can destroy it before this stage (286/293-295). A successful malformed LENGTH response must follow an actual upstream HTTP response; a mere fault message is insufficient.

7. Receiver https server invokes handle via a microtask after HTTP parsing, except the closed-server guard at72-75. sync-http-server220-222 increments requests FIRST, before URL/method checks, authentication, capacity rejection, ledger authorization, envelope parsing or identity-session creation. Socket acceptance/TLS handshake/HTTP parser/clientError failures are earlier and may leave requests0 (70-94). Once handle has incremented, an authorization, storage, envelope or identity failure does not decrement it. status592-595 copies the monotonic counters without resetting them. fixture171-173 returns that copy directly; test143-145 reads its network counter, not storage counters or client counters. The case starts a fresh server and never sends a restart/reset command.

8. On the normal receiver identity path, authentication performs current startCommunication first; only then envelope/challenge/session handling occurs (246-288). Receiver inventory runs only if its route direction is outbound, while this fixture receiver route is inbound. A receiver authorization/storage rejection AFTER handle entry would still yield requests>=1, so such a rejection by itself cannot explain the observed0. No valid path constructs the intended proxy LENGTH response from an upstream HTTP response while this same live receiver counter remains0. Counter0 is still a point-in-time status observation: neither client failure nor IPC status joins all proxy/upstream activity. An in-flight admission after the observation remains distinguishable only with correlated/drained evidence. “No counted receiver request yet” is justified; “no socket/request existed anywhere” is not.

## Candidate96 changes on the actual path

Unchanged protocol/test files do not exonerate the candidate. At610/b249 snapshot directly checks directories then calls readLedger; dc28/c491 snapshot150-152 delegates through readSnapshot190-203 with an async readLedger callback. The current readLedger1572-1574 delegates to new parseVerifiedLedger1576-1587 after the same fresh byte read. The latter still parses the entire ledger and verifies every record. These refactors execute in fixture/setup, reconciliation snapshots and store admission/recovery/watchers. The new module is also imported by sync-store. Their added calls/promise scheduling/module load and any resulting error/timing consequences were not measured here and are not presumed irrelevant.

The exact-byte reuse/local-ID map in ManagedSyncStore.withReadView154-188 is selected only by its explicit scoped operation. This case does not call it: the stores are direct ManagedSyncStore objects; client/server admission uses mutate/readLedger and ordinary snapshots. The post-recovery listDocuments call is after the failed assertion and was unreached; no static export or LocalDocumentSource/LocalDocumentBackend read-view dispatch is selected before failure. LocalDocumentBackend methods did change and can be loaded through the test import graph, but pair/enroll/publish/identity use the direct managed-store implementations. Accordingly, view-cache invalidation cannot be asserted as the mechanism of this observed failure; shared readLedger/snapshot changes and execution scheduling remain in scope for a future paired trace.

sync-model.ts is identical at610/b249/dc28/c491, and sync-signatures.ts does not exist at these96 pins. This candidate does not contain94's process-wide signature-success cache. No cache-specific cause is inferred from either historical record.

## Distinct old94 record, not a baseline reproduction

Old preserved original: /home/agent/.t3/worktrees/html-inbox/perf-94-sigcache/artifacts/94/ci-original-ubuntu20-shard2.log
624504 bytes,4903 lines, SHA25607e7eedbe99cfaf8e21a165cde308e733f0249fe3e8bb9128e33f2328702419b.
Run42388445296 attempt1, Ubuntu20 Source2/2 job128450720113:
https://github.com/deveshsangwan/html-inbox/actions/runs/42388445296/job/128450720113
PR119 head999c75d37e1f1d86c25e58b4d45db3f96a66df38, parent610c931b7b22920cce59cf03e49c0de15ebaf2a2; actual logged checkout09f8e49eaeeca34ac8fd4ed40d9894693b9afbd6 (merge of those pins). Build24.22.2, runtime20.20.2; exact command node scripts/run-unit-tests.mjs --test-shard=2/2.

Old case522 was OVERSIZED, not LENGTH: lines3046-3068 report1799.779962ms and the same0vs1 source295/js294 assertion, with proxy5102/application5091 cleanup diagnostics. Test bytes equal all four mapped pins (SHA0bb954d8...7b571), but old candidate999 DOES include94 signature caching and the actual job/shard/source differ. Oversized mutation replaces the upstream body with4097 spaces (child274) and declares its actual length; LENGTH keeps the upstream bytes but declares one extra byte. These are distinct injected faults. Both records lack successful faultProof/recovery evidence. Their common failed oracle motivates checking shared admission/transport/accounting; it does not establish a common cause, pre-existing failure on610/b249, load sensitivity or resolution by a later green run.

## Alternatives and concrete discriminants

| Alternative consistent with current observation | Evidence that distinguishes or falsifies it |
| --- | --- |
| Reconciliation skipped the route or failed before inner request construction, including state/authorization/ledger/baseline/lock/cleanup/watcher paths | Exact returned route status/lastError, client counters, outer/inner admission phase and original typed error/cause. A correlated native request-created event/client count1 excludes a wholly precreation failure for that request. A fulfilled f.run alone does not. |
| Deadline or cancellation before dispatch or on either TLS leg | Positive recorded deadline margin/abort-source event and phase at failure are required. Successful request creation or proxy selection narrows the stage but does not itself exclude later deadline/cancellation. Config500/case1323 proves neither occurrence nor cause. |
| Native HTTPS construction/TLS/transport failure before proxy HTTP callback | Client native-create/error/socket/secureConnect observations, plus proxy starts0 and still-armed selector. Proxy starts/hits1 excludes “never reached proxy HTTP” but not upstream failure. |
| Proxy selected the LENGTH fault, then upstream connect/TLS/parser/abort/forwarding failed before receiver handle | Proxy starts/hits/armed plus upstream stage/error and receiver socket/TLS/parser/handle-entry event. A correlated receiver handle-entry/counter>=1 falsifies “no receiver admission”. Existing proxy fault message is emitted too early to decide. |
| Receiver socket/TLS/HTTP parsing or closed-server guard stopped it before handle | Receiver connection/secureConnection/clientError/tlsClientError/closed status, paired with proxy upstream events. Authentication/schema/store rejection after handle alone is incompatible with0 on this same unchanged counter. |
| Status sampled before a still-in-flight upstream request entered handle | Preserve the original counter snapshot for the existing assertion; compare later correlated events only diagnostically and record whether all relevant sockets/handlers settled. A joined no-later-admission trace would exclude this. Later requests must not turn the original failed assertion into a pass. |
| Wrong server/counter correlation, restart, or counter reset | Fixture child PID/listener instance and request association. Source shows no reset/restart and fresh pair ownership, so this has no positive support; it becomes material only if emitted LENGTH upstream completion and an unchanged same-instance counter0 contradict the source ordering. |
| Client received/rejected the intended short LENGTH response | Requires proxy upstream complete, actual short-body write/end and corresponding client headers/body/complete/error trace, with receiver admission>=1. Current0 observation and unreached faultProof supply no positive evidence of that path. |

## Smallest bounded next check proposed to root — NOT executed or granted here

First use already available state, without a new production hook: retain the arm reply (starts/hits/armed), capture the returned f.run routes/client counters, and preserve receiver status at exactly the existing source295 observation. If the count assertion fails, emit these bounded diagnostics plus current proxy.status and its bounded matching fault messages in a failure-only finally/rethrow path. Keep the original count value, message and assertion; keep all preceding safety, subsequent faultProof, retry and confirmed-recovery assertions in their present order. A diagnostic IPC query after failure must not resample the asserted value to turn0 into1. Do not let diagnostic failures replace the original assertion. This first check usually partitions client0 / proxy0 / upstream0 without a broad fixture redesign, but cannot by itself recover the missing500ms margins.

If root authorizes a trace in the same diagnostic run, keep it narrowly attached to this one LENGTH attempt: a bounded per-process event buffer (for example32 records, overflow explicitly flagged), recorded locally and emitted after failure/settlement, with relative monotonic timestamps, instance/request ordinal, phase, remaining absolute deadline, and typed error code/cause category. Capture before/after outer admission, inner openRouteAttempt and startCommunication/native request creation; socket/TLS/response/stream end/error/abort; proxy selector consumption versus upstream response completion and short-body write/end; receiver handle increment and its pre-handle TLS/parser errors. Record watcher/parent/request abort source separately and retain cleanup errors. Do not insert awaited IPC/logging inside the500ms operation, log credentials/authorization/bindings/private keys/bodies, or import a timing-heavy observer into production. Cross-process monotonic clocks have different origins: correlate request ordinals and existing IPC/forwarding order, and report relative local times rather than subtracting unrelated clocks.

The existing child-ready and arm-ack messages are the preparation barrier. Preserve them and their evidence; do not add an authenticated identity preflight (it would consume the fault/warm the path), a pause/release that delays malformed delivery, a wait-until-counter1, extra automatic retries, bypassed validation or a later-started budget. Any passive post-failure settlement observation is diagnostic only and cannot replace the original assertion. Preserve500ms client/8000ms pass/20000ms test and3000/4000ms receiver/proxy bounds; leave the60s production maximum/default policies unchanged.

After96 releases its active measurement work and root grants a separate bounded diagnostic run, proposed execution scope is exactly one isolated LENGTH case at the failing source tree (c3b24e50, or byte-identical dc28 with provenance stated) and one at actual parentb249, same freshly linked dist/build toolchain, exact Node20.20.2, fixture sizes/settings and diagnostic wiring, sequential, no repeat-until-green. Root must choose whether to recreate the original whole shard or run the isolated case first; isolation cannot establish the original shard context. Proposed isolated command on each separately built/pinned dist is node --test --test-name-pattern='^actual client rejects length identity response and leaves recoverable work$' packages/cli/dist/sync-protocol-faults.test.js. This is a future proposal, not an execution command issued here. Stop after this fixed comparison or any cleanup mismatch; retain failure and success logs, source/dist/runtime/observer hashes, exact request outcome, margins, child reap and loopback closure. A non-recurrence would leave the historical cause unconfirmed. Attribute a candidate-specific effect only with a trace that reaches the changed snapshot/parser path and distinguishes it from the parent; otherwise root coordinates any shared protocol/test diagnostic scope before edits.

No evidence here concerns dc28's Windows legacy-deletion result, older finalization guards, browser navigation or nlink. Those assignments remain separate.

## Read-only command/status receipt

Successful inspection operations (exit0 unless noted): git rev-parse HEAD; git status --short --branch; git diff --stat; git show <each exact source pin>:packages/cli/src/<files in hash table> with numbered relevant excerpts; git diff b24927ab dc28e39b -- packages/cli/src/sync-store.ts packages/cli/src/backend.ts packages/cli/src/local-document-source.ts packages/cli/src/documents.ts; git diff dc28e39b c4914196 --name-status; rg over the original logs for checkout/runtime/command/not-ok/request-stage fields; Python read_bytes/decode/SHA256 over the full originals and adjacent metadata; byte comparisons against Git; git check-ignore -v artifacts/94/shared-protocol-length-triage-2026-11-08.md.

Read-only GitHub connector operations: fetch_commit(repo_full_name=deveshsangwan/html-inbox,commit_sha=c3b24e50b5cf07909e31ff51300d8529da7996f4); compare_commits(repo_full_name=deveshsangwan/html-inbox,base=dc28e39bd4b691661d02af3ea6e3c58c48fbf450,head=c3b24e50b5cf07909e31ff51300d8529da7996f4), both successful. Compare result summarized above. No check listing/watch/rerun was requested.

Inspection-only limitations: local git cat-file for the ephemeral merge returned128, handled by the read-only remote source comparison. One unquoted zsh inspection glob matched no file and was replaced with exact paths. Large tool outputs were truncated; exact failure/setup/tail spans and the full-file accounting were reread with bounded output. These are inspection issues, not application failures or discarded qualification samples.

Final state: no tracked/untracked nonignored changes; HEAD53dd8fd5ef4282acbc6304fac89028d695562d7b unchanged; no heavy process started; no new owner/child/review/PR/watch. Cause unconfirmed. Root owns the proposed future execution/repair decision. Existing PR119 readiness/reviews/measurement/GO scope remain as previously accepted; this triage does not widen them. Owner babysitting continues without re-registration.
