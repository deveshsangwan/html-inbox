# Windows hub legacy deletion, read-only receipt

No native cause is established. A concrete adjacent application error narrows this from a generic surviving-document observation: the handler logs an IPC-parsed EPERM opening the exact per-document deletion lock. Helper exit0 and fulfilled hub close do not assert successful deletion. No application/toolchain/test/browser execution, install, retry, source/test/fixture edit, child/review/PR or new watch occurred. #96 measurement slot and reserved b249 generated outputs are untouched; PR117/120 source/refs/readiness remain unchanged.

## Original evidence

Historical candidate dc28e39bd4b691661d02af3ea6e3c58c48fbf450, exact parent b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad; current comparison c4914196d275b0dac2a60e9dc09353a29da49f01. Run42507158253 attempt1, Windows24 Source1/1 job128812155307, runtime24.22.2. Read the complete original log and adjacent observation/pinned source copies. Independently rehashed log564637bytes SHA256a09bcc1641fe0ea021c017d8c2175c108a4c7ef6b5cbcbc4596ab2b8b2ee5914. Original absolute path and source identities are appended below. Originals were not changed.

The case lasts428.2197ms and fails at compiled viewer-mutation-shutdown.test.js355:26, source329, strict getter expectednull but returned schema1 metadata plus original64-byte body. No timeout is reported. By source assertion order, native close/rebind, closeCompletedfalse/helper.exitCodenull/originalbytes before release, awaited parent unlink, bounded Promise.all(closing,helperClosed), closeCompletedtrue and helper.exitCode0 all passed. No later success-result assertion exists in this case; its final getter-null assertion failed. Finally still owns disconnect/close joins, followed by temporaryHome's removal hook; the log is not an independently preserved native handle or full fixture cleanup trace.

Immediately preceding this case, original log lines contain:

```text
html-inbox: Document deletion failed: Error: EPERM: operation not permitted, open '...html-inbox-test-5LRUQD\documents\.trash\.delete-caca7333da338a3a72ab51b966909a075fb7bb9704d5daf2e19c14e8ee1a474a.lock'
at parseDeletionError (...document-deletion-protocol.js:98:86)
at parseDocumentDeletionResponse (...document-deletion-protocol.js:69:36)
at ChildProcess.<anonymous> (...document-deletion.js:144:91)
code: 'EPERM', [cause]: undefined
```

The basename digest is independently SHA256('legacy-original'), exactly the test's held lock. The adjacent error is strongly correlated with this single-helper case through that lock and test order, but the log lacks a request ID, child PID and originating worker stack. The displayed stack is reconstructed in the parent, not a native call stack. This is lock-file OPEN, not document-directory RENAME, viewer.json unlink, browser count timing or late command marker. Do not conflate their native causes.

## Pinned source paths

All line references below are dc28 unless explicitly qualified; c491 production bytes match dc28 for every listed relevant path.

1. **Test283–336.** Publishes one fresh unenrolled legacy document with fixed ID and exact64-byte body. Parent creates `.trash/.delete-<digest>.lock` with wx and JSON pid/token. Test-local fork wrapper asserts the real compiled index.js entry, retains the real child, observes OS spawn and close. It does not retain the child's IPC response/result or an actual worker-side lock-admission signal. OS spawn is not proof that the child reached/waited on that lock. After disconnect it starts hub close, observes native listener close/rebind and child still live, reads index.html, then unlinks the held lock. This ordering allows overlap with a worker's lock-owner inspection or next exclusive create, but no such overlap is timed in the log. ClosingPending/helperAlive can also reflect startup/pre-lock work.
2. **hub21–33.** Captures createDocumentDeleter per mount and a LocalDocumentSource, then starts the hub HTTP server. This is not startViewerLifecycle; it has no viewer.json owner or Tailscale service here.
3. **document-deletion15–89,123–179.** Captures canonical root/instance/documents/trash identity; repeatedly checks managed lifecycle. This fixture has no enrollment, so its selected legacy deleter forks index.js `__delete-document`, cwd=home, execArgv=[], IPC with stdio ignored. On spawn it sends the captured request. The returned mutation promise resolves/rejects only at CHILD CLOSE: valid success response resolves result/null; valid ok:false rejects parsed error; transport/missing/nonzero outcomes reject. The test does not retain this promise directly.
4. **index final entry gate and worker34–61.** IPC-only private invocation calls runDocumentDeletionWorker. The worker catches validation/storage/delete errors into `{protocolVersion:1,ok:false,error:serializeDeletionError(error)}`, awaits sending the response, disconnects and resolves normally. The top entry sets exitCode1 only for a rejection escaping this routine. Thus OS exit0 is compatible with a reported deletion error or success-null. It does not mean a document was removed. The test's helperClosed promise ignores its close arguments; the subsequent exitCode0 assertion supplies only process termination status.
5. **protocol86–110 and viewer-document-deletion55–84.** Success and ok:false are separate IPC contracts. The HTTP handler awaits deletion; a generic parsed EPERM chooses its500 error branch after logging. A success-null would choose404, a real successful result204, cleanup-error200 and identity-error409. This client is already disconnected, so the test asserts no HTTP response status/body and observes none of these distinctions. The adjacent log is evidence of the parsed worker-error path; actual response delivery500 is not captured and must not be claimed.
6. **viewer-http-server149–175.** pendingMutations contains the request-handling promise, whose errors are handled/logged; close awaits native close and Promise.allSettled over that set. This owns lifetime/settlement, not mutation success. A failed deletion can settle, the helper can close0, and hub.close can fulfill with the original document still on disk. Therefore the passed joins do not contradict the final assertion failure. There is no evidence here that hub close returned before this observed helper closed.
7. **worker134–179,221–254,398–427.** Inspects legacy document tree and metadata, validates identity/snapshot, then acquires the per-ID lock; after lock acquisition it rechecks and renames into a unique trash directory, purges and releases. The exclusive lock create is `open(lockPath,"wx",0o600)` at254. Only EEXIST is treated as contention; EPERM is propagated, not retried. Lock-owner read opens the same file via readCheckedFile, but its errors are either tolerated for a recent lock or wrapped by checkDocumentLockOwner's distinct verification message/cause. Under this pinned code, the plain EPERM-open-lock message without cause therefore narrows most directly to exclusive-create254. This is a SOURCE-DERIVED phase inference, not an observed worker stack or native-cause proof. Minimal phase logging should confirm it. No rename success is reported in this log.
8. **Legacy publish/read path.** backend46–74 prepares home/documents/.staging/.trash; writes metadata.json and index.html into staging then renames to documents/legacy-original. The getter122–145 calls readCurrentDocument with NO managed view, checks enrollment, calls public getDocumentMetadata148–162, hardens/verifies directory/files234–260, reads fresh metadata178–206, then fresh index.html137. Missing/incomplete paths can returnnull; complete actual metadata/body yields this observed object. No stored body/metadata cache is visible on this direct path. The hub LocalDocumentSource also delegates legacy reads to freshly checked metadata/body/identity, not a managed view. Hardening includes filesystem chmod; that is a real operation, not a cache read. The pre-release explicit index.html read is awaited; its presence proves data existed then, not later deletion success.

## Production comparison and contrary alternatives

#96 changes backend/source public methods into direct private dispatch and adds opt-in withReadView; managed snapshot implementation also changes. These candidate changes must not be exonerated just because the test file is unchanged. However the exact final getter here supplies no managed view, and hub's HTTP reads do not call withReadView. Source tracing therefore does not support a stale managed-view buffer as an explanation for this direct getter. Timing/dispatch, identity or unexpected enrollment branches remain falsifiable alternatives until captured. The nonnull object is source-consistent with a fresh read of a retained original after a reported deletion failure.

Inherited PR120 changes startViewerLifecycle ownership/journaling and common browser fixture cleanup, plus a separate managed startup test loop. It does not change the hub, worker, IPC protocol or reader pending-mutation implementation. The whole mutation test file differs610 because of that loop, but this particular hub-case body also compares independently. This narrows placement, not historical attribution. dc28→c491 has no packages/cli/src changes; later c491 green CI neither explains the original error nor makes it pre-existing/flaky. See complete hashes below.

The test has a concrete observability/synchronization gap: it joins the helper but treats exit0 as a success proxy, does not inspect the result/error contract, and uses OS spawn rather than a worker lock-phase barrier. That does not justify weakening its final deletion assertion. The observed operation error remains a correctness observation requiring disposition before attributing it to a harmless test condition.

Falsifiable next alternatives:

- Primary source-consistent path: child exclusive lock create rejects with EPERM, returns ok:false, hub joins failed handling, getter reads the untouched original. Capture the actual child IPC envelope and phase to distinguish this from nominal success/null. No native reason for EPERM is established.
- Parent unlink may overlap a child lock-owner read or subsequent create. If a phase trace shows EPERM BEFORE parent unlink begins, this specific release-overlap hypothesis is falsified; after-unlink failure remains compatible with other native/permission/handle conditions, not proof of delete-pending semantics. Do not assert ordinary Node file reads categorically deny deletion on Windows.
- Contrary outcome: worker reports ok:true with matching nonnull result yet the same original remains after helper close. That requires a different investigation of exact home/cwd/identity, rename/purge result and getter disk state; the joined-error explanation would be insufficient. A success-null while the original remains likewise needs exact existence/identity events. A stale direct read or different target is not proven merely by nonnull data.

## Smallest proposed next check, NOT RUN

Root may authorize ONE focused Windows24.22.2 run at exact dc28 in an isolated diagnostic checkout, with the existing15000ms case/5000ms join limits and all assertions intact:

```sh
node --test --test-name-pattern='^hub close joins a disconnected legacy deletion and its real helper child$' packages/cli/dist/viewer-mutation-shutdown.test.js
```

First use only test-local passive observers in the existing fork wrapper: monotonic parent times for fork/spawn, lock-unlink start/end, child message including complete bounded parsed/raw IPC envelope, exit/close code/signal, nativeClose/hubClose, final getter result and error chain. Tag home/instance/id/lock digest, childPID and one synthetic request correlation ID in the diagnostic record, without altering the wire request. Capture matching deletion-handler error unmodified. Retain the final strict null assertion. Preserve output/errors and join owned children on failure; save evidence outside fixture root before its cleanup. No new retry or generic timeout change.

If that single observation still cannot identify the lock phase, root can separately authorize a narrow child open observer using the existing test worker-interception pattern: phase/path/flags plus start/end/error/native code around lock-exclusive-create versus lock-owner-read and descriptor close, correlated with parent unlink. Record native handle facts only if actually captured. No production lock/retry patch follows from this proposal. An independent deterministic error-envelope control can use an existing synthetic worker error to verify ok:false plus exit0 and preserved original; that proves the contract distinction, not the native actor. No broad review, runtime loop or extra unrequested execution is needed now.

The three earlier failure families remain separate, as do the command-runner observation and macOS sync observations. Root owns the next scope/integration decision. This receipt does not change PR117/120 readiness or current measurement authority.

## Identity appendix

Generated below from git objects and the unchanged original file. No generated dist/bundle was read or changed for this triage.

```json
{
  "pins": {
    "610c931": "610c931b7b22920cce59cf03e49c0de15ebaf2a2",
    "b24927a": "b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad",
    "dc28e39": "dc28e39bd4b691661d02af3ea6e3c58c48fbf450",
    "c491": "c4914196d275b0dac2a60e9dc09353a29da49f01"
  },
  "source_sha256": {
    "viewer-mutation-shutdown.test.ts": {
      "610c931": "e51ff7adf9cc7157a12e1dede87f0445fe17a2d910d014eebce8a47d15a4a380",
      "b24927a": "973f35b90f5927d0a88f3cd9d76e1ed0cc1af4baf71c88764fefdbee380ec4e6",
      "dc28e39": "973f35b90f5927d0a88f3cd9d76e1ed0cc1af4baf71c88764fefdbee380ec4e6",
      "c491": "973f35b90f5927d0a88f3cd9d76e1ed0cc1af4baf71c88764fefdbee380ec4e6"
    },
    "backend.ts": {
      "610c931": "8292e8e2a3b47ce3231ff73879f851e8ad769b5b6d3494c7ba475d682a99bef3",
      "b24927a": "8292e8e2a3b47ce3231ff73879f851e8ad769b5b6d3494c7ba475d682a99bef3",
      "dc28e39": "6724999d14997e3e630e977fffedd4c8734b36aa518aa2a776e3386233b1dcdb",
      "c491": "6724999d14997e3e630e977fffedd4c8734b36aa518aa2a776e3386233b1dcdb"
    },
    "local-document-source.ts": {
      "610c931": "3246fc6d2625a18af06add4b8bab2fc99295995a98f230f06b2d17f3e4244e27",
      "b24927a": "3246fc6d2625a18af06add4b8bab2fc99295995a98f230f06b2d17f3e4244e27",
      "dc28e39": "a486923b0e77eeab35dd59bd19501b5aaa044b913e88c8887d0c2a0e8b650a1e",
      "c491": "a486923b0e77eeab35dd59bd19501b5aaa044b913e88c8887d0c2a0e8b650a1e"
    },
    "document-read-view.ts": {
      "610c931": null,
      "b24927a": null,
      "dc28e39": "79387035ac835c7d08a80080cf747a3cca22937d4bf9e68bfa9a826e85aa86a9",
      "c491": "79387035ac835c7d08a80080cf747a3cca22937d4bf9e68bfa9a826e85aa86a9"
    },
    "document-deletion.ts": {
      "610c931": "b7cb7c93dca0659d0afcc10cd9d5bd9824d9916b8fd91642a21d18051f23531b",
      "b24927a": "b7cb7c93dca0659d0afcc10cd9d5bd9824d9916b8fd91642a21d18051f23531b",
      "dc28e39": "b7cb7c93dca0659d0afcc10cd9d5bd9824d9916b8fd91642a21d18051f23531b",
      "c491": "b7cb7c93dca0659d0afcc10cd9d5bd9824d9916b8fd91642a21d18051f23531b"
    },
    "document-deletion-worker.ts": {
      "610c931": "c319bcea40d88fb91e2e127ab8f697d8e580a66c7d04206ce71af235b0046090",
      "b24927a": "c319bcea40d88fb91e2e127ab8f697d8e580a66c7d04206ce71af235b0046090",
      "dc28e39": "c319bcea40d88fb91e2e127ab8f697d8e580a66c7d04206ce71af235b0046090",
      "c491": "c319bcea40d88fb91e2e127ab8f697d8e580a66c7d04206ce71af235b0046090"
    },
    "document-deletion-protocol.ts": {
      "610c931": "e30fa568167d400cd2e165f6ec6ac1e0f92f5c3473005cd7b269dc9f28c3f755",
      "b24927a": "e30fa568167d400cd2e165f6ec6ac1e0f92f5c3473005cd7b269dc9f28c3f755",
      "dc28e39": "e30fa568167d400cd2e165f6ec6ac1e0f92f5c3473005cd7b269dc9f28c3f755",
      "c491": "e30fa568167d400cd2e165f6ec6ac1e0f92f5c3473005cd7b269dc9f28c3f755"
    },
    "viewer-http-server.ts": {
      "610c931": "4f05cfcd2982ee49421628d7862917034dd4667c633c864e8496af9ee224cfa7",
      "b24927a": "4f05cfcd2982ee49421628d7862917034dd4667c633c864e8496af9ee224cfa7",
      "dc28e39": "4f05cfcd2982ee49421628d7862917034dd4667c633c864e8496af9ee224cfa7",
      "c491": "4f05cfcd2982ee49421628d7862917034dd4667c633c864e8496af9ee224cfa7"
    },
    "viewer-document-deletion.ts": {
      "610c931": "5ca670f13d78fa18c446c57285733fb2e2d20639d5d60d210bcb50bfca513252",
      "b24927a": "5ca670f13d78fa18c446c57285733fb2e2d20639d5d60d210bcb50bfca513252",
      "dc28e39": "5ca670f13d78fa18c446c57285733fb2e2d20639d5d60d210bcb50bfca513252",
      "c491": "5ca670f13d78fa18c446c57285733fb2e2d20639d5d60d210bcb50bfca513252"
    },
    "hub.ts": {
      "610c931": "4df121f6a54b34b89d6515794d18f3506297c992d5a92df834842edd2802ca03",
      "b24927a": "4df121f6a54b34b89d6515794d18f3506297c992d5a92df834842edd2802ca03",
      "dc28e39": "4df121f6a54b34b89d6515794d18f3506297c992d5a92df834842edd2802ca03",
      "c491": "4df121f6a54b34b89d6515794d18f3506297c992d5a92df834842edd2802ca03"
    },
    "index.ts": {
      "610c931": "bae1691971aaae349426eebd5b9324dfab70cb7d749d87a3421cc6302894f7f7",
      "b24927a": "bae1691971aaae349426eebd5b9324dfab70cb7d749d87a3421cc6302894f7f7",
      "dc28e39": "bae1691971aaae349426eebd5b9324dfab70cb7d749d87a3421cc6302894f7f7",
      "c491": "bae1691971aaae349426eebd5b9324dfab70cb7d749d87a3421cc6302894f7f7"
    },
    "viewer-server.ts": {
      "610c931": "342d2ec232fc2da54a8437fb3dcdf8687a0c18c1511899b10ba00d2e1ff49c0f",
      "b24927a": "50a05873e7de3ad171b2021c12300197ed4ca54bf7c660d70aea1bab34a52cfe",
      "dc28e39": "50a05873e7de3ad171b2021c12300197ed4ca54bf7c660d70aea1bab34a52cfe",
      "c491": "50a05873e7de3ad171b2021c12300197ed4ca54bf7c660d70aea1bab34a52cfe"
    },
    "test-fixtures.ts": {
      "610c931": "6c14cc880cc3ec6eef56968b8da1302e4ec91a7a677c524a730df6cd57434926",
      "b24927a": "6c14cc880cc3ec6eef56968b8da1302e4ec91a7a677c524a730df6cd57434926",
      "dc28e39": "6c14cc880cc3ec6eef56968b8da1302e4ec91a7a677c524a730df6cd57434926",
      "c491": "6c14cc880cc3ec6eef56968b8da1302e4ec91a7a677c524a730df6cd57434926"
    },
    "local-storage-checks.ts": {
      "610c931": "9e97fd0bdac27c93dce45c136d4b5bc1c2d9536b18fb7e7c7bd6a74fde474a90",
      "b24927a": "9e97fd0bdac27c93dce45c136d4b5bc1c2d9536b18fb7e7c7bd6a74fde474a90",
      "dc28e39": "9e97fd0bdac27c93dce45c136d4b5bc1c2d9536b18fb7e7c7bd6a74fde474a90",
      "c491": "9e97fd0bdac27c93dce45c136d4b5bc1c2d9536b18fb7e7c7bd6a74fde474a90"
    },
    "private-storage.ts": {
      "610c931": "000d77f9dbd585e3f10ea393f03a6e59049980d4d3aae34a219e2cbfd4413e62",
      "b24927a": "000d77f9dbd585e3f10ea393f03a6e59049980d4d3aae34a219e2cbfd4413e62",
      "dc28e39": "000d77f9dbd585e3f10ea393f03a6e59049980d4d3aae34a219e2cbfd4413e62",
      "c491": "000d77f9dbd585e3f10ea393f03a6e59049980d4d3aae34a219e2cbfd4413e62"
    }
  },
  "case_body_sha256": {
    "610c931": "e6adf36cd2b1beedbe841a3a553d3262643921dcaf07cfaa6c7c2f7558d0a7b3",
    "b24927a": "e6adf36cd2b1beedbe841a3a553d3262643921dcaf07cfaa6c7c2f7558d0a7b3",
    "dc28e39": "e6adf36cd2b1beedbe841a3a553d3262643921dcaf07cfaa6c7c2f7558d0a7b3",
    "c491": "e6adf36cd2b1beedbe841a3a553d3262643921dcaf07cfaa6c7c2f7558d0a7b3"
  },
  "original_files": {
    "/home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/ci-42507158253/windows-source-128812155307.log": {
      "bytes": 564637,
      "sha256": "a09bcc1641fe0ea021c017d8c2175c108a4c7ef6b5cbcbc4596ab2b8b2ee5914"
    },
    "/home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/ci-42507158253/windows-source-job.json": {
      "bytes": 4017,
      "sha256": "5dd380b684ac69cc39e0914780049d69c6ee3ae44f6650a8c0574686b04ce9cf"
    },
    "/home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/ci-42507158253/windows-source-observation.json": {
      "bytes": 1838,
      "sha256": "208738c036caf0f401e730de2a24cba84074cb8fb332a514d3418bc433fa6e31"
    },
    "/home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/ci-42507158253/pinned-viewer-mutation-shutdown.test.ts": {
      "bytes": 21801,
      "sha256": "973f35b90f5927d0a88f3cd9d76e1ed0cc1af4baf71c88764fefdbee380ec4e6"
    },
    "/home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/ci-42507158253/pinned-backend.ts": {
      "bytes": 9229,
      "sha256": "6724999d14997e3e630e977fffedd4c8734b36aa518aa2a776e3386233b1dcdb"
    }
  },
  "lock_digest_legacy-original": "caca7333da338a3a72ab51b966909a075fb7bb9704d5daf2e19c14e8ee1a474a",
  "local_status": {
    "/home/agent/.t3/worktrees/html-inbox/perf-93-startup": {
      "head": "f290211f440f65c11c877dd5baf50b88cda2d969",
      "status": ""
    },
    "/home/agent/.t3/worktrees/html-inbox/t3-26d1cd47": {
      "head": "b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad",
      "status": ""
    }
  }
}
```
