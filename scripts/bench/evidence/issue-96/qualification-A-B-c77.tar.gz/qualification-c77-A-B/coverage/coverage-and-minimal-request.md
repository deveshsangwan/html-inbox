# Read-only coverage assessment at c77ace3

Clean head **c77ace3c207f302249ba98216caafeab8719dd7b**, immediate parent **b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad**. Proposed coverage disposition for root, not an execution grant or a success rewrite. No application/controller/helper/toolchain/test/version/browser/install/benchmark command ran; no tracked source, parent output, retained root or raw receipt changed. No push.

Saved **Verify42520123188 attempt1** metadata reports15 leaves plus Verify successful. Eight necessary Linux logs were fetched ONCE and retained verbatim with hashes in `log-retrieval-receipt.json`; `hosted-step-index.json` binds exact commands, summaries, step conclusions and line ranges. Checkout merge **041c201fee21302f18107afda8cb9595ceac16bd** has complete tree **cebf38e8f907b35786acafad78faee3a731539d8**, independently verified equal to c77's tree. Native jobs' success is metadata evidence; native raw counts are not inferred.

Source and Browser build on **24.22.2**, frozen pnpm11.7.0 lockfile/tsc-rs0.7.0, then test on **20.20.2** or **24.22.2**. Skills selects its test runtime without a candidate build. Browser uses real Chromium in pinned Playwright1.63.0 noble image `bc6ab0d6d44ff4826e4cb8c1e6d801e185bfc42bb0753f8e2a30efc70db054c7`, `--ipc=host`. CI does not retain measured compiled/bundle/TGZ byte equality or runtime binary hashes. Thus source qualification, exact local24.19.0 execution and measured-artifact installation are distinct.

Job references (log lines below refer to local `job-ID.log`):

- [S20a:128851577786](https://github.com/deveshsangwan/html-inbox/actions/runs/42520123188/job/128851577786), [S20b:128851577945](https://github.com/deveshsangwan/html-inbox/actions/runs/42520123188/job/128851577945): Ubuntu source shards1/2,2/2; build24.22.2 → test20.20.2.
- [S24a:128851577996](https://github.com/deveshsangwan/html-inbox/actions/runs/42520123188/job/128851577996), [S24b:128851577910](https://github.com/deveshsangwan/html-inbox/actions/runs/42520123188/job/128851577910): Ubuntu source shards1/2,2/2; build/test24.22.2.
- [K20:128851577752](https://github.com/deveshsangwan/html-inbox/actions/runs/42520123188/job/128851577752), [K24:128851577914](https://github.com/deveshsangwan/html-inbox/actions/runs/42520123188/job/128851577914): Ubuntu Skills20.20.2/24.22.2.
- [B20:128851577886](https://github.com/deveshsangwan/html-inbox/actions/runs/42520123188/job/128851577886), [B24:128851577952](https://github.com/deveshsangwan/html-inbox/actions/runs/42520123188/job/128851577952): container Browser, build24.22.2 → test20.20.2/24.22.2.

**L3** means accepted integrated ecffd focused controls on BOTH exact20.20.2/24.19.0:18 baseline,44 actual-view,1 GC,18 export/source,4 origin,11 owned/stub cases per runtime. All335 reusable inputs,400 candidate/392 b249 files, bundles and recorded runtime/tool hashes still match accepted pins (`identity-assessment.json`). L3 is not a full-unit or real-browser pass. **P** marks an unrun broad24.19.0 invocation: proposed normal source coverage uses hosted24.22.2 plus exact24.19.0 affected controls, subject to root acceptance. No full24.19.0 matrix is claimed or silently substituted. The21 intents below are10 per runtime plus Python once; command keys specify exact argv after the selected `node`.

```text
C1 scripts/run-unit-tests.mjs --test-shard=1/2
C2 scripts/run-unit-tests.mjs --test-shard=2/2
C3 --test packages/cli/dist/managed-view-retention-check.js
C4 --test scripts/viewer-systemd-cleanup.test.mjs scripts/run-unit-tests.test.mjs scripts/release-policy.test.mjs
C5 --test scripts/skill-cli-resolution.test.mjs scripts/skill-cli-windows.test.mjs
C6 scripts/package-smoke.mjs [TGZ: local intent only; hosted omits it]
C7 scripts/skill-cli-package-smoke.mjs
C8 scripts/run-browser-tests.mjs
C9 scripts/verify-site.mjs
C10 --test scripts/site-theme.test.mjs
C11 python3 -m unittest discover -s scripts/bench -p 'test_*.py'
```

| Intended gate | Hosted exact command key, step / raw lines / result | Accepted local evidence | Remaining gap / smallest action |
| --- | --- | --- | --- |
| 20.20.2 unit1 | C1; S20a step10 /197–4284 /730 pass,2 skip | L3 affected controls; local full shard -15/incomplete | Normal source pass; retain local stop. No repeat solely for timeout. |
| 20.20.2 unit2 | C2; S20b step10 /191–3659 /602 pass | L3 affected controls; full local unrun | Normal source pass; measured compiled-byte identity not proved by CI. |
| 20.20.2 GC | C3; S20a step11 /4285–4307 /1 pass | L3 exact-runtime1 case + wrapper pass | Covered affected lifetime gate; no repeat. |
| 20.20.2 harness | C4; S20a step12 /4308–4396 /15 pass | Local full unrun | Normal source pass; no repeat. |
| 20.20.2 Skills | C5; K20 step5 /141–554 /78 pass,2 skip | Local unrun | Normal resolver pass; native skips retained. |
| 20.20.2 measured TGZ | C6 WITHOUT TGZ; S20a step13 /4397–4402 /installed lifecycle/export/delete success | Measured bundle operation passed; pack reproduced bytes; TGZ not installed | A: exact supplied-TGZ smoke300s. Different hosted package is insufficient. |
| 20.20.2 npm fallback | C7; K20 step6 /555–586 /explicit OK | Local unrun | Normal resolver pass for published0.5.0, not candidate0.6.1. |
| 20.20.2 real Browser | C8; B20 step10 /266–815 /81 pass,1 skip | L3 stub-browser + real-listener controls only | Normal real-browser source pass; local host/browser bytes differ. |
| 20.20.2 site | C9; S20a step15 /4403–4484 /15 pages | Local unrun | Normal source pass; no repeat. |
| 20.20.2 theme | C10; same successful combined step /9 pass | Local unrun | Normal source pass; no repeat. |
| 24.19.0 unit1 | C1; S24a step10 /193–5010 /730 pass,2 skip at24.22.2 | L3 affected controls; full24.19 unrun | P; no claim of full24.19 coverage. |
| 24.19.0 unit2 | C2; S24b step10 /188–4258 /602 pass at24.22.2 | L3 affected controls; full24.19 unrun | P; no claim of full24.19 coverage. |
| 24.19.0 GC | C3; S24a step11 /5011–5045 /1 pass at24.22.2 | L3 exact24.19.0:1 case + wrapper pass | Affected exact-runtime lifetime gate covered. |
| 24.19.0 harness | C4; S24a step12 /5046–5072 /15 pass at24.22.2 | Exact24.19 full invocation unrun | P; normal source gate passed. |
| 24.19.0 Skills | C5; K24 step5 /137–233 /78 pass,2 skip at24.22.2 | Exact24.19 invocation unrun | P; native skips retained. |
| 24.19.0 measured TGZ | C6 WITHOUT TGZ; S24a step13 /5073–5078 /installed lifecycle/export/delete success at24.22.2 | Exact24.19 pack0 +400 measured bytes reproduced; TGZ not installed | A: supplied-TGZ smoke300s on24.19.0. |
| 24.19.0 npm fallback | C7; K24 step6 /234–265 /explicit OK at24.22.2 | Exact24.19 invocation unrun | P; published0.5.0 distinct from candidate. |
| 24.19.0 real Browser | C8; B24 step10 /262–481 /81 pass,1 skip at24.22.2 | L3 stub-browser + real-listener controls only | P; real browser is proved in CI, not locally on24.19.0. |
| 24.19.0 site | C9; S24a step15 /5088–5131 /15 pages at24.22.2 | Exact24.19 invocation unrun | P; normal source/site gate passed. |
| 24.19.0 theme | C10; same successful combined step /9 pass at24.22.2 | Exact24.19 invocation unrun | P; normal source/theme gate passed. |
| Python once | C11; S24a step14 /5079–5087 /16 tests,OK | Earlier parser/identity/comparator subsets have separate receipts | Normal discovery passed. Hosted Python version/hash unlogged; no exact local-Python criterion. |

Actual-view44 appears once in each normal shard2; GC is separate. Linux unit skips are optional untouched b843 old-viewer fixture (not supplied) and native Windows taskkill. Browser skips optional LIVE_CDN upstream checks (`HTML_INBOX_LIVE_CDN=1` absent); Skills skips two native PowerShell cases. Native Windows/macOS successes are separate metadata evidence; macOS24 remains excluded. These expected skips stay visible. Actual-view and GC probe wrappers are POSIX-scoped; native Windows green is not those probes passing on Windows. No actual host-systemd gate or ignored controller is in normal Verify.

The original local shard remains **-15/incomplete**,20 later invocations unrun:490 top-level ok includes1 SKIP,81 nested ok overlaps, no final TAP plan/summary. First boundary was300s, not exhaustion of4500s. Five controller SIGTERMs/83 adopted exits remain interventions, not test verdicts. Root audit SHA `57d0e5398bbaf3a45b576558834f147ab1765a57d394a5e2b0e104c666131022` is unchanged. All four retained roots stay untouched. Hosted green explains neither this stop nor historical lock-OPEN EPERM, pre-admission LENGTH0, navigation, marker/cleanup or other shared observations; root owns those dispositions.

## A — measured-artifact installation proposal

Only **two supplied-TGZ package smokes plus two15s versions**, original300s smoke caps, sum630s; one750s application clock including audits plus fixed120s cleanup. No repeat pack/build/typecheck or broad suites. Exact argv/cwd/caps are in `proposed-commands.json`, a data proposal, not an executable controller. Reuse existing reviewed ownership/installed-package inspection primitives after root binds the scope; no new generic runner/hook.

N20 = `/home/agent/.local/share/fnm/node-versions/v20.20.2/installation/bin/node`, SHA `6295488653f0d93b0a157841746fef7e72cc4328cfb60c4bbe0ca2668a836ffd`.
N24 = `/home/agent/.local/share/fnm/node-versions/v24.19.0/installation/bin/node`, SHA `bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12`.
Cwd is the candidate worktree; ordered commands:

```text
N20 --version
N24 --version
N20 scripts/package-smoke.mjs /home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/full-qualification-freeze-attempt1/package-artifact/html-inbox-0.6.1.tgz
N24 scripts/package-smoke.mjs /home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/full-qualification-freeze-attempt1/package-artifact/html-inbox-0.6.1.tgz
```

TGZ260070bytes/SHA `b7e5a45f0204cba70e41cdbaf640218f47ef6e20453609326b2000b84422bfdb`; four members rehashed in `retained-package-readonly.json`. Its bundle1283240bytes/SHA `7f8fa149cb7233b41cd1671089bcb76ac15ebdd2fb3323ce64a40ca644b70509` equals measured/current bytes. Absolute TGZ uses script lines25–43's existing no-pack branch; normal isolated npm installation and foreground/detached/content/export/delete/shutdown assertions remain. Prior pack receipt stays stopped/incomplete despite accepted bounded artifact reuse.

Use ABSENT `artifacts/issue-96/measured-package-c77ace3-proposed1`, fresh private per-command HOME/TMPDIR/XDG/catalog/npm-cache and runtime-first PATH, original sanitized env/fixed registry/deadlines. Requires later listener/detached-viewer/isolated-install authority. Reuse package/401-file backup read-only; record installed four-member/runtime identity through the existing inspector. Missing sample is fail-stop instrumentation uncertainty. Capture outputs, primary script cleanup and exact owned/adopted identities/groups; no general filesystem capture or archival of private ledgers/keys/tokens. Compare source/ref/index/build/bundle/tool pins, join before disposal; preserve unjoined/residual roots, release before packaging. No historical housekeeping.

P is an explicit decision point: recommend normal20/24 source qualification plus accepted exact24.19.0 affected controls and A, rather than broad reruns solely for the extra controller stop. If root requires a particular still-unproven24.19.0 behavior, use that original command/cap (unit300,harness120,Skills120,fallback300,browser300,site30,theme60), without automatic matrix repetition or bound increase. Full broad24.19.0 qualification is currently unproven. Historical typecheck reuse retains missing retrospective transitive-declaration/tool-library hashes; fresh inventories do not repair them.

## B — combined stack versus original610

The contract separately requires this comparison before recommending integration. Accepted c491/b249 paired evidence isolates96 against its immediate parent; it is not combined96+120 versus610. Historical610 one-record smoke supplies no seven-pair100-record combined gain. This criterion remains open.

Read-only prerequisites PASS now: `/home/agent/.t3/worktrees/html-inbox/perf-89-bench` clean at **610c931b7b22920cce59cf03e49c0de15ebaf2a2**. All477 tracked hashes and195 runtime JS match preserved76 build receipt; exact24.19.0 base-build/base-bundle both exited0. JS aggregate `aa190f42b28b38c01bf03b0273a8e4649e07ebe42c3bb00ad50ffb14de826013`; release bundle1275572bytes/SHA `a6fa54ab38173962a4f77134821b6b1938984533d9e78568af0139807ce1b535`. Current390-file map saved; no historical declaration-byte proof invented from195JS. Required parse5@7.3.0/parse-srcset@1.0.2 files exist, without a fresh load claim. The76 /proc parser evidence remains INVALID; accepted reuse concerns successful build identities. Corrected084/0575 one-record evidence remains separate. No parent mutation occurred.

Request root acceptance/reservation of these existing610 runtime bytes READ-ONLY, current400 candidate files/bundle/335 inputs and exact binaries/tools. Baseline and b249 outputs remain read-only. Recheck clean HEAD/ref/index and maps at admission/postflight; no new checkout/build/install is presently necessary. If provenance is declined or inputs change, stop before execution and coordinate only necessary artifact preparation; no implicit rebuild.

Use the EXISTING unchanged runner/companions and paired auditor; bind only head/baseline/output identities. Counts1/100, bodies10240, seven alternating AB/BA pairs, concurrency1, each runtime independently. Two15s versions plus two420s invocations, sum870s; one900s application clock including audits plus fixed120s cleanup, as previously used. Exact proposed commands:

```text
N20 --version
N24 --version
/usr/bin/python3 scripts/bench/run.py managed-read --baseline-repo /home/agent/.t3/worktrees/html-inbox/perf-89-bench --expected-baseline-commit 610c931b7b22920cce59cf03e49c0de15ebaf2a2 --node /home/agent/.local/share/fnm/node-versions/v20.20.2/installation/bin/node --counts 1,100 --sizes 10240 --samples 7 --timeout 30 --out /home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/combined-610-c77ace3-proposed1/node20
/usr/bin/python3 scripts/bench/run.py managed-read --baseline-repo /home/agent/.t3/worktrees/html-inbox/perf-89-bench --expected-baseline-commit 610c931b7b22920cce59cf03e49c0de15ebaf2a2 --node /home/agent/.local/share/fnm/node-versions/v24.19.0/installation/bin/node --counts 1,100 --sizes 10240 --samples 7 --timeout 30 --out /home/agent/.t3/worktrees/html-inbox/perf-96-snapshot/artifacts/issue-96/combined-610-c77ace3-proposed1/node24
```

Both proposed roots are absent. Reuse c491's environment/owned-child path, real untimed enrollment, complete validation, fresh outputs and100ms /proc-only outer sampling (no hot fixture traversal). Primary COMPLETE release-bundle CLI process elapsed; actual callback batch/CPU/RSS supporting, instrumented I/O separate. Per runtime79 child rows (42 count1 including sole mixed fixture +37 count100),38 trees,14 pairs,8 profiles; totals158/76/28/16. Audit every count/pair/role/output identity, full bytes/manifests/diagnostics and named CLI owner/time/outputDir differences. Independently reparse all raw seven-field counters/native bounds, retain live-stat assertions and derived size consistency without constants. Recompute raw pairs, absolute/relative median/min/max/spread, count1 regressions, memory and bundle costs. No high counts/bodies, pooled runtimes, p95/cold-cache claims or gain-based stop. Full per-body ledger I/O remains the partial limitation.

Admit only when a full unchanged command cap fits the one absolute clock; stop first behavior/audit/provenance/cleanup failure, preserve originals/partial/unrun list, no retry/oracle change. Join/reap/check exact-owned identities before fixtures and explicitly release before packaging. If root declines/unqualifies610 comparison, retain a narrower draft partial96 scoped benefit versus b249 and withhold combined integration recommendation. Do not close96, waive shared gates, or imply fresh same-pin reviews occurred. No runtime or review is authorized by this assessment.
