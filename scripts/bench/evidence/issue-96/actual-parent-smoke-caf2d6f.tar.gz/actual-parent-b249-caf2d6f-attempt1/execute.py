import ctypes
import argparse
import re
import stat
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
NODE24 = Path('/home/agent/.local/share/fnm/node-versions/v24.19.0/installation/bin/node')
NODE20 = Path('/home/agent/.local/share/fnm/node-versions/v20.20.2/installation/bin/node')
PNPM = NODE24.parent.parent / 'lib/node_modules/corepack/dist/pnpm.js'
parser = argparse.ArgumentParser()
parser.add_argument('--expected-head', required=True)
parser.add_argument('--grant', required=True)
options = parser.parse_args()
if not re.fullmatch(r'[0-9a-fA-F]{40}', options.expected_head):
    parser.error('--expected-head requires a full40-hex immutable pin')
EXPECTED = options.expected_head.lower()
PRIOR = REPO/'artifacts/issue-96/integrated-correctness-44ef6c0-attempt1'
ORIGINAL = json.loads((PRIOR/'receipt.json').read_text())
BUILD_PRIOR = REPO/'artifacts/issue-96/integrated-correctness-79a2912-continuation1'
BUILD_RECEIPT_SHA256 = '8038412626e8e667cfeb9e994ac7eef359310b93f5a0db3d22551f9bb4130e59'
BUILD = json.loads((BUILD_PRIOR/'receipt.json').read_text())
QUAL_PRIOR = REPO/'artifacts/issue-96/integrated-correctness-tests-ecffd-attempt1'
QUAL = json.loads((QUAL_PRIOR/'receipt.json').read_text())
QUAL_SHA256 = '68d2d43404ad5cc41ec8e7dad5eace6cfb4aa725aed2d45da0b81769cda0b338'
RESERVATION_SHA256 = 'f21101e2a32ead8cd1805585a4b29ba7945f274d773b8a76c73551f4394b2143'
BASE = Path('/home/agent/.t3/worktrees/html-inbox/t3-26d1cd47')
PARENT = 'b24927abf4cae14c9bbf1753ff6ea2cfb7a945ad'
APP_BUDGET = 900
CLEANUP_ALLOWANCE = 120
commands = []
app_started = None
app_deadline = None
hard_deadline = None
cleanup_used = 0.0
receipt = {'head': EXPECTED, 'base': PARENT, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'application_budget_seconds': APP_BUDGET, 'separate_cleanup_allowance_seconds': CLEANUP_ALLOWANCE, 'commands': commands, 'grant': options.grant}
assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0

def save():
    receipt['cleanup_used_seconds'] = cleanup_used
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def tracked(repo=REPO):
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0')
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in names if name and (repo / name).is_file()}

def compiled(repo=REPO):
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((repo / 'packages/cli/dist').rglob('*.js'))}

def own_children():
    filename = Path(f'/proc/self/task/{os.getpid()}/children')
    return [int(value) for value in filename.read_text().split()]

def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False

def drain_group(record):
    global cleanup_used
    started = time.monotonic()
    deadline = min(hard_deadline, started + max(0, CLEANUP_ALLOWANCE - cleanup_used))
    record['cleanup_absolute_deadline_monotonic'] = deadline
    reaped = []
    actions = []
    for child_pid in own_children():
        try:
            os.kill(child_pid, signal.SIGTERM)
            actions.append({'pid': child_pid, 'signal': 'SIGTERM'})
        except ProcessLookupError:
            pass
    if group_exists(record['pgid']):
        os.killpg(record['pgid'], signal.SIGTERM)
        actions.append({'pgid': record['pgid'], 'signal': 'SIGTERM'})
    while True:
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if pid == 0:
                break
            reaped.append({'pid': pid, 'status': status})
        children = own_children()
        live_group = group_exists(record['pgid'])
        if not children and not live_group:
            break
        if time.monotonic() >= deadline:
            raise RuntimeError('Cleanup allowance exhausted; preserve fixtures')
        if time.monotonic() - started >= 1:
            if live_group:
                os.killpg(record['pgid'], signal.SIGKILL)
            for pid in children:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        time.sleep(min(0.01, max(0, deadline-time.monotonic())))
    cleanup_used += time.monotonic() - started
    record['cleanup'] = {'group_absent': True, 'children_remaining': [], 'adopted_reaped': reaped, 'signals': actions, 'seconds': time.monotonic() - started}

def observe_tree(record):
    found = set([record['pid'], *own_children()])
    table = {}
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().split(') ', 1)[1].split()
            table[int(proc.name)] = dict(ppid=int(fields[1]), pgid=int(fields[2]), start=fields[19], state=fields[0])
        except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, IndexError):
            pass
    previous = None
    while previous != len(found):
        previous = len(found)
        found.update(pid for pid, info in table.items() if info['ppid'] in found)
    for pid in found:
        if pid in table:
            record.setdefault('observed_processes', {})[str(pid)] = table[pid]



def file_map(directory, repo=REPO):
    return {str(p.relative_to(repo)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(directory.rglob('*')) if p.is_file()}

def aggregate(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def directory_metadata(directory):
    return [{'path': str(p.relative_to(directory)), 'mode': p.lstat().st_mode, 'uid': p.lstat().st_uid,
             'size': p.lstat().st_size} for p in sorted(directory.rglob('*'))]

def dispose_tool_output(record, owned):
    commands_by_label = {
        'candidate-bundle': ([str(NODE24), str(PNPM), '--filter', 'html-inbox', 'bundle'], str(REPO)),
        'base-build': ([str(NODE24), str(PNPM), 'build'], str(BASE)),
        'base-bundle': ([str(NODE24), str(PNPM), '--filter', 'html-inbox', 'bundle'], str(BASE)),
    }
    expected = commands_by_label.get(record['label'])
    if expected is None:
        return False
    if expected != (record['command'], record['cwd']):
        raise RuntimeError('Tool command/cwd identity mismatch; preserve roots')
    if own_children() or any(record['observed_groups_after_drain'].values()):
        raise RuntimeError('Tool output disposal requires joined owned work')

    root = owned.lstat()
    identity = {'dev': root.st_dev, 'ino': root.st_ino, 'uid': root.st_uid, 'mode': stat.S_IMODE(root.st_mode)}
    if not stat.S_ISDIR(root.st_mode) or identity != record['owned_tmpdir_identity'] or root.st_uid != os.getuid() or identity['mode'] != 0o700:
        raise RuntimeError('Tool output root identity/private ownership changed')

    inventory = {}
    for directory, directories, files in os.walk(owned, followlinks=False):
        for name in sorted([*directories, *files]):
            filename = Path(directory)/name
            info = filename.lstat()
            item = {'uid': info.st_uid, 'gid': info.st_gid, 'mode': info.st_mode, 'nlink': info.st_nlink,
                    'bytes': info.st_size, 'dev': info.st_dev, 'ino': info.st_ino}
            if stat.S_ISREG(info.st_mode):
                fd = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW)
                try:
                    opened = os.fstat(fd)
                    assert (opened.st_dev, opened.st_ino) == (info.st_dev, info.st_ino)
                    with os.fdopen(fd, 'rb', closefd=False) as stream:
                        item['sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
                finally:
                    os.close(fd)
            elif stat.S_ISLNK(info.st_mode):
                item['link_text_not_followed'] = os.readlink(filename)
            inventory[str(filename.relative_to(owned))] = item

    record['tool_output_inventory_after_join'] = inventory
    save()
    current = owned.lstat()
    assert (current.st_dev, current.st_ino, current.st_uid, stat.S_IMODE(current.st_mode)) == (identity['dev'], identity['ino'], identity['uid'], 0o700)
    assert time.monotonic() < hard_deadline and cleanup_used < CLEANUP_ALLOWANCE
    assert shutil.rmtree.avoids_symlink_attacks
    shutil.rmtree(owned)
    assert not owned.exists()
    record['tool_output_root_removed_after_join'] = True
    return True

def postflight(record, owned, home, evidence):
    groups = {record['pgid'], *(info['pgid'] for info in record.get('observed_processes', {}).values())}
    record['observed_groups_after_drain'] = {str(group): group_exists(group) for group in groups}
    assert not any(record['observed_groups_after_drain'].values()), 'Observed owned group remains; preserve roots'
    captures = [json.loads(line) for p in sorted(evidence.glob('teardown-*.jsonl')) for line in p.read_text().splitlines()]
    for capture in captures:
        assert not capture.get('captureError') and not capture.get('cleanupError') and capture.get('removalCompleted'), capture
        assert not Path(capture['fixture']).exists(), 'Observed fixture remains'
        destination = evidence / f"fixture-{capture['pid']}-{capture['sequence']:02d}"
        for output in capture['outputs']:
            for item in output['files']:
                data = (destination/output['name']/item['path']).read_bytes()
                assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    record['output_capture'] = {'fixtures': len(captures), 'files': sum(len(output['files']) for c in captures for output in c['outputs']),
                                'shapes': {shape: sum(c['shape']==shape for c in captures) for shape in sorted({c['shape'] for c in captures})}}
    text = (ROOT/(record['label']+'.stdout.log')).read_text() + (ROOT/(record['label']+'.stderr.log')).read_text()
    import re
    diagnostic_roots = re.findall(r'"fixtureRoot":"([^"\n]+)"', text)
    record['diagnostic_fixture_roots'] = diagnostic_roots
    assert all(not Path(p).exists() for p in diagnostic_roots), 'Wrapper fixture root remains'
    is_tool_output = dispose_tool_output(record, owned)
    record['remaining_tmp_entries'] = [] if is_tool_output else directory_metadata(owned)
    record['synthetic_home_entries'] = directory_metadata(home)
    if record['remaining_tmp_entries']:
        raise RuntimeError('Unexpected synthetic fixture remains after joined groups; preserve roots')
    if not is_tool_output:
        owned.rmdir()
    shutil.rmtree(home)
    record['owned_tmpdir_absent'] = not owned.exists()
    record['isolated_home_absent'] = not home.exists()

def run(label, command, timeout, observed=False, cwd=REPO):
    global app_started, app_deadline, hard_deadline, cleanup_used
    if app_started is None:
        app_started = time.monotonic()
        app_deadline = app_started + APP_BUDGET
        hard_deadline = app_deadline + CLEANUP_ALLOWANCE
        receipt['application_absolute_deadline_monotonic'] = app_deadline
        receipt['hard_absolute_deadline_monotonic'] = hard_deadline
    remaining = app_deadline-time.monotonic()
    if remaining < timeout:
        raise RuntimeError('Insufficient remaining aggregate budget for full command scope: '+label)
    owned = ROOT/(label+'-tmp')
    home = ROOT/(label+'-home')
    evidence = ROOT/(label+'-outputs')
    for directory in [owned, home, evidence]: directory.mkdir(mode=0o700)
    (home/'catalog').mkdir(mode=0o700)
    env = {'PATH': str(NODE24.parent)+os.pathsep+os.environ['PATH'], 'LANG':'C.UTF-8', 'LC_ALL':'C.UTF-8', 'TZ':'UTC',
           'HOME':str(home), 'TMPDIR':str(owned), 'XDG_CONFIG_HOME':str(home/'config'), 'XDG_STATE_HOME':str(home/'state'),
           'XDG_DATA_HOME':str(home/'data'), 'HTML_INBOX_CATALOG_HOME':str(home/'catalog'),
           'COREPACK_HOME':'/home/agent/.cache/node/corepack', 'COREPACK_ENABLE_NETWORK':'0', 'COREPACK_ENABLE_AUTO_PIN':'0',
           'COREPACK_ENABLE_DOWNLOAD_PROMPT':'0'}
    if observed:
        env.update(HTML_INBOX_CONTRACT_EVIDENCE=str(evidence), NODE_OPTIONS='--require='+str(OBSERVER))
    record = {'label':label, 'command':list(map(str,command)), 'cwd':str(cwd), 'environment':env, 'limit_seconds':timeout,
              'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pre_spawn_catalog_empty':not any((home/'catalog').iterdir()),
              'observation_overhead':bool(observed), 'isolated_home':str(home), 'isolated_tmpdir':str(owned)}
    root_identity = owned.lstat()
    record['owned_tmpdir_identity'] = {'dev': root_identity.st_dev, 'ino': root_identity.st_ino, 'uid': root_identity.st_uid, 'mode': stat.S_IMODE(root_identity.st_mode)}
    assert stat.S_ISDIR(root_identity.st_mode) and root_identity.st_uid==os.getuid() and stat.S_IMODE(root_identity.st_mode)==0o700
    commands.append(record)
    print('START '+label, flush=True)
    started = time.monotonic()
    command_deadline = min(app_deadline,started+timeout)
    record['absolute_deadline_monotonic'] = command_deadline
    with (ROOT/(label+'.stdout.log')).open('wb') as stdout, (ROOT/(label+'.stderr.log')).open('wb') as stderr:
        child = subprocess.Popen(command,cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        record.update(pid=child.pid,pgid=child.pid)
        record['proc_start'] = Path(f'/proc/{child.pid}/stat').read_text().split(') ',1)[1].split()[19]
        save()
        try:
            while child.poll() is None:
                observe_tree(record)
                record['observed_fixture_directories'] = sorted(set(record.get('observed_fixture_directories',[])) |
                    {str(p) for p in owned.rglob('*') if p.is_dir() and p.name.startswith('html-inbox-')})
                if time.monotonic() >= command_deadline:
                    raise subprocess.TimeoutExpired(command,timeout)
                time.sleep(min(0.02,max(0,command_deadline-time.monotonic())))
            record['exit_code'] = child.wait()
            observe_tree(record)
        except subprocess.TimeoutExpired:
            record['timed_out'] = True
            os.killpg(child.pid,signal.SIGKILL)
            cleanup_started = time.monotonic()
            until = min(hard_deadline,cleanup_started+max(0,CLEANUP_ALLOWANCE-cleanup_used))
            try: record['exit_code'] = child.wait(timeout=max(0,until-time.monotonic()))
            finally: cleanup_used += time.monotonic()-cleanup_started
        record['application_elapsed_seconds'] = time.monotonic()-started
    drain_group(record)
    cleanup_started=time.monotonic()
    try:
        assert cleanup_started < hard_deadline and cleanup_used < CLEANUP_ALLOWANCE
        postflight(record,owned,home,evidence)
    finally: cleanup_used += time.monotonic()-cleanup_started
    record['source_unchanged'] = tracked()==receipt['source_before']
    record['git_head_unchanged'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==EXPECTED
    record['git_clean'] = not subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)
    if 'compiled_candidate_full' in receipt:
        record['compiled_unchanged'] = file_map(REPO/'packages/cli/dist')==receipt['compiled_candidate_full']
    record['base_source_unchanged'] = tracked(BASE)==receipt['base_source_before']
    record['base_head_unchanged'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()==PARENT
    record['base_clean'] = not subprocess.check_output(['git','status','--porcelain=v1'],cwd=BASE,text=True)
    if 'base_compiled_candidate_full' in receipt:
        record['base_compiled_unchanged'] = file_map(BASE/'packages/cli/dist',BASE)==receipt['base_compiled_candidate_full']
    if 'bundles_candidate' in receipt:
        record['bundles_unchanged'] = {str(repo):file_map(repo/'packages/cli/bundle',repo) for repo in [REPO,BASE]}==receipt['bundles_candidate']
    save()
    print('END '+label+' exit='+str(record['exit_code']),flush=True)
    assert record['exit_code']==0 and not record.get('timed_out') and record['source_unchanged'] and record['git_head_unchanged'] and record['git_clean'] and record.get('compiled_unchanged',True) and record['base_source_unchanged'] and record['base_head_unchanged'] and record['base_clean'] and record.get('base_compiled_unchanged',True) and record.get('bundles_unchanged',True), 'STOP first failed command/pin: '+label

OBSERVER=REPO/'artifacts/issue-96/correctness-fc858a5-attempt1/capture-outputs.cjs'
try:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==EXPECTED
    assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)
    assert subprocess.check_output(['git','merge-base','HEAD',PARENT],cwd=REPO,text=True).strip()==PARENT
    assert (REPO/'node_modules').is_dir()
    assert hashlib.sha256((PRIOR/'receipt.json').read_bytes()).hexdigest()=='86830f723a0970c4c2ed68f05bc2e6868aa4ea88b163b2e22a64be07037b4823', 'Original stopped receipt changed'
    receipt['source_before']=tracked()
    reusable_names = {name for name in set(ORIGINAL['source_after']) | set(receipt['source_before'])
                      if not name.startswith(('docs/', 'scripts/bench/evidence/')) or name.endswith(('.ts', '.tsx', '.mts', '.cts'))}
    assert all(receipt['source_before'].get(name)==ORIGINAL['source_after'].get(name) for name in reusable_names), 'Typecheck inputs/executable source changed'
    receipt['reused_typecheck'] = {'tested_head': ORIGINAL['head'], 'original_receipt_sha256': hashlib.sha256((PRIOR/'receipt.json').read_bytes()).hexdigest(),
        'unchanged_source_inputs': {name: receipt['source_before'][name] for name in sorted(reusable_names)},
        'note': 'All tracked non-documentation/evidence inputs, every tracked TS file, and original recorded compiler/tool hashes must match. Installed declaration dependency hashes were not retained at the earlier typecheck; they cannot be independently reconstructed retrospectively.'}
    assert hashlib.sha256((BUILD_PRIOR/'receipt.json').read_bytes()).hexdigest()==BUILD_RECEIPT_SHA256, 'Successful build receipt changed'
    assert BUILD['head']=='79a2912864044f310401f2ee8a0a6c1bdd390997' and BUILD['base']==PARENT
    assert [(item['label'],item['exit_code']) for item in BUILD['commands']]==[('node20-version',0),('node24-version',0),('build',0)]
    assert BUILD['result']=='stopped' and BUILD['error']=="RuntimeError('Unsafe tool cache ownership/permissions; preserve roots')"
    assert all(receipt['source_before'].get(name)==BUILD['source_after'].get(name) for name in reusable_names), 'Executable source changed since successful build'
    receipt['compiled_candidate']=compiled()
    receipt['compiled_candidate_full']=file_map(REPO/'packages/cli/dist')
    assert receipt['compiled_candidate_full']==BUILD['compiled_after_full'], 'Successful build outputs changed'
    receipt['bundle_before_full']=file_map(REPO/'packages/cli/bundle')
    assert receipt['bundle_before_full']==BUILD['bundle_after_full'], 'Unqualified bundle changed'
    receipt['reused_build']={'tested_head':BUILD['head'],'receipt_sha256':BUILD_RECEIPT_SHA256,'compiled_files':len(receipt['compiled_candidate_full']),
        'classification':'Successful exact24 build reused; later ecffd scoped correctness accepted. Historical cache stops/bytes remain archived; exact disposed roots subsequently removed under separate housekeeping authority.'}
    receipt['runtime_hashes']={str(n):hashlib.sha256(n.read_bytes()).hexdigest() for n in [NODE20,NODE24]}
    assert list(receipt['runtime_hashes'].values())==['6295488653f0d93b0a157841746fef7e72cc4328cfb60c4bbe0ca2668a836ffd','bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12']
    pnpm_package=Path('/home/agent/.cache/node/corepack/v1/pnpm/11.7.0/package.json')
    assert json.loads(pnpm_package.read_text())['version']=='11.7.0'
    tool_paths=[PNPM,REPO/'pnpm-lock.yaml',REPO/'package.json',REPO/'packages/cli/package.json',REPO/'node_modules/.bin/tsc-rs',REPO/'node_modules/tsc-rs/package.json',pnpm_package]
    tool_paths += [p for p in (REPO/'node_modules/.pnpm').glob('@tsc-rs+linux-x64@*/node_modules/@tsc-rs/linux-x64/lib/tsc')]
    assert len(tool_paths)==8,'Expected exact native compiler file'
    receipt['tool_files']={str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in tool_paths}
    assert receipt['tool_files']==ORIGINAL['tool_files_after'], 'Compiler/config/lock/tool inputs changed since typecheck'
    assert receipt['tool_files']==BUILD['tool_files_after'] and receipt['runtime_hashes']==BUILD['runtime_hashes_after'], 'Build/runtime identities changed'
    receipt['observer_sha256']=hashlib.sha256(OBSERVER.read_bytes()).hexdigest()
    receipt['runner_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    receipt['runner_provenance']='Source-prepared actual-b249 bundle/build/one-record request; accepted400 candidate compiled files/typecheck reuse; existing managed-read runner unchanged; owned private tool TMPDIR inventory/removal limited to3 pinned tool commands; no application empty-directory/cache-child permission oracle on tool outputs'
    receipt['observation_limits']='20ms /proc and private-directory sampling can miss shorter-lived descendants. Existing run.py owns18 sequential children per smoke; native count probes are separate instrumentation, physical I/O may be zero. No generic interruption or practical-gain claim; no teardown preload used by this outer controller.'
    assert hashlib.sha256((QUAL_PRIOR/'receipt.json').read_bytes()).hexdigest()==QUAL_SHA256, 'Accepted correctness receipt changed'
    assert QUAL['head']=='ecffd7c44b68f72532148dd296b361d192633a28' and all(c['exit_code']==0 for c in QUAL['commands']) and not QUAL['not_run']
    assert receipt['compiled_candidate_full']==QUAL['compiled_after_full'] and receipt['tool_files']==QUAL['tool_files_after']
    assert all(receipt['source_before'].get(name)==QUAL['source_after'].get(name) for name in reusable_names)
    receipt['accepted_correctness_receipt_sha256']=QUAL_SHA256
    reservation_file=ROOT/'parent-output-reservation.json'
    assert hashlib.sha256(reservation_file.read_bytes()).hexdigest()==RESERVATION_SHA256
    reservation=json.loads(reservation_file.read_text())
    assert reservation['head']==PARENT and reservation['checkout']==str(BASE)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()==PARENT
    assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=BASE,text=True)
    assert (BASE/'node_modules').is_dir()
    receipt['base_source_before']=tracked(BASE)
    receipt['base_compiled_before_full']=file_map(BASE/'packages/cli/dist',BASE)
    receipt['base_bundle_before_full']=file_map(BASE/'packages/cli/bundle',BASE)
    assert receipt['base_compiled_before_full']==reservation['generated_outputs']['packages/cli/dist']['files']
    assert receipt['base_bundle_before_full']==reservation['generated_outputs']['packages/cli/bundle']['files']
    receipt['parent_reservation_sha256']=RESERVATION_SHA256
    receipt['parent_output_note']='Presence fingerprints only before explicit authorized build/bundle; no prior runtime qualification claimed'
    extra_tools=[repo/name for repo in [REPO,BASE] for name in ['node_modules/.bin/ncc','node_modules/@vercel/ncc/package.json','node_modules/.bin/tsc-rs','node_modules/tsc-rs/package.json','pnpm-lock.yaml','package.json']]
    extra_tools += [p for p in (BASE/'node_modules/.pnpm').glob('@tsc-rs+linux-x64@*/node_modules/@tsc-rs/linux-x64/lib/tsc')]
    assert len(extra_tools)==13, 'Expected exact parent native compiler'
    receipt['bundle_parent_tool_files']={str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in extra_tools}
    receipt['auditor_sha256']=hashlib.sha256((ROOT/'audit-evidence.py').read_bytes()).hexdigest()
    receipt['planned_checks']=['candidate-bundle','base-build','base-bundle','node20-managed-smoke','node24-managed-smoke']
    save()
    run('node20-version',[NODE20,'--version'],15)
    assert (ROOT/'node20-version.stdout.log').read_text().strip()=='v20.20.2'
    run('node24-version',[NODE24,'--version'],15)
    assert (ROOT/'node24-version.stdout.log').read_text().strip()=='v24.19.0'
    run('candidate-bundle',[NODE24,PNPM,'--filter','html-inbox','bundle'],180)
    assert file_map(BASE/'packages/cli/dist',BASE)==receipt['base_compiled_before_full']
    assert file_map(BASE/'packages/cli/bundle',BASE)==receipt['base_bundle_before_full']
    run('base-build',[NODE24,PNPM,'build'],120,cwd=BASE)
    receipt['base_compiled_candidate_full']=file_map(BASE/'packages/cli/dist',BASE)
    save()
    run('base-bundle',[NODE24,PNPM,'--filter','html-inbox','bundle'],180,cwd=BASE)
    receipt['bundles_candidate']={str(repo):file_map(repo/'packages/cli/bundle',repo) for repo in [REPO,BASE]}
    save()
    import runpy
    audit=runpy.run_path(str(ROOT/'audit-evidence.py'))
    for runtime,node in [('node20',NODE20),('node24',NODE24)]:
        run(runtime+'-managed-smoke',['python3','scripts/bench/run.py','managed-read','--baseline-repo',BASE,
            '--expected-baseline-commit',PARENT,'--node',node,'--counts','1','--sizes','10240','--samples','1','--timeout','30','--out',ROOT/(runtime+'-smoke')],180)
        audit['audit_runtime'](runtime,ROOT,ROOT,EXPECTED)
        assert time.monotonic()<app_deadline, 'Application/audit deadline exhausted'
    receipt['result']='actual-b249 one-record harness smoke passed both exact runtimes; not practical-benefit qualification'

except BaseException as error:
    if commands and 'pgid' in commands[-1] and 'cleanup' not in commands[-1]:
        record=commands[-1]
        try: os.killpg(record['pgid'],signal.SIGKILL)
        except ProcessLookupError: pass
        drain_group(record)
    receipt['result']='stopped'
    receipt['error']=repr(error)
    raise
finally:
    receipt['base_source_after']=tracked(BASE)
    receipt['base_compiled_after_full']=file_map(BASE/'packages/cli/dist',BASE)
    receipt['base_bundle_after_full']=file_map(BASE/'packages/cli/bundle',BASE)
    receipt['source_after']=tracked()
    receipt['compiled_after']=compiled()
    receipt['compiled_after_full']=file_map(REPO/'packages/cli/dist')
    receipt['bundle_after_full']=file_map(REPO/'packages/cli/bundle')
    receipt['runtime_hashes_after']={str(n):hashlib.sha256(n.read_bytes()).hexdigest() for n in [NODE20,NODE24]}
    receipt['tool_files_after']={p:{'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in receipt.get('tool_files',{})}
    receipt['source_unchanged']=receipt.get('source_before')==receipt['source_after']
    receipt['bundle_changed_from_old_stale']=receipt.get('bundle_before_full')!=receipt['bundle_after_full']
    receipt['bundles_match_qualified_smoke_inputs']=receipt.get('bundles_candidate')=={str(repo):file_map(repo/'packages/cli/bundle',repo) for repo in [REPO,BASE]}
    receipt['bundle_parent_tool_files_after']={p:{'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in receipt.get('bundle_parent_tool_files',{})}
    receipt['git_status']=subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)
    receipt['application_elapsed_seconds']=time.monotonic()-app_started if app_started else 0
    receipt['application_within_deadline']=time.monotonic()<=app_deadline if app_deadline else True
    receipt['final_group_checks']={str(g):group_exists(g) for item in commands for g in {item.get('pgid',0),*(info['pgid'] for info in item.get('observed_processes',{}).values())} if g}
    receipt['owned_children_at_exit']=own_children()
    receipt['not_run']=[label for label in receipt.get('planned_checks',[]) if label not in {c['label'] for c in commands}]
    receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({k:receipt.get(k) for k in ['result','error','application_elapsed_seconds','cleanup_used_seconds','owned_children_at_exit']}),flush=True)
