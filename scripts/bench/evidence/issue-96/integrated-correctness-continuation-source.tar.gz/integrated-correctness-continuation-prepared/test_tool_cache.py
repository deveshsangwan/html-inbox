# Prepared controls only. Not run under source-only authorization.
import ast
import hashlib
import os
from pathlib import Path
import stat
import tempfile
import unittest

SOURCE = Path(__file__).with_name('execute.py')

class ToolCacheControls(unittest.TestCase):
    def setUp(self):
        tree = ast.parse(SOURCE.read_text())
        definition = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'inspect_toolchain_cache')
        self.namespace = {'hashlib': hashlib, 'os': os, 'stat': stat, 'NODE24': Path('/pinned/node24'), 'PNPM': Path('/pinned/corepack/pnpm.js')}
        exec(compile(ast.Module(body=[definition], type_ignores=[]), str(SOURCE), 'exec'), self.namespace)
        self.inspect = self.namespace['inspect_toolchain_cache']
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.build = {'label': 'build', 'command': ['/pinned/node24', '/pinned/corepack/pnpm.js', 'build']}

    def cache(self):
        cache = self.root/'node-compile-cache'
        cache.mkdir(mode=0o700)
        data = cache/'compiled'
        data.write_bytes(b'known tooling bytes')
        data.chmod(0o600)
        return cache, data

    def test_empty_joined_tmpdir_has_no_exception_for_test_command(self):
        self.assertEqual(self.inspect({'label': 'node20-baseline', 'command': []}, self.root, True), (None, {}))

    def test_only_pinned_build_cache_is_inventoried_without_removing(self):
        cache, data = self.cache()
        found, inventory = self.inspect(self.build, self.root, True)
        self.assertEqual(found, cache)
        self.assertEqual(inventory['node-compile-cache/compiled']['sha256'], hashlib.sha256(data.read_bytes()).hexdigest())
        self.assertEqual(inventory['node-compile-cache/compiled']['bytes'], len(b'known tooling bytes'))
        self.assertTrue(cache.exists())

    def test_cache_is_rejected_for_test_or_wrong_build_command(self):
        self.cache()
        for record in [{'label': 'node24-actual-ci', 'command': self.build['command']},
                       {'label': 'build', 'command': ['/other/node', '/pinned/corepack/pnpm.js', 'build']}]:
            with self.subTest(record=record), self.assertRaises(RuntimeError):
                self.inspect(record, self.root, True)

    def test_other_residue_is_rejected_even_beside_known_cache(self):
        self.cache()
        (self.root/'html-inbox-test-unremoved').mkdir()
        with self.assertRaises(RuntimeError):
            self.inspect(self.build, self.root, True)

    def test_root_symlink_and_file_are_rejected(self):
        external = tempfile.TemporaryDirectory()
        self.addCleanup(external.cleanup)
        outside = Path(external.name)
        cache = self.root/'node-compile-cache'
        cache.symlink_to(outside, target_is_directory=True)
        with self.assertRaises(RuntimeError):
            self.inspect(self.build, self.root, True)
        cache.unlink()
        cache.write_bytes(b'not a directory')
        with self.assertRaises(RuntimeError):
            self.inspect(self.build, self.root, True)

    def test_link_or_writable_cache_entry_is_rejected(self):
        cache, data = self.cache()
        linked = cache/'hardlink'
        os.link(data, linked)
        with self.assertRaises(RuntimeError):
            self.inspect(self.build, self.root, True)
        linked.unlink()
        linked.symlink_to(data)
        with self.assertRaises(RuntimeError):
            self.inspect(self.build, self.root, True)
        linked.unlink()
        data.chmod(0o666)
        with self.assertRaises(RuntimeError):
            self.inspect(self.build, self.root, True)

    def test_cache_requires_join_before_any_classification(self):
        self.cache()
        with self.assertRaises(RuntimeError):
            self.inspect(self.build, self.root, False)

if __name__ == '__main__':
    unittest.main()
