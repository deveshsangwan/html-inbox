import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
NODE24 = Path('/home/agent/.local/share/fnm/node-versions/v24.19.0/installation/bin/node')
NODE20 = Path('/home/agent/.local/share/fnm/node-versions/v20.20.2/installation/bin/node')
PNPM = NODE24.parent.parent / 'lib/node_modules/corepack/dist/pnpm.js'
EXPECTED = '42232780e567728618680073ce40bb4efa5f887b'
ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0)
commands = []
receipt = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commands': commands, 'gate': 'baseline characterization only'}

def save():
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def manifest(paths):
    result = {}
    for filename in paths:
        result[str(filename.relative_to(REPO))] = hashlib.sha256(filename.read_bytes()).hexdigest()
    return result

def source_manifest():
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).decode().split('\0')
    return manifest([REPO / name for name in tracked if name and (REPO / name).is_file()])

def run(label, command, env, timeout=180):
    record = {'label': label, 'command': list(map(str, command)), 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    commands.append(record)
    print('START ' + label, flush=True)
    started = time.monotonic()
    with (ROOT / f'{label}.stdout.log').open('wb') as stdout, (ROOT / f'{label}.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=REPO, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        record['pid'] = child.pid
        try:
            record['exit_code'] = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            record['timed_out'] = True
            os.killpg(child.pid, signal.SIGKILL)
            record['exit_code'] = child.wait()
        record['elapsed_seconds'] = time.monotonic() - started
        try:
            os.killpg(child.pid, 0)
        except ProcessLookupError:
            record['process_group_absent'] = True
        else:
            record['process_group_absent'] = False
            os.killpg(child.pid, signal.SIGKILL)
    adopted = []
    while True:
        try:
            pid, status = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            break
        if pid == 0:
            raise RuntimeError('Owned child remains running after command')
        adopted.append({'pid': pid, 'status': status})
    record['adopted_children_reaped'] = adopted
    save()
    print('END ' + label + ' exit=' + str(record['exit_code']), flush=True)
    if record['exit_code'] or not record['process_group_absent']:
        raise RuntimeError('Stop after failed command: ' + label)

try:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == EXPECTED
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
    receipt['head'] = EXPECTED
    receipt['base'] = '610c931b7b22920cce59cf03e49c0de15ebaf2a2'
    receipt['source_before'] = source_manifest()
    receipt['runtime_hashes'] = {str(node): hashlib.sha256(node.read_bytes()).hexdigest() for node in [NODE20, NODE24]}
    env = {key: value for key, value in os.environ.items() if not key.startswith('HTML_INBOX_') and key not in ['NODE_OPTIONS', 'NODE_TEST_CONTEXT']}
    env['PATH'] = str(NODE24.parent) + os.pathsep + env['PATH']
    run('node24-version', [NODE24, '--version'], env)
    run('node20-version', [NODE20, '--version'], env)
    assert (ROOT / 'node24-version.stdout.log').read_text().strip() == 'v24.19.0'
    assert (ROOT / 'node20-version.stdout.log').read_text().strip() == 'v20.20.2'
    if not (REPO / 'node_modules').exists():
        run('install-frozen', [NODE24, PNPM, 'install', '--frozen-lockfile'], env, 300)
    run('typecheck', [NODE24, PNPM, 'typecheck'], env)
    run('build', [NODE24, PNPM, 'build'], env)
    compiled = manifest(sorted((REPO / 'packages/cli/dist').rglob('*.js')))
    assert compiled
    receipt['compiled_before_tests'] = compiled
    save()
    for name, node in [('node20-probe', NODE20), ('node24-probe', NODE24)]:
        owned = ROOT / (name + '-tmp')
        evidence = ROOT / (name + '-exports')
        owned.mkdir(mode=0o700)
        evidence.mkdir(mode=0o700)
        probe_env = dict(env, TMPDIR=str(owned), HTML_INBOX_CONTRACT_EVIDENCE=str(evidence), NODE_OPTIONS='--require=' + str(ROOT / 'capture-exports.cjs'))
        try:
            run(name, [node, '--test', 'scripts/bench/managed-read-contract.cjs'], probe_env)
        finally:
            captures = [json.loads(line) for line in (evidence / 'teardown.jsonl').read_text().splitlines()] if (evidence / 'teardown.jsonl').exists() else []
            receipt[name] = {'captures': len(captures), 'capture_errors': [item for item in captures if 'captureError' in item or 'cleanupError' in item or not item.get('removalCompleted')], 'remaining_fixtures': sorted(path.name for path in owned.iterdir()), 'compiled_unchanged': manifest(sorted((REPO / 'packages/cli/dist').rglob('*.js'))) == compiled}
            save()
        assert receipt[name]['captures'] == 18
        assert not receipt[name]['capture_errors']
        assert not receipt[name]['remaining_fixtures']
        assert receipt[name]['compiled_unchanged']
    receipt['result'] = 'characterization passed both runtimes'
except BaseException as error:
    receipt['result'] = 'stopped'
    receipt['error'] = repr(error)
    raise
finally:
    receipt['source_after'] = source_manifest()
    receipt['source_unchanged'] = receipt.get('source_before') == receipt['source_after']
    receipt['git_status'] = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
    receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({key: value for key, value in receipt.items() if key not in ['source_before', 'source_after', 'compiled_before_tests', 'commands']}), flush=True)
