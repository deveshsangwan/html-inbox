Baseline characterization of issue #96

Head 42232780e567728618680073ce40bb4efa5f887b; common production base 610c931b7b22920cce59cf03e49c0de15ebaf2a2.
No tracked source or policy oracle changed. Install-if-needed/typecheck/build on exact Node24.19.0, then probe sequentially on exact Node20.20.2 and Node24.19.0. Both 18/18, no skips/failures/cancellations. No speedup claim.

execute.py is the exact command/environment runner; receipt.json contains command arguments/exits, timings, per-file source/compiled/runtime hashes and before/after equality. Source/compiled aggregate digests use SHA256 of UTF-8 json.dumps(mapping, sort_keys=True, separators=(',', ':')).

Each probe used NODE_OPTIONS=--require=<this artifact directory>/capture-exports.cjs, TMPDIR=<per-runtime owned fixture directory>, HTML_INBOX_CONTRACT_EVIDENCE=<per-runtime output archive directory>. Inherited HTML_INBOX_* variables, NODE_OPTIONS and NODE_TEST_CONTEXT were removed before setting those explicit values. All library operations explicitly targeted the probe's temporary homes. No independent syscall trace of HOME/catalog access was collected.

The cleanup-only preload observes fs.promises.rm for exactly the probe-created fixture roots directly under that runtime's TMPDIR. Before forwarding their normal removal it copies only export/staging/backup outputs, never managed ledgers/keys, and records hashes and removal completion. Other rm calls delegate directly. This captures the actual generated export bytes without changing the frozen probe or compiled production. This is an observed characterization run, not an uninstrumented timing sample. Capture overhead is not performance evidence.

Each runtime has 18 fixture archives, teardown.jsonl, stdout with all case results/cleanup diagnostics, and empty stderr. All 36 roots had only export/library immediately before disposal, one export output, no staging/backup residue, and completed removal. Postflight rechecked every captured file SHA256/size against the observer inventory and emitted manifest. Runtime fixtures are separately generated, so createdAt differs; do not treat cross-runtime output equality as tested. The probe tests output/metadata consistency within each operation.

cleanup.json records all seven direct commands reaped, process groups absent at exit, all seven recorded PIDs absent postflight, no adopted children left, and both fixture TMPDIRs empty. The supervising exec command also exited 0. No worker, server, bundle, full suite or sustained benchmark ran. Empty TMPDIR/evidence directories are intentional artifacts; no active library remains.

Original unrelated hosted CI timeout causes remain unresolved. This receipt neither diagnoses them nor replaces future optimized-view-path qualification.
