const fs = require('node:fs/promises');
const path = require('node:path');
const { createHash } = require('node:crypto');
const temporary = process.env.TMPDIR;
const evidence = process.env.HTML_INBOX_CONTRACT_EVIDENCE;
const remove = fs.rm;
let sequence = 0;

async function inventory(directory, relative = '') {
  const files = [];
  for (const entry of await fs.readdir(path.join(directory, relative), { withFileTypes: true })) {
    const name = path.join(relative, entry.name);
    if (entry.isDirectory()) {
      files.push(...await inventory(directory, name));
    } else if (entry.isFile()) {
      const bytes = await fs.readFile(path.join(directory, name));
      files.push({ path: name, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
    } else {
      throw new Error(`Unexpected generated output type: ${name}`);
    }
  }
  return files.sort((a, b) => a.path.localeCompare(b.path));
}

fs.rm = async function(filename, ...args) {
  if (typeof filename !== 'string' || path.dirname(filename) !== temporary || !path.basename(filename).startsWith('html-inbox-read-contract-')) {
    return remove.call(this, filename, ...args);
  }

  const record = { sequence: ++sequence, fixture: filename, outputs: [] };
  try {
    record.entriesBeforeCleanup = (await fs.readdir(filename)).sort();
    const destination = path.join(evidence, `fixture-${String(sequence).padStart(2, '0')}`);
    await fs.mkdir(destination, { recursive: true, mode: 0o700 });
    for (const name of record.entriesBeforeCleanup.filter((name) => name === 'export' || name.startsWith('export.staging-') || name.startsWith('export.backup-'))) {
      await fs.cp(path.join(filename, name), path.join(destination, name), { recursive: true });
      record.outputs.push({ name, files: await inventory(path.join(destination, name)) });
    }
  } catch (error) {
    record.captureError = String(error);
  }

  try {
    const result = await remove.call(this, filename, ...args);
    record.removalCompleted = true;
    return result;
  } catch (error) {
    record.cleanupError = String(error);
    throw error;
  } finally {
    await fs.appendFile(path.join(evidence, 'teardown.jsonl'), JSON.stringify(record) + '\n');
  }
};
