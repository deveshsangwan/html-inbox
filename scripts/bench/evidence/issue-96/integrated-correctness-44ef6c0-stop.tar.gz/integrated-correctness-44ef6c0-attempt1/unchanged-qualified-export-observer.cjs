const fs = require('node:fs/promises');
const path = require('node:path');
const { createHash } = require('node:crypto');
const temporary = process.env.TMPDIR;
const evidence = process.env.HTML_INBOX_CONTRACT_EVIDENCE;
const remove = fs.rm;
let sequence = 0;
const shapes = [
  ['html-inbox-read-contract-', 'baseline-export', ['export']],
  ['html-inbox-view-contract-', 'actual-view-control', ['export']],
  ['html-inbox-view-legacy-', 'legacy-transition', ['fallback', 'scoped']],
  ['html-inbox-view-retention-', 'retention', []],
  ['html-inbox-test-', 'existing-unit', ['snapshot', 'snapshot-invalid-encoding', 'snapshot-too-large', 'reversed-snapshot']],
  ['html-inbox-managed-reader-', 'selected-origin-control', ['racing-snapshot']],
];

async function inventory(directory, relative = '') {
  const files = [];
  for (const entry of await fs.readdir(path.join(directory, relative), { withFileTypes: true })) {
    const name = path.join(relative, entry.name);
    if (entry.isDirectory()) {
      files.push(...await inventory(directory, name));
    } else if (entry.isFile()) {
      const bytes = await fs.readFile(path.join(directory, name));
      files.push({ path: name, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
    } else {
      throw new Error(`Unexpected generated output type: ${name}`);
    }
  }
  return files.sort((a, b) => a.path.localeCompare(b.path));
}

fs.rm = async function(filename, ...args) {
  const shape = typeof filename === 'string' ? shapes.find(([prefix]) => path.basename(filename).startsWith(prefix)) : undefined;
  if (!shape || path.dirname(filename) !== temporary) {
    return remove.call(this, filename, ...args);
  }

  const record = { sequence: ++sequence, pid: process.pid, shape: shape[1], fixture: filename, outputs: [] };
  try {
    record.entriesBeforeCleanup = (await fs.readdir(filename)).sort();
    const destination = path.join(evidence, `fixture-${process.pid}-${String(sequence).padStart(2, '0')}`);
    await fs.mkdir(destination, { recursive: true, mode: 0o700 });
    for (const name of record.entriesBeforeCleanup.filter((name) => shape[2].some((output) => name === output || name.startsWith(output + '.staging-') || name.startsWith(output + '.backup-')))) {
      const info = await fs.lstat(path.join(filename, name));
      if (!info.isDirectory() || info.isSymbolicLink()) throw new Error('Unsafe generated output directory');
      await inventory(path.join(filename, name));
      await fs.cp(path.join(filename, name), path.join(destination, name), { recursive: true });
      record.outputs.push({ name, files: await inventory(path.join(destination, name)) });
    }
  } catch (error) {
    record.captureError = String(error);
  }

  try {
    const result = await remove.call(this, filename, ...args);
    record.removalCompleted = true;
    return result;
  } catch (error) {
    record.cleanupError = String(error);
    throw error;
  } finally {
    await fs.appendFile(path.join(evidence, `teardown-${process.pid}.jsonl`), JSON.stringify(record) + '\n');
  }
};
