(function initializeViewer() {
    const root = document.documentElement;
    const storageKey = "html-inbox-theme";
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const modes = new Set(["system", "light", "dark"]);
    const configuredMode = document
        .querySelector('meta[name="html-inbox-appearance"]')
        ?.getAttribute("content");
    const defaultMode = configuredMode && modes.has(configuredMode) ? configuredMode : "system";
    const readMode = () => {
        try {
            const saved = window.localStorage.getItem(storageKey);
            return saved && modes.has(saved) ? saved : defaultMode;
        }
        catch {
            return defaultMode;
        }
    };
    const notifyDocument = () => {
        const frame = document.querySelector("[data-document-frame]");
        if (frame instanceof HTMLIFrameElement) {
            // The sandbox intentionally gives documents an opaque origin.
            frame.contentWindow?.postMessage({ type: "html-inbox:appearance", theme: root.dataset.theme }, "*");
        }
    };
    const applyMode = (mode) => {
        const resolved = mode === "system" ? (media.matches ? "dark" : "light") : mode;
        root.dataset.theme = resolved;
        root.style.colorScheme = resolved;
        document
            .querySelectorAll("[data-theme-option]")
            .forEach((option) => {
            option.checked = option.value === mode;
        });
        notifyDocument();
    };
    let mode = readMode();
    applyMode(mode);
    const initialize = () => {
        document
            .querySelectorAll("[data-theme-option]")
            .forEach((option) => {
            option.checked = option.value === mode;
            option.addEventListener("change", () => {
                if (!option.checked || !modes.has(option.value)) {
                    return;
                }
                mode = option.value;
                try {
                    window.localStorage.setItem(storageKey, mode);
                }
                catch { }
                applyMode(mode);
            });
        });
        const frame = document.querySelector("[data-document-frame]");
        if (frame instanceof HTMLIFrameElement) {
            frame.addEventListener("load", notifyDocument);
            notifyDocument();
        }
        const hideFrame = document.querySelector("[data-hide-frame]");
        const showFrame = document.querySelector("[data-show-frame]");
        if (hideFrame instanceof HTMLButtonElement &&
            showFrame instanceof HTMLButtonElement) {
            hideFrame.addEventListener("click", () => {
                document
                    .querySelectorAll("[data-viewer-menu]")
                    .forEach((menu) => {
                    menu.open = false;
                });
                document.body.dataset.frameHidden = "";
                showFrame.hidden = false;
                showFrame.focus({ preventScroll: true });
            });
            showFrame.addEventListener("click", () => {
                delete document.body.dataset.frameHidden;
                showFrame.hidden = true;
                hideFrame.focus({ preventScroll: true });
            });
        }
        const menus = Array.from(document.querySelectorAll("[data-viewer-menu]"));
        if (frame instanceof HTMLIFrameElement) {
            window.addEventListener("blur", () => {
                // The sandbox prevents document clicks from reaching the viewer.
                // Wait for focus to settle before identifying a click inside the frame.
                window.setTimeout(() => {
                    if (document.activeElement !== frame) {
                        return;
                    }
                    menus.forEach((menu) => {
                        menu.open = false;
                    });
                }, 0);
            });
        }
        document.addEventListener("click", (event) => {
            const target = event.target;
            if (!(target instanceof Node)) {
                return;
            }
            menus.forEach((menu) => {
                if (!menu.contains(target)) {
                    menu.open = false;
                }
            });
        });
        document.addEventListener("keydown", (event) => {
            if (event.key !== "Escape" || document.querySelector("[data-copy-dialog][open]")) {
                return;
            }
            menus.forEach((menu) => {
                if (!menu.open) {
                    return;
                }
                menu.open = false;
                menu.querySelector("summary")?.focus();
            });
        });
        const dateFormatter = new Intl.DateTimeFormat(undefined, {
            dateStyle: "medium",
            timeStyle: "short",
        });
        document
            .querySelectorAll("time[data-local-date]")
            .forEach((element) => {
            const date = new Date(element.dateTime);
            if (!Number.isNaN(date.valueOf())) {
                element.textContent = dateFormatter.format(date);
            }
        });
        const searchForm = document.querySelector("[data-client-search]");
        if (searchForm instanceof HTMLFormElement) {
            const input = searchForm.querySelector('input[name="q"]');
            const rows = Array.from(document.querySelectorAll("[data-search-text]"));
            const count = document.querySelector("[data-document-count]");
            const empty = document.querySelector("[data-client-empty]");
            const clear = searchForm.querySelector("[data-search-clear]");
            const submit = searchForm.querySelector("[data-search-submit]");
            const total = rows.length;
            if (submit)
                submit.hidden = true;
            const applySearch = (value) => {
                const query = value.trim().slice(0, 200).toLowerCase();
                let visible = 0;
                rows.forEach((row) => {
                    const matches = !query || (row.dataset.searchText || "").includes(query);
                    row.hidden = !matches;
                    if (matches)
                        visible += 1;
                });
                if (count) {
                    count.textContent = query
                        ? visible + " of " + total + " documents"
                        : total + (total === 1 ? " document" : " documents");
                }
                if (empty)
                    empty.hidden = !query || visible > 0;
                if (clear)
                    clear.hidden = !query;
            };
            const initialQuery = new URL(window.location.href).searchParams.get("q") || "";
            if (input instanceof HTMLInputElement)
                input.value = initialQuery;
            applySearch(initialQuery);
            const commit = (value) => {
                const url = new URL(window.location.href);
                const query = value.trim().slice(0, 200);
                if (query)
                    url.searchParams.set("q", query);
                else
                    url.searchParams.delete("q");
                window.history.replaceState(null, "", url);
                applySearch(value);
            };
            searchForm.addEventListener("submit", (event) => {
                event.preventDefault();
                commit(input instanceof HTMLInputElement ? input.value : "");
            });
            if (input instanceof HTMLInputElement) {
                input.addEventListener("input", () => commit(input.value));
            }
            if (clear) {
                clear.addEventListener("click", (event) => {
                    event.preventDefault();
                    if (input instanceof HTMLInputElement)
                        input.value = "";
                    commit("");
                    if (input instanceof HTMLInputElement)
                        input.focus();
                });
            }
        }
    };
    media.addEventListener("change", () => {
        if (mode === "system")
            applyMode(mode);
    });
    window.addEventListener("storage", (event) => {
        if (event.key !== storageKey && event.key !== null) {
            return;
        }
        mode = readMode();
        applyMode(mode);
    });
    document.addEventListener("DOMContentLoaded", initialize, { once: true });
})();
(function initializeViewerCopy(maximumJsonBytes) {
    const initialize = () => {
        const dialog = document.querySelector("[data-copy-dialog]");
        const openButton = document.querySelector("[data-copy-open]");
        const closeButton = document.querySelector("[data-copy-close]");
        const retryButton = document.querySelector("[data-copy-retry]");
        const content = document.querySelector("[data-copy-content]");
        const status = document.querySelector("[data-copy-status]");
        const format = document.querySelector("[data-copy-format]");
        const codeControls = document.querySelector("[data-copy-code-controls]");
        const codePicker = document.querySelector("[data-copy-code-block]");
        const empty = document.querySelector("[data-copy-empty]");
        const previewLabel = document.querySelector("[data-copy-preview-label]");
        const preview = document.querySelector("[data-copy-preview]");
        const copyAll = document.querySelector("[data-copy-all]");
        const copySelection = document.querySelector("[data-copy-selection]");
        const copyCode = document.querySelector("[data-copy-code]");
        const selectAll = document.querySelector("[data-copy-select-all]");
        const menu = openButton?.closest("[data-viewer-menu]");
        const summary = menu?.querySelector("summary");
        if (!(dialog instanceof HTMLDialogElement) ||
            !(openButton instanceof HTMLButtonElement) ||
            !(closeButton instanceof HTMLButtonElement) ||
            !(retryButton instanceof HTMLButtonElement) ||
            !(content instanceof HTMLElement) ||
            !(status instanceof HTMLElement) ||
            !(format instanceof HTMLSelectElement) ||
            !(codeControls instanceof HTMLElement) ||
            !(codePicker instanceof HTMLSelectElement) ||
            !(empty instanceof HTMLElement) ||
            !(previewLabel instanceof HTMLElement) ||
            !(preview instanceof HTMLTextAreaElement) ||
            !(copyAll instanceof HTMLButtonElement) ||
            !(copySelection instanceof HTMLButtonElement) ||
            !(copyCode instanceof HTMLButtonElement) ||
            !(selectAll instanceof HTMLButtonElement) ||
            !(menu instanceof HTMLDetailsElement) ||
            !(summary instanceof HTMLElement)) {
            return;
        }
        const copyUrl = dialog.dataset.copyUrl;
        if (!copyUrl) {
            return;
        }
        let payload;
        let preparation;
        let generation = 0;
        let previewGeneration = 0;
        let isWritePending = false;
        let selectionStart = 0;
        let selectionEnd = 0;
        const isCurrent = (requestGeneration) => dialog.open && generation === requestGeneration;
        const preparedText = () => {
            if (!payload) {
                return "";
            }
            return format.value === "text" ? payload.text : payload.codeBlocks[Number(codePicker.value)] ?? "";
        };
        const hasSelection = () => format.value === "text" &&
            selectionStart >= 0 && selectionEnd > selectionStart && selectionEnd <= preview.value.length;
        const updateButtons = () => {
            const hasText = Boolean(payload && preparedText().length);
            copyAll.disabled = !hasText;
            copySelection.disabled = !hasText || !hasSelection();
            copyCode.disabled = !hasText;
            selectAll.disabled = !hasText;
            for (const button of [copyAll, copySelection, copyCode]) {
                // aria-disabled keeps the activated button focused while a write settles.
                button.setAttribute("aria-disabled", String(isWritePending));
            }
        };
        const rememberSelection = () => {
            selectionStart = preview.selectionStart;
            selectionEnd = preview.selectionEnd;
            updateButtons();
        };
        const showPreview = () => {
            previewGeneration += 1;
            const isCode = format.value === "code";
            const blockNumber = Number(codePicker.value) + 1;
            const hasCodeBlocks = Boolean(payload?.codeBlocks.length);
            codeControls.hidden = !isCode || !hasCodeBlocks;
            copyAll.hidden = isCode;
            copySelection.hidden = isCode;
            copyCode.hidden = !isCode;
            copyCode.textContent = `Copy code block ${blockNumber}`;
            previewLabel.textContent = isCode ? `Code block ${blockNumber}` : "Document text";
            preview.value = preparedText();
            preview.wrap = isCode ? "off" : "soft";
            selectionStart = 0;
            selectionEnd = 0;
            empty.textContent = isCode
                ? hasCodeBlocks ? `Code block ${blockNumber} is empty.` : "No code blocks found in the saved HTML."
                : "No document text found in the saved HTML.";
            empty.hidden = preview.value.length > 0;
            preview.hidden = isCode && !hasCodeBlocks;
            previewLabel.hidden = preview.hidden;
            updateButtons();
            status.textContent = "Content ready. Choose what to copy.";
        };
        const validatePayload = (value) => {
            if (typeof value !== "object" || value === null ||
                !("schemaVersion" in value) || value.schemaVersion !== 1 || !("status" in value)) {
                throw new Error("Invalid copy content");
            }
            if (value.status === "ready" && "text" in value && typeof value.text === "string" &&
                "codeBlocks" in value && Array.isArray(value.codeBlocks) &&
                value.codeBlocks.every((block) => typeof block === "string")) {
                return { schemaVersion: 1, status: "ready", text: value.text, codeBlocks: value.codeBlocks };
            }
            if (value.status === "unavailable" && "reason" in value &&
                (value.reason === "too-large" || value.reason === "invalid-encoding")) {
                return { schemaVersion: 1, status: "unavailable", reason: value.reason };
            }
            throw new Error("Invalid copy content");
        };
        const fetchPayload = async (signal) => {
            const response = await fetch(copyUrl, { signal, cache: "no-store", mode: "same-origin", redirect: "error" });
            const mime = response.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase();
            if (!response.ok || mime !== "application/json" || !response.body) {
                await response.body?.cancel();
                throw new Error("Invalid copy response");
            }
            if (Number(response.headers.get("Content-Length")) > maximumJsonBytes) {
                await response.body.cancel();
                throw new Error("too-large");
            }
            const reader = response.body.getReader();
            const decoder = new TextDecoder("utf-8", { fatal: true });
            const parts = [];
            let bytesRead = 0;
            try {
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        break;
                    }
                    bytesRead += value.byteLength;
                    if (bytesRead > maximumJsonBytes) {
                        throw new Error("too-large");
                    }
                    parts.push(decoder.decode(value, { stream: true }));
                }
                parts.push(decoder.decode());
            }
            catch (error) {
                await reader.cancel();
                throw error;
            }
            finally {
                reader.releaseLock();
            }
            const value = JSON.parse(parts.join(""));
            return validatePayload(value);
        };
        const resetPreparation = () => {
            generation += 1;
            preparation?.abort();
            preparation = undefined;
            payload = undefined;
            preview.value = "";
            selectionStart = 0;
            selectionEnd = 0;
            content.hidden = true;
            retryButton.hidden = true;
            codePicker.replaceChildren();
            updateButtons();
        };
        const prepareContent = async () => {
            resetPreparation();
            const requestGeneration = generation;
            const controller = new AbortController();
            preparation = controller;
            status.textContent = "Preparing content...";
            try {
                const result = await fetchPayload(controller.signal);
                if (!isCurrent(requestGeneration)) {
                    return;
                }
                if (result.status === "unavailable") {
                    status.textContent = result.reason === "too-large"
                        ? "This saved HTML is too large to prepare for copying. Use native Copy in the preview."
                        : "This saved HTML has invalid text encoding. Use native Copy in the preview.";
                    return;
                }
                payload = result;
                result.codeBlocks.forEach((_block, index) => {
                    const option = document.createElement("option");
                    option.value = String(index);
                    option.textContent = `Code block ${index + 1}`;
                    codePicker.append(option);
                });
                content.hidden = false;
                showPreview();
            }
            catch (error) {
                if (!isCurrent(requestGeneration)) {
                    return;
                }
                status.textContent = error instanceof Error && error.message === "too-large"
                    ? "Copy content is too large to prepare. Use native Copy in the preview."
                    : "Could not prepare content. Retry, or use native Copy in the preview.";
                retryButton.hidden = false;
            }
        };
        const copyText = (text) => {
            if (!dialog.open || !payload || !text.length || isWritePending) {
                return;
            }
            const manualHelp = "Select text, then use Ctrl+C or Command+C, the context menu, or touch Copy.";
            if (typeof navigator.clipboard?.writeText !== "function") {
                status.textContent = `Clipboard copy is unavailable in this browser. ${manualHelp}`;
                return;
            }
            const writeGeneration = generation;
            const writePreviewGeneration = previewGeneration;
            isWritePending = true;
            updateButtons();
            status.textContent = "Copying...";
            const settleWrite = (message) => {
                isWritePending = false;
                updateButtons();
                if (isCurrent(writeGeneration) && previewGeneration === writePreviewGeneration) {
                    status.textContent = message;
                }
            };
            try {
                // Invoke the API during this activation, before any asynchronous work.
                const write = navigator.clipboard.writeText(text);
                void write.then(() => settleWrite("Copied."), () => settleWrite(`Could not copy. ${manualHelp}`));
            }
            catch {
                settleWrite(`Could not copy. ${manualHelp}`);
            }
        };
        const closeDialog = () => {
            resetPreparation();
            status.textContent = "";
            dialog.close();
            summary.focus({ preventScroll: true });
        };
        openButton.addEventListener("click", () => {
            menu.open = false;
            format.value = "text";
            dialog.showModal();
            closeButton.focus({ preventScroll: true });
            void prepareContent();
        });
        closeButton.addEventListener("click", closeDialog);
        dialog.addEventListener("cancel", (event) => {
            event.preventDefault();
            closeDialog();
        });
        retryButton.addEventListener("click", () => { void prepareContent(); });
        format.addEventListener("change", showPreview);
        codePicker.addEventListener("change", showPreview);
        preview.addEventListener("select", rememberSelection);
        preview.addEventListener("blur", rememberSelection);
        copySelection.addEventListener("pointerdown", rememberSelection);
        copyAll.addEventListener("click", () => copyText(preparedText()));
        copyCode.addEventListener("click", () => copyText(preparedText()));
        copySelection.addEventListener("click", () => {
            if (preview.selectionEnd > preview.selectionStart) {
                rememberSelection();
            }
            if (!hasSelection()) {
                return;
            }
            copyText(preview.value.slice(selectionStart, selectionEnd));
        });
        selectAll.addEventListener("click", () => {
            preview.focus({ preventScroll: true });
            preview.select();
            rememberSelection();
        });
    };
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initialize, { once: true });
    }
    else {
        initialize();
    }
})(10485760);
(function initializeDocumentDeletion() {
    const initialize = () => {
        const dialog = document.querySelector("[data-delete-dialog]");
        const form = document.querySelector("[data-delete-form]");
        const cancel = document.querySelector("[data-delete-cancel]");
        const confirm = document.querySelector("[data-delete-confirm]");
        const title = document.querySelector("[data-delete-title]");
        const file = document.querySelector("[data-delete-file]");
        const inbox = document.querySelector("[data-delete-inbox]");
        const progress = document.querySelector("[data-delete-progress]");
        const error = document.querySelector("[data-delete-error]");
        const review = document.querySelector("[data-delete-review]");
        if (!(dialog instanceof HTMLDialogElement) ||
            !(form instanceof HTMLFormElement) ||
            !(cancel instanceof HTMLButtonElement) ||
            !(confirm instanceof HTMLButtonElement) ||
            !(title instanceof HTMLElement) ||
            !(file instanceof HTMLElement) ||
            !(inbox instanceof HTMLElement) ||
            !(progress instanceof HTMLElement) ||
            !(error instanceof HTMLElement) ||
            !(review instanceof HTMLAnchorElement) ||
            !dialog.dataset.deleteToken) {
            return;
        }
        const token = dialog.dataset.deleteToken;
        const heading = dialog.querySelector("h2");
        const home = new URL(dialog.dataset.homePath ?? "/", window.location.origin);
        const returnKey = "html-inbox-list-return";
        const receiptKey = "html-inbox-deletion-receipt";
        const isReader = document.body.classList.contains("document-page");
        const readNavigation = (key) => {
            try {
                const saved = JSON.parse(window.sessionStorage.getItem(key) ?? "null");
                window.sessionStorage.removeItem(key);
                if (saved && typeof saved === "object" && !Array.isArray(saved)) {
                    return Object.fromEntries(Object.entries(saved));
                }
            }
            catch { }
        };
        const saveNavigation = (key, value) => {
            try {
                const saved = JSON.stringify(value);
                window.sessionStorage.setItem(key, saved);
                return window.sessionStorage.getItem(key) === saved;
            }
            catch {
                return false;
            }
        };
        const listDestination = (value) => {
            if (typeof value !== "string") {
                return;
            }
            try {
                const url = new URL(value, window.location.origin);
                const ownInbox = home.searchParams.get("inbox");
                const hasValidSearch = Array.from(url.searchParams).every(([key, value]) => (key === "q" && value.length <= 200) ||
                    (key === "inbox" && (!ownInbox || !value || value === ownInbox)));
                if (url.origin === window.location.origin &&
                    url.pathname === home.pathname &&
                    !url.username && !url.password && !url.hash &&
                    url.searchParams.getAll("q").length <= 1 &&
                    url.searchParams.getAll("inbox").length <= 1 &&
                    hasValidSearch) {
                    return `${url.pathname}${url.search}`;
                }
            }
            catch { }
        };
        const currentList = `${window.location.pathname}${window.location.search}`;
        const returnContext = isReader ? readNavigation(returnKey) : undefined;
        const returnPath = returnContext?.documentPath === window.location.pathname
            ? listDestination(returnContext.listPath)
            : undefined;
        const destination = isReader ? returnPath ?? `${home.pathname}${home.search}` : currentList;
        const scrollPosition = (value) => typeof value === "number" && Number.isFinite(value)
            ? Math.max(0, value)
            : 0;
        review.href = destination;
        if (!isReader) {
            document.querySelectorAll(".doc__title").forEach((link) => {
                link.addEventListener("click", (event) => {
                    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
                        return;
                    }
                    saveNavigation(returnKey, {
                        documentPath: link.pathname,
                        listPath: currentList,
                        scrollY: window.scrollY,
                    });
                });
            });
            const receipt = readNavigation(receiptKey);
            const notice = document.querySelector("[data-deletion-notice]");
            if (receipt && listDestination(receipt.destination) === currentList &&
                typeof receipt.message === "string" && receipt.message.length <= 1000 &&
                notice instanceof HTMLElement) {
                notice.textContent = receipt.message;
                notice.hidden = false;
                const next = Array.from(document.querySelectorAll(".doc__title"))
                    .find((link) => link.pathname === receipt.focusPath);
                const focus = next ?? document.querySelector("#document-search");
                const restorePosition = () => window.requestAnimationFrame(() => {
                    focus?.focus({ preventScroll: true });
                    window.scrollTo(0, scrollPosition(receipt.scrollY));
                });
                if (document.readyState === "complete") {
                    restorePosition();
                }
                else {
                    window.addEventListener("load", restorePosition, { once: true });
                }
            }
        }
        let selected;
        let restoreFocus;
        let isDeleting = false;
        const closeDialog = () => {
            if (isDeleting) {
                return;
            }
            dialog.close();
        };
        dialog.addEventListener("cancel", (event) => {
            event.preventDefault();
            closeDialog();
        });
        dialog.addEventListener("close", () => restoreFocus?.focus({ preventScroll: true }));
        cancel.addEventListener("click", closeDialog);
        document.querySelectorAll("[data-delete-document]").forEach((button) => {
            button.addEventListener("click", () => {
                if (dialog.open || isDeleting) {
                    return;
                }
                selected = button;
                if (heading) {
                    heading.textContent = "Delete document?";
                }
                const menu = button.closest("details");
                restoreFocus = menu?.querySelector("summary") ?? button;
                if (menu instanceof HTMLDetailsElement) {
                    menu.open = false;
                }
                title.textContent = button.dataset.documentTitle ?? "";
                file.textContent = button.dataset.documentFile ?? "";
                inbox.textContent = button.dataset.inboxName ?? "";
                error.hidden = true;
                progress.hidden = true;
                review.hidden = true;
                cancel.textContent = "Cancel";
                confirm.disabled = false;
                dialog.showModal();
                cancel.focus();
            });
        });
        const finishDeletion = (button, message) => {
            const links = Array.from(document.querySelectorAll(".doc__title"));
            const index = links.findIndex((link) => link.pathname === button.dataset.documentPath);
            const next = links[index + 1] ?? links[index - 1];
            const hasSavedNotice = saveNavigation(receiptKey, {
                destination,
                message,
                focusPath: next?.pathname,
                scrollY: isReader ? scrollPosition(returnContext?.scrollY) : window.scrollY,
            });
            if (!hasSavedNotice) {
                isDeleting = false;
                dialog.removeAttribute("aria-busy");
                progress.textContent = message;
                progress.hidden = false;
                review.hidden = false;
                cancel.disabled = false;
                cancel.textContent = "Close";
                button.disabled = true;
                if (heading) {
                    heading.textContent = "Document removed";
                }
                cancel.focus();
                return;
            }
            // Replace the reader URL so Back cannot reopen a document just removed here.
            if (isReader) {
                window.location.replace(destination);
            }
            else {
                window.location.reload();
            }
        };
        form.addEventListener("submit", async (event) => {
            event.preventDefault();
            if (isDeleting || !selected || confirm.disabled) {
                return;
            }
            const button = selected;
            const documentTitle = button.dataset.documentTitle ?? "Document";
            const inboxName = button.dataset.inboxName ?? "Inbox";
            isDeleting = true;
            cancel.disabled = true;
            confirm.disabled = true;
            dialog.setAttribute("aria-busy", "true");
            progress.textContent = "Deleting document. Please wait.";
            progress.hidden = false;
            error.hidden = true;
            review.hidden = true;
            let message = "We couldn't confirm whether the document was deleted. Check the inbox before trying again.";
            const controller = new AbortController();
            const timeout = window.setTimeout(() => controller.abort(), 30_000);
            try {
                const response = await window.fetch(button.dataset.deleteUrl ?? "", {
                    method: "DELETE",
                    headers: { "X-HTML-Inbox-CSRF": token },
                    credentials: "same-origin",
                    signal: controller.signal,
                });
                if (response.status === 204 || response.status === 404) {
                    finishDeletion(button, response.status === 204
                        ? `"${documentTitle}" was deleted from "${inboxName}".`
                        : `"${documentTitle}" is already absent from "${inboxName}".`);
                    return;
                }
                if (response.status === 200) {
                    const result = await response.json();
                    if (result && typeof result === "object" &&
                        "status" in result && result.status === "removed" &&
                        "cleanup" in result && result.cleanup === "failed") {
                        finishDeletion(button, `"${documentTitle}" was removed from "${inboxName}", but some saved files could not be cleaned up.`);
                        return;
                    }
                }
                else if (response.status === 403) {
                    message = "This page can no longer delete documents. Reload the page and try again.";
                }
                else if (response.status === 409) {
                    message = "This inbox has changed or is unavailable. Restart its viewer or hub before deleting.";
                }
                else if (response.status < 500) {
                    message = "The request could not be completed. Check the inbox and reload the page before trying again.";
                }
            }
            catch { }
            finally {
                window.clearTimeout(timeout);
            }
            isDeleting = false;
            dialog.removeAttribute("aria-busy");
            progress.hidden = true;
            error.textContent = message;
            error.hidden = false;
            review.hidden = false;
            cancel.disabled = false;
            cancel.textContent = "Close";
            cancel.focus();
        });
    };
    document.addEventListener("DOMContentLoaded", initialize, { once: true });
})();