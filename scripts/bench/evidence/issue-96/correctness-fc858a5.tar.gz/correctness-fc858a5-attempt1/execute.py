import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
NODE24 = Path('/home/agent/.local/share/fnm/node-versions/v24.19.0/installation/bin/node')
NODE20 = Path('/home/agent/.local/share/fnm/node-versions/v20.20.2/installation/bin/node')
PNPM = NODE24.parent.parent / 'lib/node_modules/corepack/dist/pnpm.js'
EXPECTED = 'fc858a56d874debb470d8e26bb91c3fac99b01e6'
PATTERN = '^export fetched-origin guard rejects (imported|origin-only) return through (view|fallback)$'
APP_BUDGET = 900
CLEANUP_ALLOWANCE = 120
commands = []
app_started = None
cleanup_used = 0.0
receipt = {'head': EXPECTED, 'base': '610c931b7b22920cce59cf03e49c0de15ebaf2a2', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'application_budget_seconds': APP_BUDGET, 'separate_cleanup_allowance_seconds': CLEANUP_ALLOWANCE, 'commands': commands}
assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0

def save():
    receipt['cleanup_used_seconds'] = cleanup_used
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def tracked():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=REPO).decode().split('\0')
    return {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in names if name and (REPO / name).is_file()}

def compiled():
    return {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((REPO / 'packages/cli/dist').rglob('*.js'))}

def own_children():
    filename = Path(f'/proc/self/task/{os.getpid()}/children')
    return [int(value) for value in filename.read_text().split()]

def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False

def drain_group(record):
    global cleanup_used
    started = time.monotonic()
    deadline = started + max(0, CLEANUP_ALLOWANCE - cleanup_used)
    reaped = []
    actions = []
    for child_pid in own_children():
        try:
            os.kill(child_pid, signal.SIGTERM)
            actions.append({'pid': child_pid, 'signal': 'SIGTERM'})
        except ProcessLookupError:
            pass
    if group_exists(record['pgid']):
        os.killpg(record['pgid'], signal.SIGTERM)
        actions.append({'pgid': record['pgid'], 'signal': 'SIGTERM'})
    while True:
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if pid == 0:
                break
            reaped.append({'pid': pid, 'status': status})
        children = own_children()
        live_group = group_exists(record['pgid'])
        if not children and not live_group:
            break
        if time.monotonic() >= deadline:
            raise RuntimeError('Cleanup allowance exhausted; preserve fixtures')
        if time.monotonic() - started >= 1:
            if live_group:
                os.killpg(record['pgid'], signal.SIGKILL)
            for pid in children:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        time.sleep(0.01)
    cleanup_used += time.monotonic() - started
    record['cleanup'] = {'group_absent': True, 'children_remaining': [], 'adopted_reaped': reaped, 'signals': actions, 'seconds': time.monotonic() - started}

def output_postflight(record, owned, evidence):
    captures = [json.loads(line) for filename in sorted(evidence.glob('teardown-*.jsonl')) for line in filename.read_text().splitlines()]
    errors = []
    files = 0
    for capture in captures:
        if capture.get('captureError') or capture.get('cleanupError') or not capture.get('removalCompleted'):
            errors.append(capture)
        if Path(capture['fixture']).exists():
            raise RuntimeError('Fixture remains after recorded removal')
        destination = evidence / f"fixture-{capture['pid']}-{capture['sequence']:02d}"
        for output in capture['outputs']:
            for item in output['files']:
                data = (destination / output['name'] / item['path']).read_bytes()
                assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
                files += 1
    record['output_capture'] = {'fixtures': len(captures), 'shapes': {shape: sum(item['shape'] == shape for item in captures) for shape in sorted({item['shape'] for item in captures})}, 'files': files, 'observer_errors': errors}
    remaining = sorted(path.name for path in owned.iterdir())
    record['remaining_fixtures_after_child_reaping'] = remaining
    if remaining:
        # Only this freshly created private TMPDIR is removed, after its process group/children are gone.
        inventory = []
        for filename in sorted(owned.rglob('*')):
            info = filename.lstat()
            inventory.append({'path': str(filename.relative_to(owned)), 'mode': info.st_mode, 'uid': info.st_uid, 'dev': info.st_dev, 'ino': info.st_ino, 'nlink': info.st_nlink, 'size': info.st_size})
        (evidence / 'remaining-fixture-metadata.json').write_text(json.dumps(inventory, indent=2) + '\n')
        record['unreached_test_cleanup'] = True
    assert owned.parent == ROOT and owned.stat().st_uid == os.getuid() and not owned.is_symlink()
    shutil.rmtree(owned)
    assert not owned.exists()
    record['owned_tmpdir_absent'] = True
    if errors:
        raise RuntimeError('Output observer failed; distinguish from application result')
    if remaining:
        raise RuntimeError('Test fixture cleanup incomplete; stop after owned removal')

def run(label, command, env, timeout, observed=False):
    global app_started, cleanup_used
    if app_started is None:
        app_started = time.monotonic()
    remaining = APP_BUDGET - (time.monotonic() - app_started - cleanup_used)
    if remaining <= 0:
        raise RuntimeError('Overall application-command budget exhausted')
    limit = min(timeout, remaining)
    record = {'label': label, 'command': list(map(str, command)), 'limit_seconds': limit, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    commands.append(record)
    actual_env = dict(env)
    owned = ROOT / (label + '-tmp')
    evidence = ROOT / (label + '-outputs')
    if observed:
        owned.mkdir(mode=0o700)
        evidence.mkdir(mode=0o700)
        actual_env.update(TMPDIR=str(owned), HTML_INBOX_CONTRACT_EVIDENCE=str(evidence), NODE_OPTIONS='--require=' + str(ROOT / 'capture-outputs.cjs'))
        record['explicit_environment'] = {key: actual_env[key] for key in ['TMPDIR', 'HTML_INBOX_CONTRACT_EVIDENCE', 'NODE_OPTIONS']}
    print('START ' + label, flush=True)
    started = time.monotonic()
    with (ROOT / f'{label}.stdout.log').open('wb') as stdout, (ROOT / f'{label}.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=REPO, env=actual_env, stdout=stdout, stderr=stderr, start_new_session=True)
        record.update(pid=child.pid, pgid=child.pid)
        record['proc_start'] = Path(f'/proc/{child.pid}/stat').read_text().split(') ', 1)[1].split()[19]
        try:
            record['exit_code'] = child.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            record['timed_out'] = True
            os.killpg(child.pid, signal.SIGKILL)
            record['exit_code'] = child.wait(timeout=CLEANUP_ALLOWANCE - cleanup_used)
        record['application_elapsed_seconds'] = time.monotonic() - started
    drain_group(record)
    if observed:
        cleanup_started = time.monotonic()
        try:
            output_postflight(record, owned, evidence)
        finally:
            cleanup_used += time.monotonic() - cleanup_started
    record['source_unchanged'] = tracked() == receipt['source_before']
    if 'compiled_candidate' in receipt:
        record['compiled_unchanged'] = compiled() == receipt['compiled_candidate']
    save()
    print('END ' + label + ' exit=' + str(record['exit_code']), flush=True)
    if record['exit_code'] or not record['source_unchanged'] or record.get('compiled_unchanged') is False:
        raise RuntimeError('STOP after failed command or pin mismatch: ' + label)

try:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == EXPECTED
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
    assert (REPO / 'node_modules').is_dir()
    receipt['source_before'] = tracked()
    receipt['compiled_before_build'] = compiled()
    receipt['runtime_hashes'] = {str(node): hashlib.sha256(node.read_bytes()).hexdigest() for node in [NODE20, NODE24]}
    receipt['observer_sha256'] = hashlib.sha256((ROOT / 'capture-outputs.cjs').read_bytes()).hexdigest()
    receipt['runner_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    receipt['planned_checks'] = ['typecheck', 'build'] + [runtime + '-' + check for runtime in ['node20', 'node24'] for check in ['baseline', 'actual-view', 'retention', 'containing', 'selected-origin']]
    env = {key: value for key, value in os.environ.items() if not key.startswith('HTML_INBOX_') and key not in ['NODE_OPTIONS', 'NODE_TEST_CONTEXT']}
    env['PATH'] = str(NODE24.parent) + os.pathsep + env['PATH']
    receipt['environment_policy'] = 'inherit env minus HTML_INBOX_*, NODE_OPTIONS, NODE_TEST_CONTEXT; exact Node24 bin first on PATH; only explicit per-test observer variables added'
    save()
    run('node24-version', [NODE24, '--version'], env, 30)
    run('node20-version', [NODE20, '--version'], env, 30)
    assert (ROOT / 'node24-version.stdout.log').read_text().strip() == 'v24.19.0'
    assert (ROOT / 'node20-version.stdout.log').read_text().strip() == 'v20.20.2'
    run('typecheck', [NODE24, PNPM, 'typecheck'], env, 120)
    run('build', [NODE24, PNPM, 'build'], env, 120)
    receipt['compiled_candidate'] = compiled()
    save()
    for runtime, node in [('node20', NODE20), ('node24', NODE24)]:
        jobs = [
            ('baseline', ['--test', 'scripts/bench/managed-read-contract.cjs'], 120),
            ('actual-view', ['--test', 'scripts/bench/managed-view-contract.cjs'], 180),
            ('retention', ['--expose-gc', '--test', 'scripts/bench/managed-view-retention.cjs'], 120),
            ('containing', ['--test', 'packages/cli/dist/static-export.test.js', 'packages/cli/dist/local-document-source.test.js'], 120),
            ('selected-origin', ['--test', '--test-name-pattern=' + PATTERN, 'packages/cli/dist/sync-reader-compatibility.test.js'], 120),
        ]
        for check, arguments, limit in jobs:
            run(runtime + '-' + check, [node] + arguments, env, limit, observed=True)
    receipt['result'] = 'all 12 candidate correctness checks passed'
except BaseException as error:
    receipt['result'] = 'stopped'
    receipt['error'] = repr(error)
    raise
finally:
    receipt['source_after'] = tracked()
    receipt['compiled_after'] = compiled()
    receipt['source_unchanged'] = receipt.get('source_before') == receipt['source_after']
    receipt['git_status'] = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
    receipt['not_run'] = [label for label in receipt.get('planned_checks', []) if label not in {item['label'] for item in commands}]
    receipt['owned_children_at_exit'] = own_children()
    receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({key: value for key, value in receipt.items() if key not in ['source_before', 'source_after', 'compiled_before_build', 'compiled_candidate', 'compiled_after', 'commands']}), flush=True)
