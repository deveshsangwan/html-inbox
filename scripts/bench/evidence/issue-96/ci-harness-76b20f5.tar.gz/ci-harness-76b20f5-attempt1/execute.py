import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
NODE24 = Path('/home/agent/.local/share/fnm/node-versions/v24.19.0/installation/bin/node')
NODE20 = Path('/home/agent/.local/share/fnm/node-versions/v20.20.2/installation/bin/node')
PNPM = NODE24.parent.parent / 'lib/node_modules/corepack/dist/pnpm.js'
EXPECTED = '76b20f5ea913ac3368ac7fbb6fb1071ece6ade86'
BASE = Path('/home/agent/.t3/worktrees/html-inbox/perf-89-bench')
PARENT = '610c931b7b22920cce59cf03e49c0de15ebaf2a2'
APP_BUDGET = 900
CLEANUP_ALLOWANCE = 120
commands = []
app_started = None
cleanup_used = 0.0
receipt = {'head': EXPECTED, 'base': '610c931b7b22920cce59cf03e49c0de15ebaf2a2', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'application_budget_seconds': APP_BUDGET, 'separate_cleanup_allowance_seconds': CLEANUP_ALLOWANCE, 'commands': commands}
assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0

def save():
    receipt['cleanup_used_seconds'] = cleanup_used
    (ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

def tracked(repo=REPO):
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=repo).decode().split('\0')
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in names if name and (repo / name).is_file()}

def compiled(repo=REPO):
    return {str(p.relative_to(repo)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((repo / 'packages/cli/dist').rglob('*.js'))}

def own_children():
    filename = Path(f'/proc/self/task/{os.getpid()}/children')
    return [int(value) for value in filename.read_text().split()]

def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False

def drain_group(record):
    global cleanup_used
    started = time.monotonic()
    deadline = started + max(0, CLEANUP_ALLOWANCE - cleanup_used)
    reaped = []
    actions = []
    for child_pid in own_children():
        try:
            os.kill(child_pid, signal.SIGTERM)
            actions.append({'pid': child_pid, 'signal': 'SIGTERM'})
        except ProcessLookupError:
            pass
    if group_exists(record['pgid']):
        os.killpg(record['pgid'], signal.SIGTERM)
        actions.append({'pgid': record['pgid'], 'signal': 'SIGTERM'})
    while True:
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            if pid == 0:
                break
            reaped.append({'pid': pid, 'status': status})
        children = own_children()
        live_group = group_exists(record['pgid'])
        if not children and not live_group:
            break
        if time.monotonic() >= deadline:
            raise RuntimeError('Cleanup allowance exhausted; preserve fixtures')
        if time.monotonic() - started >= 1:
            if live_group:
                os.killpg(record['pgid'], signal.SIGKILL)
            for pid in children:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        time.sleep(0.01)
    cleanup_used += time.monotonic() - started
    record['cleanup'] = {'group_absent': True, 'children_remaining': [], 'adopted_reaped': reaped, 'signals': actions, 'seconds': time.monotonic() - started}

def observe_tree(record):
    found = set([record['pid'], *own_children()])
    table = {}
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().split(') ', 1)[1].split()
            table[int(proc.name)] = dict(ppid=int(fields[1]), pgid=int(fields[2]), start=fields[19], state=fields[0])
        except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, IndexError):
            pass
    previous = None
    while previous != len(found):
        previous = len(found)
        found.update(pid for pid, info in table.items() if info['ppid'] in found)
    for pid in found:
        if pid in table:
            record.setdefault('observed_processes', {})[str(pid)] = table[pid]


def output_postflight(record, owned):
    groups = {record['pgid'], *(info['pgid'] for info in record.get('observed_processes', {}).values())}
    record['observed_groups_after_drain'] = {str(pgid): group_exists(pgid) for pgid in groups}
    assert not any(record['observed_groups_after_drain'].values()), 'Owned group remains; preserve fixture'
    record['remaining_tmp_entries'] = sorted(item.name for item in owned.iterdir())
    # Test wrappers and the benchmark runner own internal fixture removal. Never archive a library.
    if record['remaining_tmp_entries']:
        raise RuntimeError('Unremoved synthetic fixture; preserve it after drained groups')
    owned.rmdir()
    record['owned_tmpdir_absent'] = not owned.exists()


def run(label, command, env, timeout, cwd=REPO, temporary=False):
    global app_started, cleanup_used
    if app_started is None:
        app_started = time.monotonic()
    remaining = APP_BUDGET - (time.monotonic() - app_started - cleanup_used)
    if remaining <= 0:
        raise RuntimeError('Overall application-command budget exhausted')
    limit = min(timeout, remaining)
    record = {'label': label, 'command': list(map(str, command)), 'limit_seconds': limit, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    commands.append(record)
    actual_env = dict(env)
    owned = ROOT / (label + '-tmp')
    if temporary:
        owned.mkdir(mode=0o700)
        actual_env['TMPDIR'] = str(owned)
        record['explicit_environment'] = {'TMPDIR': str(owned)}
    record['cwd'] = str(cwd)
    print('START ' + label, flush=True)
    started = time.monotonic()
    with (ROOT / f'{label}.stdout.log').open('wb') as stdout, (ROOT / f'{label}.stderr.log').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=cwd, env=actual_env, stdout=stdout, stderr=stderr, start_new_session=True)
        record.update(pid=child.pid, pgid=child.pid)
        record['proc_start'] = Path(f'/proc/{child.pid}/stat').read_text().split(') ', 1)[1].split()[19]
        try:
            while child.poll() is None:
                observe_tree(record)
                if time.monotonic() - started >= limit:
                    raise subprocess.TimeoutExpired(command, limit)
                time.sleep(0.02)
            record['exit_code'] = child.wait()
            observe_tree(record)
        except subprocess.TimeoutExpired:
            record['timed_out'] = True
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            record['exit_code'] = child.wait(timeout=CLEANUP_ALLOWANCE - cleanup_used)
        record['application_elapsed_seconds'] = time.monotonic() - started
    drain_group(record)
    if temporary:
        cleanup_started = time.monotonic()
        try:
            output_postflight(record, owned)
        finally:
            cleanup_used += time.monotonic() - cleanup_started
    record['source_unchanged'] = tracked() == receipt['source_before']
    record['base_source_unchanged'] = tracked(BASE) == receipt['base_source_before']
    if 'compiled_candidate' in receipt:
        record['compiled_unchanged'] = compiled() == receipt['compiled_candidate']
    if 'base_compiled_candidate' in receipt:
        record['base_compiled_unchanged'] = compiled(BASE) == receipt['base_compiled_candidate']
    save()
    print('END ' + label + ' exit=' + str(record['exit_code']), flush=True)
    if record['exit_code'] or not record['source_unchanged'] or not record['base_source_unchanged'] or record.get('compiled_unchanged') is False or record.get('base_compiled_unchanged') is False:
        raise RuntimeError('STOP after failed command or pin mismatch: ' + label)

try:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == EXPECTED
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
    assert (REPO / 'node_modules').is_dir()
    receipt['source_before'] = tracked()
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=BASE, text=True).strip() == PARENT
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=BASE, text=True)
    receipt['base_source_before'] = tracked(BASE)
    assert hashlib.sha256(json.dumps(receipt['source_before'],sort_keys=True,separators=(',',':')).encode()).hexdigest() == 'b7aac6e6137652f89be48fdf43b9dff6b79e8a6bb7063c2e4b3cbd2d1a3412c9'
    receipt['compiled_before_build'] = compiled()
    assert hashlib.sha256(json.dumps(receipt['compiled_before_build'],sort_keys=True,separators=(',',':')).encode()).hexdigest() == '8eaa2d75cacc00c9e6535be984862b5c4f3c0d68ac19dae495d560bceed3ffc0'
    receipt['base_compiled_before_build'] = compiled(BASE)
    receipt['bundles_before'] = {str(repo): hashlib.sha256((repo/'packages/cli/bundle/index.js').read_bytes()).hexdigest() for repo in [REPO, BASE] if (repo/'packages/cli/bundle/index.js').exists()}
    receipt['tool_files'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [PNPM, REPO/'node_modules/.bin/tsc-rs', REPO/'pnpm-lock.yaml', REPO/'package.json', REPO/'node_modules/tsc-rs/package.json']}
    receipt['compiler_files'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (REPO/'node_modules/.pnpm').glob('**/tsc-rs*/**/*') if p.is_file() and p.stat().st_size>100000}

    receipt['runtime_hashes'] = {str(node): hashlib.sha256(node.read_bytes()).hexdigest() for node in [NODE20, NODE24]}
    receipt['runner_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    receipt['observation_policy'] = 'bounded source/hash/output verification; /proc process-tree ownership sampling outside inner timings; smoke timings not performance evidence; no preload or runtime implementation observer'
    receipt['planned_checks'] = ['typecheck', 'build', 'bundle', 'base-build', 'base-bundle', 'python-harness'] + [runtime + '-' + check for runtime in ['node20', 'node24'] for check in ['actual-ci', 'retention-ci', 'managed-smoke']]
    env = {key: value for key, value in os.environ.items() if not key.startswith('HTML_INBOX_') and key not in ['NODE_OPTIONS', 'NODE_TEST_CONTEXT']}
    env['PATH'] = str(NODE24.parent) + os.pathsep + env['PATH']
    receipt['environment_policy'] = 'inherit env minus HTML_INBOX_*, NODE_OPTIONS, NODE_TEST_CONTEXT; exact Node24 bin first on PATH; only explicit per-test observer variables added'
    save()
    run('node24-version', [NODE24, '--version'], env, 30)
    run('node20-version', [NODE20, '--version'], env, 30)
    assert (ROOT / 'node24-version.stdout.log').read_text().strip() == 'v24.19.0'
    assert (ROOT / 'node20-version.stdout.log').read_text().strip() == 'v20.20.2'
    run('typecheck', [NODE24, PNPM, 'typecheck'], env, 120)
    run('build', [NODE24, PNPM, 'build'], env, 120)
    receipt['compiled_candidate'] = compiled()
    run('bundle', [NODE24, PNPM, '--filter', 'html-inbox', 'bundle'], env, 180)
    run('base-build', [NODE24, PNPM, 'build'], env, 120, cwd=BASE)
    receipt['base_compiled_candidate'] = compiled(BASE)
    run('base-bundle', [NODE24, PNPM, '--filter', 'html-inbox', 'bundle'], env, 180, cwd=BASE)
    receipt['bundles_candidate'] = {str(repo): hashlib.sha256((repo/'packages/cli/bundle/index.js').read_bytes()).hexdigest() for repo in [REPO, BASE]}
    save()
    run('python-harness', ['python3', '-m', 'unittest', 'discover', '-s', 'scripts/bench', '-p', 'test_*.py'], env, 30, temporary=True)
    for runtime, node in [('node20', NODE20), ('node24', NODE24)]:
        run(runtime+'-actual-ci', [node, '--test', 'packages/cli/dist/managed-view-regressions.test.js'], env, 90, temporary=True)
        run(runtime+'-retention-ci', [node, '--test', 'packages/cli/dist/managed-view-retention-check.js'], env, 90, temporary=True)
        run(runtime+'-managed-smoke', ['python3', 'scripts/bench/run.py', 'managed-read', '--baseline-repo', BASE, '--node', node,
                                     '--counts', '1', '--sizes', '10240', '--samples', '1', '--timeout', '30', '--out', ROOT/(runtime+'-smoke')], env, 180, temporary=True)
    receipt['result'] = 'all 12 CI-route/harness smoke checks passed'
except BaseException as error:
    # Stop the one active owned command on runner/setup errors as well as timeouts.
    if commands and 'pgid' in commands[-1] and 'cleanup' not in commands[-1]:
        record = commands[-1]
        try:
            os.killpg(record['pgid'], signal.SIGKILL)
        except ProcessLookupError:
            pass
        drain_group(record)
    receipt['result'] = 'stopped'
    receipt['error'] = repr(error)
    raise
finally:
    receipt['source_after'] = tracked()
    receipt['compiled_after'] = compiled()
    receipt['base_compiled_after'] = compiled(BASE)
    receipt['base_source_after'] = tracked(BASE)
    receipt['base_git_status'] = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=BASE, text=True)
    receipt['bundles_after'] = {str(repo): hashlib.sha256((repo/'packages/cli/bundle/index.js').read_bytes()).hexdigest() for repo in [REPO, BASE] if (repo/'packages/cli/bundle/index.js').exists()}
    receipt['application_elapsed_seconds'] = time.monotonic() - app_started - cleanup_used if app_started else 0
    receipt['final_group_checks'] = {str(g): group_exists(g) for item in commands for g in {item.get('pgid', 0), *(info['pgid'] for info in item.get('observed_processes', {}).values())} if g}

    receipt['source_unchanged'] = receipt.get('source_before') == receipt['source_after']
    receipt['git_status'] = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
    receipt['not_run'] = [label for label in receipt.get('planned_checks', []) if label not in {item['label'] for item in commands}]
    receipt['owned_children_at_exit'] = own_children()
    receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({key: value for key, value in receipt.items() if key not in ['source_before', 'source_after', 'compiled_before_build', 'compiled_candidate', 'compiled_after', 'commands']}), flush=True)
