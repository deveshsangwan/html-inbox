"""Read-only validation of already captured evidence; executes no application code."""
import hashlib
import json
import os
from pathlib import Path

root = Path(__file__).resolve().parent
receipt = json.loads((root / 'receipt.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
roots = []
pids = set()
groups = set()
for command in receipt['commands']:
    pids.add(command['pid'])
    groups.add(command['pgid'])
    pids.update(map(int, command.get('observed_processes', {})))
    groups.update(value['pgid'] for value in command.get('observed_processes', {}).values())
    for line in (root / (command['label'] + '.stdout.log')).read_text().splitlines():
        content = line.removeprefix('# ').removeprefix('ℹ ')
        if not content.startswith('{'):
            continue
        value = json.loads(content)
        if 'fixtureRoot' in value:
            roots.append(value['fixtureRoot'])
        if value.get('pid'):
            pids.add(value['pid'])
        if value.get('processGroup'):
            groups.add(value['processGroup'])

inventory = {}
exports = []
for runtime in ['node20', 'node24']:
    output = root / (runtime + '-smoke')
    environment = json.loads((output / 'environment.json').read_text())
    roots.append(environment['fixture_root'])
    rows = [json.loads(line) for line in (output / 'samples.jsonl').read_text().splitlines()]
    results = []
    for row in rows:
        pids.add(row['pid'])
        groups.add(row['process_group'])
        value = json.loads(row['stdout'])
        if 'manifest' in value:
            results.append(value)
    assert len(results) == 8
    for manifest_file in output.rglob('snapshot-manifest.json'):
        snapshot = manifest_file.parents[2]
        manifest = json.loads(manifest_file.read_text())
        matches = [value for value in results if value['manifest'] == manifest and Path(value['outputDir']).name == snapshot.name]
        assert len(matches) == 1
        result = matches[0]
        marker = json.loads((snapshot / '__html-inbox/ownership.json').read_text())
        assert marker == {'schemaVersion': 1, 'ownerId': result['ownerId']}
        actual = {}
        for filename in sorted(snapshot.rglob('*')):
            assert not filename.is_symlink()
            if filename.is_file():
                data = filename.read_bytes()
                name = str(filename.relative_to(snapshot))
                actual[name] = {'sha256': sha(data), 'size': len(data)}
                inventory[str(filename.relative_to(root))] = actual[name]
        manifest_relative = str(manifest_file.relative_to(snapshot))
        assert set(actual) == {entry['path'] for entry in manifest['files']} | {manifest_relative}
        digest = hashlib.sha256()
        for entry in manifest['files']:
            assert actual[entry['path']] == {'sha256': entry['sha256'], 'size': entry['size']}
            for value in [entry['path'], entry['sha256'], str(entry['size'])]:
                digest.update(value.encode() + b'\0')
        assert digest.hexdigest() == manifest['snapshotHash']
        assert manifest['documentCount'] == 1
        exports.append(dict(runtime=runtime, output=str(snapshot.relative_to(root)), manifest=manifest_relative,
                            original_output_dir=result['outputDir'], owner=result['ownerId'], generated_at=manifest['generatedAt'],
                            snapshot_sha256=manifest['snapshotHash'], file_count=len(actual)))
assert len(exports) == 16 and len(inventory) == 160
for pid in pids:
    assert not Path('/proc/' + str(pid)).exists(), pid
for group in groups:
    try:
        os.killpg(group, 0)
    except ProcessLookupError:
        continue
    raise AssertionError(('remaining group', group))
for directory in roots:
    assert not Path(directory).exists(), directory
assert len(roots) == 6
(root / 'output-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
(root / 'export-manifests.json').write_text(json.dumps(exports, indent=2) + '\n')
(root / 'final-audit.json').write_text(json.dumps(dict(pids=sorted(pids), groups=sorted(groups), roots=roots,
    pids_absent=True, groups_absent=True, roots_absent=True, captured_files=len(inventory), verified_manifests=len(exports),
    proc_counter_disposition='unqualified parser defect recorded separately; zero values are not kernel-I/O evidence',
    prior_cleanup_receipt='retained original renderer-limited4-root inventory; final audit covers all6 roots'), indent=2) + '\n')
print(f'Validated {len(inventory)} output files, {len(exports)} full manifests, {len(pids)} absent PIDs, {len(groups)} absent groups and all6 roots')
