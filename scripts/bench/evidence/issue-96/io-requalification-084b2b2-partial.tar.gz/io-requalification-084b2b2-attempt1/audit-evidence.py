"""Read-only audit; does not import the tested parser or any application module."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIELDS = {'rchar', 'wchar', 'syscr', 'syscw', 'read_bytes', 'write_bytes', 'cancelled_write_bytes'}
sha = lambda data: hashlib.sha256(data).hexdigest()


def independent_snapshot(text):
    values = {}
    for line in text.splitlines():
        pair = line.split(':')
        assert len(pair) == 2 and pair[0] in FIELDS and pair[0] not in values
        digits = pair[1].strip()
        assert digits and all(48 <= ord(character) <= 57 for character in digits)
        values[pair[0]] = int(digits, 10)
    assert set(values) == FIELDS
    return values


def audit_runtime(runtime):
    output = ROOT / (runtime + '-smoke')
    rows = [json.loads(line) for line in (output / 'samples.jsonl').read_text().splitlines()]
    assert len(rows) == 18 and all(row['exit_code'] == 0 and row['stderr'] == '' for row in rows)
    behaviors = [json.loads(line) for line in (output / 'behavior.jsonl').read_text().splitlines()]
    assert len(behaviors) == 2
    expected = {value['label']: value['documents'] for value in behaviors}
    assert len(expected['owned-1']) == 1
    assert len(expected['mixed-origins-terminal-suppressed']) == 2
    assert sum(bool(value['metadata'].get('origin')) for value in expected['mixed-origins-terminal-suppressed']) == 1
    results = {}
    for row in rows:
        value = json.loads(row['stdout'])
        if 'manifest' in value:
            results[row['label']] = value
        if 'documents' in value:
            label = 'mixed-origins-terminal-suppressed' if '/mixed-origins-terminal-suppressed/' in row['label'] else 'owned-1'
            assert value['documents'] == expected[label]
            assert value['usesView'] == ('/candidate/' in row['label'])
    assert len(results) == 8
    manifests = []
    inventory = {}
    trees = {}
    for filename in sorted(output.rglob('snapshot-manifest.json')):
        tree = filename.parents[2]
        manifest = json.loads(filename.read_text())
        matches = [(label, result) for label, result in results.items() if Path(result['outputDir']).name == tree.name]
        assert len(matches) == 1
        label, result = matches[0]
        assert result['manifest'] == manifest
        owner = json.loads((tree / '__html-inbox/ownership.json').read_text())
        assert owner == {'schemaVersion': 1, 'ownerId': result['ownerId']}
        files = {}
        for file in sorted(tree.rglob('*')):
            assert not file.is_symlink()
            if file.is_file():
                data = file.read_bytes()
                files[str(file.relative_to(tree))] = dict(sha256=sha(data), size=len(data))
                inventory[str(file.relative_to(ROOT))] = files[str(file.relative_to(tree))]
        manifest_path = str(filename.relative_to(tree))
        assert set(files) == {entry['path'] for entry in manifest['files']} | {manifest_path}
        assert [entry['path'] for entry in manifest['files']] == sorted({entry['path'] for entry in manifest['files']})
        digest = hashlib.sha256()
        for entry in manifest['files']:
            assert files[entry['path']] == {'sha256': entry['sha256'], 'size': entry['size']}
            for value in [entry['path'], entry['sha256'], str(entry['size'])]:
                digest.update(value.encode() + b'\0')
        assert digest.hexdigest() == manifest['snapshotHash']
        assert manifest['documentCount'] == 1
        documents = expected['mixed-origins-terminal-suppressed' if '/mixed-origins-terminal-suppressed/' in label else 'owned-1']
        owned = [document for document in documents if not document['metadata'].get('origin')]
        bodies = {name for name in files if name.endswith('/content/index.html')}
        assert len(owned) == len(bodies) == 1
        assert files[next(iter(bodies))] == {'sha256': owned[0]['sha256'], 'size': owned[0]['bytes']}
        trees[label] = (tree, files)
        manifests.append(dict(label=label, tree=str(tree.relative_to(ROOT)), files=len(files), manifest=manifest,
                              owner=result['ownerId'], original_output_dir=result['outputDir']))
    assert len(manifests) == 8 and len(inventory) == 80
    pairs = []
    for baseline in [label for label in trees if '/baseline/' in label]:
        candidate = baseline.replace('/baseline/', '/candidate/')
        first, second = trees[baseline], trees[candidate]
        assert set(first[1]) == set(second[1])
        exact = baseline.endswith('/api-export')
        differences = []
        for name in first[1]:
            a, b = (first[0] / name).read_bytes(), (second[0] / name).read_bytes()
            if not exact and (name == '__html-inbox/ownership.json' or name.endswith('/snapshot-manifest.json')):
                if a != b:
                    differences.append(name)
            else:
                assert a == b, name
        pairs.append(dict(baseline=baseline, candidate=candidate, exact_all_bytes=exact, differing_nonce_files=differences))
    assert len(pairs) == 4 and sum(pair['exact_all_bytes'] for pair in pairs) == 2
    io = []
    for filename in sorted(output.glob('io-*.json')):
        profile = json.loads(filename.read_text())
        captured = profile['proc_io']
        before = independent_snapshot(captured['raw_before'])
        after = independent_snapshot(captured['raw_after'])
        delta = {name: after[name] - before[name] for name in FIELDS}
        assert before == captured['before'] and after == captured['after']
        assert delta == captured['delta'] == profile['io'] and all(value >= 0 for value in delta.values())
        native = profile['counts']
        reads = 3 if 'cli-export' in filename.name else 2
        assert profile['exitCode'] == 0
        assert native == dict(ledgerOpens=reads, checkedLedgerBytes=1901*reads, bodyOpens=1, bodyBytes=10240)
        assert delta['rchar'] >= native['checkedLedgerBytes'] + native['bodyBytes']
        assert delta['syscr'] >= native['ledgerOpens'] + native['bodyOpens']
        io.append(dict(file=filename.name, raw_before_sha256=sha(captured['raw_before'].encode()),
                       raw_after_sha256=sha(captured['raw_after'].encode()), before=before, after=after,
                       delta=delta, native=native, physical_io_positive_minimum=False))
    assert len(io) == 4
    cleanup = json.loads((output / 'cleanup.json').read_text())
    assert cleanup == {'fixture_root_removed': True, 'children_reaped': True}
    environment = json.loads((output / 'environment.json').read_text())
    assert not Path(environment['fixture_root']).exists()
    result = dict(runtime=runtime, manifests=manifests, file_inventory=inventory, paired_output=pairs, io=io,
                  fixture_root=environment['fixture_root'], cleanup=cleanup, application_module_imports=False,
                  pids=[row['pid'] for row in rows], groups=[row['process_group'] for row in rows])
    (ROOT / (runtime+'-independent-audit.json')).write_text(json.dumps(result, indent=2)+'\n')
    print(f'AUDIT {runtime}:80 output files,8 manifests,4 raw I/O profiles; independent recomputation passed',flush=True)
    return result


def final_cleanup_audit():
    receipt = json.loads((ROOT/'receipt.json').read_text())
    pids = set()
    groups = set()
    roots = []
    for command in receipt['commands']:
        pids.add(command['pid'])
        groups.add(command['pgid'])
        pids.update(map(int,command.get('observed_processes',{})))
        groups.update(value['pgid'] for value in command.get('observed_processes',{}).values())
        if 'explicit_environment' in command:
            roots.append(command['explicit_environment']['TMPDIR'])
    for runtime in ['node20','node24']:
        audit = json.loads((ROOT/(runtime+'-independent-audit.json')).read_text())
        pids.update(audit['pids']);groups.update(audit['groups']);roots.append(audit['fixture_root'])
    for pid in pids:
        assert not Path('/proc/'+str(pid)).exists(),pid
    for group in groups:
        try:
            os.killpg(group,0)
        except ProcessLookupError:
            continue
        raise AssertionError(('remaining group',group))
    for path in roots:
        assert not Path(path).exists(),path
    assert receipt['owned_children_at_exit']==[] and not any(receipt['final_group_checks'].values())
    result=dict(pids=sorted(pids),groups=sorted(groups),roots=roots,all_absent=True,
                adopted_reaped=[item for row in receipt['commands'] for item in row['cleanup']['adopted_reaped']],
                signals=[item for row in receipt['commands'] for item in row['cleanup']['signals']])
    (ROOT/'cleanup-postflight.json').write_text(json.dumps(result,indent=2)+'\n')
    print(f'FINAL CLEANUP:{len(pids)} PIDs,{len(groups)} groups,{len(roots)} roots absent')
    return result


if __name__=='__main__':
    final_cleanup_audit()
