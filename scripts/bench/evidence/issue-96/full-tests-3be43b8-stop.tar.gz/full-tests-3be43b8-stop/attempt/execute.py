import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
MANIFEST_SHA256 = '5ee20b560323ea4a8a184d18a48ccbdba26ed9079fffc0e10c5b0d740c421ec5'
parser = argparse.ArgumentParser()
parser.add_argument('--expected-head', required=True)
parser.add_argument('--grant', required=True)
options = parser.parse_args()
if not re.fullmatch(r'[0-9a-fA-F]{40}', options.expected_head):
    parser.error('--expected-head requires a full40-hex immutable pin')
EXPECTED = options.expected_head.lower()
manifest_bytes = (ROOT/'manifest.json').read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == MANIFEST_SHA256
manifest = json.loads(manifest_bytes)
assert str(ROOT) == manifest['attempt_root'], 'Copy only to the bound fresh directory'
BASE = Path(manifest['parent_checkout'])
PARENT = manifest['parent_commit']
APP_BUDGET = 4500
CLEANUP_ALLOWANCE = 120
commands = []
app_started = time.monotonic()
app_deadline = app_started + APP_BUDGET
hard_deadline = app_deadline + CLEANUP_ALLOWANCE
cleanup_deadline = None
receipt = {'head': EXPECTED, 'base': PARENT, 'grant': options.grant, 'commands': commands,
           'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'manifest_sha256': MANIFEST_SHA256, 'controller_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'application_budget_seconds': APP_BUDGET, 'separate_cleanup_allowance_seconds': CLEANUP_ALLOWANCE,
           'application_absolute_deadline_monotonic': app_deadline, 'hard_absolute_deadline_monotonic': hard_deadline}


def save():
    (ROOT/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')


def remaining(deadline=None):
    deadline = deadline or cleanup_deadline or app_deadline
    seconds = deadline-time.monotonic()
    if seconds <= 0:
        raise RuntimeError('Absolute deadline exhausted; retain roots')

    return seconds


def git(*args, repo=REPO):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=repo, text=True, timeout=min(15, remaining())).strip()


def git_state(repo=REPO):
    index_path = Path(git('rev-parse', '--git-path', 'index', repo=repo))
    if not index_path.is_absolute():
        index_path = repo/index_path

    return {'head': git('rev-parse', 'HEAD', repo=repo),
            'head_ref': git('rev-parse', '--symbolic-full-name', 'HEAD', repo=repo),
            'staged_entries': git('ls-files', '--stage', '-z', repo=repo).split('\0'),
            'raw_index_sha256': hashlib.sha256(index_path.read_bytes()).hexdigest()}


def tracked(repo=REPO):
    names = git('ls-files', '-z', repo=repo).split('\0')
    return {name: hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in names if name and (repo/name).is_file()}


def file_map(directory, repo=REPO):
    result = {}
    for parent, directories, files in os.walk(directory, followlinks=False):
        remaining()
        for name in directories:
            assert not (Path(parent)/name).is_symlink(), 'Unexpected generated-directory link'
        for name in sorted(files):
            path = Path(parent)/name
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode), 'Unexpected generated-file type'
            result[str(path.relative_to(repo))] = {'bytes': info.st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

    return dict(sorted(result.items()))


def aggregate(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def identity(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().split(') ', 1)[1].split()
        return {'ppid': int(fields[1]), 'pgid': int(fields[2]), 'session': int(fields[3]),
                'start': fields[19], 'state': fields[0]}
    except (FileNotFoundError, ProcessLookupError):
        return None


def own_children():
    return [int(value) for value in Path(f'/proc/self/task/{os.getpid()}/children').read_text().split()]


def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


def observe_tree(record):
    table = {}
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            found = identity(int(path.name))
            if found:
                table[int(path.name)] = found
        except (PermissionError, ValueError, IndexError):
            record['unreadable_proc_entries_seen'] = True
    found = {record['pid'], *own_children()}
    previous = None
    while previous != len(found):
        previous = len(found)
        found.update(pid for pid, info in table.items() if info['ppid'] in found)
    for pid in found:
        if pid not in table:
            continue
        info = table[pid]
        if pid != record['pid'] and info['ppid'] == os.getpid():
            assert int(info['start']) >= int(record['proc_start']), 'Unknown older direct child; retain roots'
        old = record.setdefault('observed_processes', {}).get(str(pid))
        assert old is None or old['start'] == info['start'], 'Observed PID reused; retain roots'
        record['observed_processes'][str(pid)] = info
        record.setdefault('observed_groups', {})[str(info['pgid'])] = True
        try:
            argv = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        selected = [name for name in manifest['compiled_test_files'] if str(REPO/name).encode() in argv]
        if len(selected) == 1:
            record['sampled_test_file_selections'] = sorted(set(record.get('sampled_test_file_selections', [])) | set(selected))


def reap_adopted(record):
    # Never waitpid(-1): Popen alone owns the still-pending command's status.
    for pid in own_children():
        if pid == record['pid']:
            continue
        info = identity(pid)
        if info is None:
            continue
        expected = record.get('observed_processes', {}).get(str(pid))
        if expected is None:
            # Adoption can occur after observe_tree's snapshot. Establish identity
            # on the next pass before reaping; the child still prevents joined=True.
            continue

        assert expected['start'] == info['start'] and info['ppid'] == os.getpid()
        reaped, status = os.waitpid(pid, os.WNOHANG)
        if reaped:
            record.setdefault('adopted_exits', []).append({'pid': pid, 'start': info['start'], 'pgid': info['pgid'],
                'raw_status': status, 'exit_code': os.waitstatus_to_exitcode(status),
                'while_command_pending': record.get('exit_code') is None,
                'classification': 'Recorded exit; expectedness belongs to unchanged suite assertions, not exit0 inference'})


def signal_owned(record, pid, requested):
    expected = record.get('observed_processes', {}).get(str(pid))
    assert expected, 'Never signal an unobserved PID'
    if any(action['pid'] == pid and action['start'] == expected['start'] and action['signal'] == requested.name for action in record.get('controller_signals', [])):
        return
    try:
        descriptor = os.pidfd_open(pid)
    except ProcessLookupError:
        return
    try:
        current = identity(pid)
        if current is None:
            return
        assert current['start'] == expected['start'], 'Identity changed before signal; retain roots'
        try:
            signal.pidfd_send_signal(descriptor, requested)
        except ProcessLookupError:
            record.setdefault('signal_targets_already_exited', []).append(
                {'pid': pid, 'start': current['start'], 'requested_signal': requested.name})
            return

        record.setdefault('controller_signals', []).append({'pid': pid, 'start': current['start'], 'signal': requested.name})
    finally:
        os.close(descriptor)


def drain_group(record, child, failed=False):
    global cleanup_deadline
    if failed and cleanup_deadline is None:
        cleanup_deadline = min(hard_deadline, time.monotonic()+CLEANUP_ALLOWANCE)
        receipt['cleanup_absolute_deadline_monotonic'] = cleanup_deadline
        receipt['cleanup_started_monotonic'] = time.monotonic()
    deadline = cleanup_deadline if failed else record['absolute_deadline_monotonic']
    started = time.monotonic()
    while True:
        observe_tree(record)
        reap_adopted(record)
        code = child.poll()
        if code is not None:
            record['exit_code'] = code
        groups = {int(group): group_exists(int(group)) for group in record.get('observed_groups', {})}
        if code is not None and not own_children() and not any(groups.values()):
            record['cleanup'] = {'group_checks': groups, 'children_remaining': [], 'joined': True,
                                 'forced_failure_cleanup': failed, 'seconds': time.monotonic()-started}
            return
        remaining(deadline)
        if failed:
            requested = signal.SIGKILL if time.monotonic()-started >= 1 else signal.SIGTERM
            for pid, expected in list(record.get('observed_processes', {}).items()):
                current = identity(int(pid))
                if current and current['start'] == expected['start'] and current['state'] != 'Z':
                    signal_owned(record, int(pid), requested)
        time.sleep(min(0.05, remaining(deadline)))


def inventory(directory, hash_files=False):
    result = {}
    for parent, directories, files in os.walk(directory, followlinks=False):
        remaining(cleanup_deadline or app_deadline)
        for name in sorted([*directories, *files]):
            path = Path(parent)/name
            info = path.lstat()
            item = {'mode': info.st_mode, 'uid': info.st_uid, 'dev': info.st_dev, 'ino': info.st_ino, 'bytes': info.st_size}
            if stat.S_ISLNK(info.st_mode):
                item['link_not_followed'] = os.readlink(path)
            elif hash_files and stat.S_ISREG(info.st_mode):
                descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                try:
                    opened = os.fstat(descriptor)
                    assert (opened.st_dev, opened.st_ino) == (info.st_dev, info.st_ino)
                    with os.fdopen(descriptor, 'rb', closefd=False) as stream:
                        item['sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
                finally:
                    os.close(descriptor)
            result[str(path.relative_to(directory))] = item

    return result


def dispose_root(record, work):
    assert record['cleanup']['joined'] and not own_children()
    assert not any(group_exists(int(group)) for group in record['observed_groups'])
    info = work.lstat()
    identity_now = {'dev': info.st_dev, 'ino': info.st_ino, 'uid': info.st_uid, 'mode': stat.S_IMODE(info.st_mode)}
    assert stat.S_ISDIR(info.st_mode) and identity_now == record['work_root_identity'] and info.st_uid == os.getuid()
    assert identity_now['mode'] == 0o700 and shutil.rmtree.avoids_symlink_attacks
    assert not any((work/'tmp').iterdir()), 'Unexpected application TMPDIR residue; retain root'
    record['disposed_root_inventory'] = inventory(work)
    save()
    remaining()
    current = work.lstat()
    assert (current.st_dev, current.st_ino, current.st_uid) == (info.st_dev, info.st_ino, os.getuid())
    shutil.rmtree(work)
    record['work_root_absent'] = not work.exists()


def verify_inputs():
    current = tracked()
    reusable = {name for name in current if not name.startswith(('docs/', 'scripts/bench/evidence/')) or name.endswith(('.ts', '.tsx', '.mts', '.cts'))}
    assert {name: current[name] for name in reusable} == manifest['reusable_inputs']
    assert git('rev-parse', 'HEAD') == EXPECTED and not git('status', '--porcelain=v1')
    assert git('merge-base', 'HEAD', PARENT) == PARENT
    assert git('rev-parse', 'HEAD', repo=BASE) == PARENT and not git('status', '--porcelain=v1', repo=BASE)
    assert tracked(BASE) == manifest['parent_tracked']
    assert file_map(REPO/'packages/cli/dist') == manifest['candidate_compiled']
    assert file_map(REPO/'packages/cli/bundle') == manifest['candidate_bundle']
    assert file_map(BASE/'packages/cli/dist', BASE) == manifest['parent_compiled']
    assert file_map(BASE/'packages/cli/bundle', BASE) == manifest['parent_bundle']
    for name, expected in manifest['identity_files'].items():
        remaining()
        info = Path(name).stat()
        assert {'bytes': info.st_size, 'sha256': hashlib.sha256(Path(name).read_bytes()).hexdigest()} == expected, name
    for directory, expected in manifest['fresh_dependency_trees'].items():
        assert inventory(Path(directory), hash_files=True) == expected, 'Fresh dependency identity changed: '+directory
    return current


def verify_tarball():
    pack = Path(manifest['package_output'])
    assert sorted(path.name for path in pack.iterdir()) == ['html-inbox-0.6.1.tgz']
    result = {}
    with tarfile.open(manifest['tarball'], 'r:gz') as archive:
        for member in archive:
            remaining()
            assert member.isfile() and member.name not in result and member.name in manifest['package_members']
            expected = manifest['package_members'][member.name]
            assert member.size == expected['bytes']
            with archive.extractfile(member) as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            assert digest == expected['sha256']
            result[member.name] = {**expected, 'mode': member.mode}
    assert set(result) == set(manifest['package_members'])
    receipt['package_members'] = result
    path = Path(manifest['tarball'])
    receipt['tarball'] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    save()


def verify_reused_pack():
    accepted = manifest['reused_pack']
    prior_bytes = Path(accepted['receipt']).read_bytes()
    assert hashlib.sha256(prior_bytes).hexdigest() == accepted['receipt_sha256']
    prior = json.loads(prior_bytes)
    audit_bytes = Path(accepted['root_artifact_audit']).read_bytes()
    assert hashlib.sha256(audit_bytes).hexdigest() == accepted['root_artifact_audit_sha256']
    audit = json.loads(audit_bytes)
    assert audit['boundedPackArtifactAcceptance']['backupAndCurrentMatchMeasured']
    assert prior['head'] == accepted['source_head'] and prior['result'] == accepted['original_result']
    assert prior['incomplete'] == accepted['original_incomplete']
    pack_commands = [command for command in prior['commands'] if command['label'] == 'npm-pack']
    assert len(pack_commands) == 1 and pack_commands[0]['exit_code'] == 0
    assert pack_commands[0]['cleanup']['joined']
    assert pack_commands[0]['compiled_after_pack'] == manifest['candidate_compiled']
    assert pack_commands[0]['bundle_after_pack'] == manifest['candidate_bundle']

    backup = Path(manifest['measured_backup'])
    assert file_map(backup, backup) == {**manifest['candidate_compiled'], **manifest['candidate_bundle']}
    verify_tarball()
    assert receipt['tarball']['sha256'] == accepted['tarball_sha256'] == prior['tarball']['sha256']
    receipt['reused_pack'] = accepted
    receipt['reused_artifact_paths_read_only'] = [manifest['measured_backup'], manifest['package_output']]
    save()


def inspect_installed_package(record, work):
    if record['label'] not in ('node20-package', 'node24-package') or record.get('installed_package'):
        return
    for fixture in (work/'tmp').glob('html-inbox-package-*'):
        package = fixture/'consumer/node_modules/html-inbox'
        executable = package/'bundle/index.js'
        for pid, observed in list(record.get('observed_processes', {}).items()):
            try:
                current = identity(int(pid))
                if not current or current['start'] != observed['start']:
                    continue
                argv = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                continue
            if str(executable).encode() not in argv:
                continue
            # An installed-CLI invocation follows the script's awaited npm install.
            # No extraction-completion guess or new application hook is used.
            try:
                runtime = Path(os.readlink(f'/proc/{pid}/exe')).resolve()
            except (FileNotFoundError, ProcessLookupError):
                # A completed invocation supplies no stable runtime observation.
                continue

            assert runtime == Path(record['argv'][0]).resolve(), 'Installed CLI runtime differs'
            actual = file_map(package, package)
            expected = {name.removeprefix('package/'): value for name, value in manifest['package_members'].items()}
            assert actual == expected, 'Installed package bytes/member set differ from packed artifact'
            record['installed_package'] = {'fixture': str(fixture), 'invoking_pid': int(pid), 'start': current['start'],
                'members': actual, 'observation': 'Read-only while unchanged package smoke invoked installed CLI; no preload/capture wrapper'}
            return


def audit_log(record):
    text = (ROOT/(record['label']+'.stdout.log')).read_text(errors='replace')+'\n'+(ROOT/(record['label']+'.stderr.log')).read_text(errors='replace')
    roots = re.findall(r'"fixtureRoot":"([^"\n]+)"', text)
    record['diagnostic_fixture_roots'] = sorted(set(roots))
    assert all(not Path(path).exists() for path in roots), 'Managed probe fixture remains'
    record['native_summaries'] = re.findall(r'^(?:#|ℹ) (?:tests|pass|fail|cancelled|skipped) \d+$', text, re.MULTILINE)
    record['output_capture'] = 'No preload. Unsupported internal export outputs are unobserved; logs/TGZ/installed hashes only.'
    if record['label'].endswith('-package'):
        assert record.get('installed_package'), 'Installed package identity was not observed; no qualification credit'


def run(spec):
    label = spec['label']
    assert remaining() >= spec['limit_seconds'], 'Insufficient full-command budget: '+label
    work = Path(spec['work_root'])
    work.mkdir(mode=0o700)
    for name in ['home', 'tmp', 'catalog', 'npm-cache']:
        (work/name).mkdir(mode=0o700)
    info = work.lstat()
    assert stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) == 0o700
    for name in ['home', 'tmp', 'catalog', 'npm-cache']:
        created = (work/name).lstat()
        assert stat.S_ISDIR(created.st_mode) and created.st_uid == os.getuid() and stat.S_IMODE(created.st_mode) == 0o700
    record = {**spec, 'work_root_identity': {'dev': info.st_dev, 'ino': info.st_ino, 'uid': info.st_uid, 'mode': stat.S_IMODE(info.st_mode)},
              'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': None,
              'absolute_deadline_monotonic': min(app_deadline, time.monotonic()+spec['limit_seconds'])}
    commands.append(record)
    child = None
    print('START '+label, flush=True)
    try:
        with (ROOT/(label+'.stdout.log')).open('xb') as stdout, (ROOT/(label+'.stderr.log')).open('xb') as stderr:
            child = subprocess.Popen(spec['argv'], cwd=spec['cwd'], env=spec['environment'], stdout=stdout, stderr=stderr, start_new_session=True)
            record.update(pid=child.pid, pgid=child.pid)
            first = identity(child.pid)
            assert first, 'Spawned process identity unavailable; preserve roots and report'
            record['proc_start'] = first['start']
            record['observed_processes'] = {str(child.pid): first}
            record['observed_groups'] = {str(child.pid): True}
            assert first['ppid'] == os.getpid() and first['pgid'] == child.pid
            save()
            while child.poll() is None:
                observe_tree(record)
                reap_adopted(record)
                inspect_installed_package(record, work)
                time.sleep(min(0.1, remaining(record['absolute_deadline_monotonic'])))
            record['exit_code'] = child.returncode
            drain_group(record, child)
        assert record['exit_code'] == 0, 'First nonzero command: '+label
        if label.endswith('-version'):
            assert (ROOT/(label+'.stdout.log')).read_text().strip() == spec['expected_stdout']
        audit_log(record)
        source_after = verify_inputs()
        record['source_after_aggregate'] = aggregate(source_after)
        assert source_after == receipt['source_before']
        dispose_root(record, work)
        record['completed'] = True
        print('END '+label+' exit=0', flush=True)
    except BaseException as error:
        receipt.setdefault('application_stopped_monotonic', time.monotonic())
        record['error'] = repr(error)
        record['root_retained'] = str(work)
        if child and 'proc_start' in record:
            try:
                drain_group(record, child, failed=True)
            except BaseException as cleanup_error:
                record['cleanup_error'] = repr(cleanup_error)
        elif child:
            record['cleanup_error'] = 'Spawn identity unavailable; no speculative signal. Preserve roots; settlement unproven.'
        raise
    finally:
        save()


try:
    root_identity = ROOT.lstat()
    assert stat.S_ISDIR(root_identity.st_mode) and root_identity.st_uid == os.getuid() and stat.S_IMODE(root_identity.st_mode) == 0o700
    assert hasattr(os, 'pidfd_open') and hasattr(signal, 'pidfd_send_signal') and shutil.rmtree.avoids_symlink_attacks
    controller = identity(os.getpid())
    assert controller and controller['start'], 'Controller self identity unavailable'
    receipt['controller_identity'] = {'pid': os.getpid(), **controller, 'argv': [sys.executable, *sys.argv]}
    assert not own_children(), 'Controller must start without unrelated direct children'
    assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0
    assert len(manifest['commands']) == 23 and sum(command['limit_seconds'] for command in manifest['commands']) == 3990
    assert sum(command['kind'] != 'version' for command in manifest['commands']) == 21
    assert sys.executable == manifest['python_executable'] and sys.version == manifest['python_version']
    assert {path.name for path in ROOT.iterdir()} == set(manifest['initial_files']), 'Fresh copied source directory required'
    assert all(not Path(path).exists() for path in manifest['must_be_absent_after_copy'])
    save()
    prior = Path(manifest['measured_receipt'])
    assert hashlib.sha256(prior.read_bytes()).hexdigest() == manifest['measured_receipt_sha256']
    receipt['source_before'] = verify_inputs()
    receipt['git_before'] = {'candidate': git_state(), 'parent': git_state(BASE)}
    receipt['reused_typecheck_limit'] = manifest['reused_typecheck_limit']
    receipt['fresh_dependency_snapshot_note'] = 'Present-day static inventory only; does not recover missing historical typecheck declarations.'
    receipt['observation_limits'] = '100ms /proc ancestry sampling can miss short-lived descendants. Adopted direct children are reaped during pending commands, excluding Popen-owned main status. Script cleanup assertions stay primary. No generic interruption/OS-close guarantee or independent remote/native cleanup proof.'
    receipt['source_manifest'] = manifest
    verify_reused_pack()
    for spec in manifest['commands']:
        run(spec)
        if spec['label'].endswith('-unit-2') or spec['label'].endswith('-gc'):
            runtime = spec['label'].split('-')[0]
            labels = [runtime+'-unit-1', runtime+'-unit-2'] if spec['label'].endswith('-unit-2') else [spec['label']]
            probe = 'managed-view-contract.cjs' if len(labels) == 2 else 'managed-view-retention.cjs'
            text = ''.join((ROOT/(label+'.stdout.log')).read_text(errors='replace') for label in labels)
            assert text.count('"probe":"'+probe+'"') == 1, 'Scoped probe entry must occur exactly once per runtime'
            receipt.setdefault('probe_entry_counts', {})[runtime+'/'+probe] = 1
    receipt['result'] = 'remaining full-qualification tests completed using accepted pack; root gate disposition and fresh reviews remain open'
except BaseException as error:
    receipt['result'] = 'stopped'
    receipt['error'] = repr(error)
    receipt.setdefault('application_stopped_monotonic', time.monotonic())
    if cleanup_deadline is None:
        cleanup_deadline = min(hard_deadline, time.monotonic()+CLEANUP_ALLOWANCE)
        receipt['cleanup_absolute_deadline_monotonic'] = cleanup_deadline
        receipt['cleanup_started_monotonic'] = time.monotonic()
    raise
finally:
    try:
        receipt['candidate_compiled_after'] = file_map(REPO/'packages/cli/dist')
        receipt['candidate_bundle_after'] = file_map(REPO/'packages/cli/bundle')
        receipt['parent_compiled_after'] = file_map(BASE/'packages/cli/dist', BASE)
        receipt['parent_bundle_after'] = file_map(BASE/'packages/cli/bundle', BASE)
        receipt['git_status_after'] = git('status', '--porcelain=v1')
        receipt['final_inputs_verified'] = aggregate(verify_inputs()) == aggregate(receipt.get('source_before'))
        receipt['git_after'] = {'candidate': git_state(), 'parent': git_state(BASE)}
        receipt['raw_index_bytes_equal'] = {}
        for role, after in receipt['git_after'].items():
            before = receipt['git_before'][role]
            assert all(before[name] == after[name] for name in ['head', 'head_ref', 'staged_entries']), 'Tracked Git state changed: '+role
            receipt['raw_index_bytes_equal'][role] = before['raw_index_sha256'] == after['raw_index_sha256']
    except BaseException as final_error:
        receipt['final_provenance_error'] = repr(final_error)
        receipt['result'] = 'stopped'
    receipt['not_run'] = [item['label'] for item in manifest['commands'] if item['label'] not in {c['label'] for c in commands}]
    receipt['incomplete'] = [c['label'] for c in commands if not c.get('completed')]
    receipt['owned_children_at_exit'] = own_children()
    receipt['final_group_checks'] = {group: group_exists(int(group)) for c in commands for group in c.get('observed_groups', {})}
    finished = time.monotonic()
    application_finished = receipt.get('application_stopped_monotonic', finished)
    receipt['application_elapsed_seconds'] = application_finished-app_started
    receipt['application_within_deadline'] = application_finished <= app_deadline
    receipt['cleanup_elapsed_seconds'] = finished-receipt['cleanup_started_monotonic'] if cleanup_deadline else 0
    receipt['cleanup_within_deadline'] = finished <= cleanup_deadline if cleanup_deadline else True
    if not receipt['application_within_deadline'] or not receipt['cleanup_within_deadline']:
        receipt['result'] = 'stopped'
        receipt.setdefault('error', 'Qualification finished beyond its absolute deadline')

    receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({key: receipt.get(key) for key in ['result', 'error', 'not_run', 'incomplete', 'owned_children_at_exit', 'final_group_checks']}), flush=True)

if receipt['result'] == 'stopped' or receipt['owned_children_at_exit'] or any(receipt['final_group_checks'].values()):
    raise SystemExit(1)
