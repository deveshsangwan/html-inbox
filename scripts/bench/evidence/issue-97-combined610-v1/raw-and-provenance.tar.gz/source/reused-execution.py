#!/usr/bin/env python3
"""One ignored operational controller. Requires a separate explicit root grant."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tarfile
import tempfile
import time

state = {}
owned = {}
leaders = {}
interrupted = None


class Stop(Exception):
    pass


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.pending')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.chmod(0o600)
    temporary.replace(path)


def remember(kind, detail):
    issue = dict(kind=kind, detail=str(detail), monotonic=time.monotonic())
    state['issues'].append(issue)
    if state['first_unexpected'] is None:
        state['first_unexpected'] = issue
    write_json(state['out'] / 'receipt.json', serializable_state())


def require(condition, kind, detail):
    if not condition:
        remember(kind, detail)
        raise Stop(str(detail))


def serializable_state():
    return {**{key: value for key, value in state.items() if key not in ['out', 'scratch']},
            'output': str(state['out']), 'scratch': str(state['scratch']),
            'observed_processes': list(owned.values())}


def identity(pid):
    try:
        raw = Path(f'/proc/{pid}/stat').read_text()
        fields = raw[raw.rfind(')') + 2:].split()
        return dict(pid=int(pid), start_ticks=int(fields[19]), ppid=int(fields[1]),
                    group=int(fields[2]), session=int(fields[3]), state=fields[0])
    except (FileNotFoundError, ProcessLookupError):
        return None


def key(process):
    return f"{process['pid']}:{process['start_ticks']}"


def track(process, discovery):
    recorded = owned.setdefault(key(process), {**process, 'discovery': discovery, 'groups_seen': []})
    group = dict(group=process['group'], session=process['session'])
    if group not in recorded['groups_seen']:
        recorded['groups_seen'].append(group)
    recorded['latest_ppid'] = process['ppid']
    recorded['latest_state'] = process['state']


def refresh_owned():
    processes = []
    for entry in Path('/proc').iterdir():
        if entry.name.isdigit():
            try:
                process = identity(entry.name)
            except PermissionError:
                continue
            if process:
                processes.append(process)
    descendants = {os.getpid()}
    changed = True
    while changed:
        changed = False
        for process in processes:
            if process['ppid'] in descendants and process['pid'] not in descendants:
                descendants.add(process['pid'])
                track(process, 'controller-descendant')
                changed = True

    witnesses = {(p['group'], p['session']) for p in processes if key(p) in owned}
    for process in processes:
        if (process['group'], process['session']) in witnesses:
            track(process, 'verified-owned-group')

    for process in processes:
        if key(process) in owned and process['ppid'] == os.getpid() and key(process) not in leaders:
            try:
                pid, status = os.waitpid(process['pid'], os.WNOHANG)
                if pid:
                    state['adopted_exits'].append(dict(identity=process, wait_status=status))
            except ChildProcessError:
                pass
    for child in leaders.values():
        child.poll()
    return [p for p in processes if key(p) in owned and identity(p['pid']) is not None]


def matching_live():
    live = []
    for recorded in owned.values():
        current = identity(recorded['pid'])
        if current and current['start_ticks'] == recorded['start_ticks']:
            live.append(current)
    return live


def join_owned(label):
    actions = []
    for signum, seconds in [(signal.SIGTERM, 2), (signal.SIGKILL, 2)]:
        refresh_owned()
        live = matching_live()
        if not live or time.monotonic() >= state['final_deadline']:
            break
        groups = {}
        for process in live:
            if process['group'] == os.getpgrp():
                remember('ownership', 'Owned child shares controller group; refusing unsafe group signal')
                continue
            groups.setdefault(process['group'], process)
        for group, witness in groups.items():
            if time.monotonic() >= state['final_deadline']:
                break
            current = identity(witness['pid'])
            if current and current['start_ticks'] == witness['start_ticks'] and current['group'] == group:
                try:
                    os.killpg(group, signum)
                    actions.append(dict(signal=signum, group=group, witness=current))
                except ProcessLookupError:
                    pass
        phase_deadline = min(time.monotonic() + seconds, state['final_deadline'])
        while time.monotonic() < phase_deadline:
            refresh_owned()
            if not matching_live():
                break
            time.sleep(min(.025, max(0, phase_deadline - time.monotonic())))

    reap_deadline = min(time.monotonic() + 3, state['final_deadline'])
    while time.monotonic() < reap_deadline:
        refresh_owned()
        if not matching_live():
            break
        time.sleep(min(.025, max(0, reap_deadline - time.monotonic())))
    remaining = matching_live()
    state['cleanup'].append(dict(label=label, actions=actions, remaining=remaining,
                                 monotonic=time.monotonic(), final_deadline=state['final_deadline']))
    if remaining:
        remember('cleanup', f'{label}: remaining owned identities {remaining}')
    return not remaining


def run(command, label, bound, environment, cwd, stdout_name=None, defer_validation=False, setup_seconds=None):
    require(state['first_unexpected'] is None, 'continuation', 'Unexpected failure already recorded')
    require(not interrupted, 'interrupt', interrupted)
    started = time.monotonic()
    require(started < state['application_deadline'], 'application-budget', 'No application time remains')
    deadline = min(started + bound, state['application_deadline'])
    values = dict(repo=state['manifest']['repo'], scratch=str(state['scratch']),
                  workload=str(Path(state['manifest']['repo']) / state['manifest']['workload']))
    spec = state['manifest']['commands'][label]
    expected_command = [arg.format_map(values) for arg in spec['command']]
    expected_environment = {name: value.format_map(values) for name, value in spec.get('environment', {}).items()}
    require(command == expected_command and environment == expected_environment and
            str(cwd) == spec['cwd'].format_map(values) and bound == spec['bound_seconds'] and
            defer_validation == spec.get('defer_validation', False) and setup_seconds == spec.get('setup_seconds'),
            'command-manifest', label)
    fixture = state['scratch'] / f'fixture-{label}'
    fixture.mkdir()
    if spec.get('fixture_marker'):
        (fixture / '.issue95-fixture').write_text(spec['fixture_marker'])
    env = dict(PATH=state['node24_bin'] + ':/usr/local/bin:/usr/bin:/bin', LANG='C.UTF-8',
               HOME=str(fixture), USERPROFILE=str(fixture), TMPDIR=str(fixture), TMP=str(fixture), TEMP=str(fixture),
               XDG_CONFIG_HOME=str(fixture), XDG_STATE_HOME=str(fixture), XDG_DATA_HOME=str(fixture),
               XDG_CACHE_HOME=str(fixture), HTML_INBOX_CATALOG_HOME=str(fixture / 'catalog'), **environment)
    output = state['out'] / (stdout_name or f'{label}.tap')
    errors = state['out'] / f'{label}.stderr'
    row = dict(label=label, command=command, cwd=str(cwd), environment=env, fixture=str(fixture),
               started_monotonic=started, command_deadline=deadline, bound_seconds=bound, setup_seconds=None, exit=None)
    child = None
    try:
        with output.open('wb') as stdout, errors.open('wb') as stderr:
            child = subprocess.Popen(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL, start_new_session=True)
            process = identity(child.pid)
            require(process is not None and process['group'] == child.pid and process['session'] == child.pid,
                    'ownership', f'{label}: missing exact new-session leader identity')
            track(process, label)
            leaders[key(process)] = child
            row['identity'] = process
            write_json(state['out'] / 'current-command.json', row)
            while child.poll() is None:
                refresh_owned()
                if interrupted:
                    raise InterruptedError(interrupted)
                if setup_seconds is not None and row['setup_seconds'] is None:
                    elapsed = time.monotonic() - started
                    if elapsed >= setup_seconds:
                        raise TimeoutError(f'{label}: conservative setup observation exceeded {setup_seconds}s')
                    marker = fixture / 'setup-complete.json'
                    if marker.exists():
                        require(json.loads(marker.read_text()) == dict(count=0, direction='inbound'), 'setup-marker', label)
                        row['setup_seconds'] = elapsed
                if time.monotonic() >= deadline:
                    raise TimeoutError(f'{label}: command/application deadline reached')
                time.sleep(min(.025, max(0, deadline - time.monotonic())))
            row['exit'] = child.returncode
            refresh_owned()
            survivors = [p for p in matching_live() if p['state'] != 'Z']
            if survivors:
                remember('cleanup', f'{label}: live descendants after direct command exit {survivors}')
    except BaseException as error:
        row['error'] = repr(error)
        remember('command', f'{label}: {error!r}')
    finally:
        try:
            joined = join_owned(label)
        except BaseException as error:
            joined = False
            remember('cleanup', f'{label}: cleanup operation failed {error!r}')
        row.update(terminated_exit=child.returncode if child else None, group_joined=joined,
                   elapsed_seconds=time.monotonic() - started)
        for file in [output, errors]:
            if file.exists():
                original = file.read_bytes()
                row[file.suffix.lstrip('.') + '_original_sha256'] = hashlib.sha256(original).hexdigest()
                if defer_validation:
                    redacted = re.sub(rb'("controlToken"\s*:\s*")[^"]*(")', rb'\1<REDACTED>\2', original)
                    redacted = re.sub(rb"(controlToken:\s*)'[^']*'", rb"\1'<REDACTED>'", redacted)
                    file.write_bytes(redacted)
                file.chmod(0o600)
        if joined and time.monotonic() < state['final_deadline']:
            row['fixture_entries_before_removal'] = sorted(p.name for p in fixture.iterdir())
            try:
                shutil.rmtree(fixture)
            except BaseException as error:
                remember('fixture-cleanup', f'{label}: {error!r}')
        row['fixture_removed'] = not fixture.exists()
        state['commands'].append(row)
        write_json(state['out'] / 'receipt.json', serializable_state())
    if not defer_validation:
        require(row.get('exit') == 0 and not row.get('error') and row['group_joined'], 'command-result', row)
    return row, output


def tree_identity(directory, pattern):
    result = {}
    aggregate = hashlib.sha256()
    for file in sorted(directory.rglob(pattern)):
        require(time.monotonic() < state['application_deadline'], 'application-budget', 'Identity calculation exceeded application deadline')
        if file.is_symlink() or not file.is_file():
            continue
        relative = str(file.relative_to(directory))
        data = file.read_bytes()
        result[relative] = dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
                                git_blob_sha1=hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest())
        aggregate.update(relative.encode() + b'\0' + data)
    return dict(files=result, aggregate_sha256=aggregate.hexdigest(), count=len(result))


def tap_statistics(text):
    return {name: int(match.group(1)) if (match := re.search(r'^# ' + name + r' (\d+)$', text, re.M)) else None
            for name in ['tests', 'pass', 'fail', 'cancelled', 'skipped']}


def parse_regression(row, output):
    text = output.read_text()
    stats = tap_statistics(text)
    target = re.findall(r'^(not ok|ok) \d+ - an actual interval callback retains lifetime ownership until its read joins shutdown\s*$', text, re.M)
    result = dict(label=row['label'], command_exit=row['exit'], target_verdicts=target, tap_stats=stats,
                  qualification=False, raw_output=str(output))
    state['regression_results'].append(result)
    write_json(state['out'] / (row['label'] + '-classification.json'), result)
    require(row['exit'] == 0 and not row.get('error') and row['group_joined'] and target == ['ok'],
            'normal-regression', result)
    require(stats['pass'] == 1 and stats['fail'] == 0 and stats['cancelled'] == 0 and
            stats['skipped'] in [0, 12] and stats['tests'] == 1 + stats['skipped'], 'normal-regression-totals', stats)
    require(state['first_unexpected'] is None, 'normal-regression', 'Unexpected failure stops routed invocations')


def caller_kind(caller, dist):
    frames = caller.replace('\\n', '\n')
    worker = re.escape(str(dist / 'sync-worker.js')) + r':\d+:\d+'
    lifecycle = str(dist / 'sync-lifecycle.js')
    reconciliation = str(dist / 'sync-reconciliation.js')
    if re.search(r'at (?:async )?tick \(' + worker + r'\)', frames) and 'assertManagedLifecycle' not in frames:
        return 'archived-worker-observation-tick'
    if re.search(r'at (?:async )?(?:refreshSchedule|observeSchedule) \(' + worker + r'\)', frames):
        return 'archived-worker-serialized-observation'
    if lifecycle in frames and 'assertManagedLifecycle' in frames and re.search(r'at (?:async )?drain \(' + worker + r'\)', frames):
        return 'archived-worker-drain-lifecycle'
    if reconciliation in frames and re.search(r'at (?:async )?(?:reconcileSyncRoutes|pull|push|recordFailure) ', frames):
        return 'archived-worker-reconciliation'
    if re.search(r'at (?:async )?drain \(' + worker + r'\)', frames):
        return 'archived-worker-drain'
    return None


def parse_routed(row, output, role, dist):
    events, errors = [], []
    for line in output.read_text().splitlines():
        if not line.strip():
            continue
        try:
            event = json.loads(line)
            if not isinstance(event, dict):
                raise ValueError('event is not an object')
            events.append(event)
        except (json.JSONDecodeError, ValueError) as error:
            errors.append(f'Malformed workload output: {error}')
    result = dict(label=row['label'], revision=state['manifest'][role], command_exit=row['exit'],
                  classification='unclassified', passing_cell=False, qualification=False,
                  resource_gain_eligible=False, original_routed_caller='still-untagged',
                  original_feasibility_unrun=25, errors=errors, events_file=str(output))
    state['routed_results'].append(result)
    result_file = state['out'] / (row['label'] + '-classification.json')
    write_json(result_file, result)

    def check(condition, message):
        if not condition:
            errors.append(message)

    def one(kind, predicate=lambda item: True):
        found = [event for event in events if event.get('type') == kind and predicate(event)]
        check(len(found) == 1, f'Expected one {kind} event, observed {len(found)}')
        return found[0] if len(found) == 1 else None

    try:
        check(row.get('error') is None and row['group_joined'], 'Command deadline/ownership/join failure')
        check(row['setup_seconds'] is not None and row['setup_seconds'] < 90, 'Setup checkpoint was not observed within bound')
        caught = one('caught-up')
        if caught:
            check(caught['count'] == 0 and caught['direction'] == 'inbound', 'Wrong workload shape')
        idle_start, idle_stop = one('idle-start'), one('idle-stop')
        if idle_start:
            check(idle_start['count'] == 0 and idle_start['direction'] == 'inbound' and idle_start['duration'] == 65000,
                  'Wrong idle shape or duration')
        if idle_stop:
            observation = idle_stop['observations'][0]
            check(observation['elapsedMs'] >= 65000 and observation['completedPasses'] >= 2,
                  'Idle did not retain actual duration and two periodic completions')
        for label in ['explicit-wake', 'wall-forward', 'wall-backward', 'monotonic-gap', 'suspend-both', 'retry-deadline']:
            reaction = one('reaction-stop', lambda event: event.get('label') == label)
            if reaction:
                check(reaction['elapsedMs'] <= 30000, f'{label}: original reaction bound failed')
        retry = one('retry-reaction')
        if retry:
            check(retry['requestAt'] >= retry['deadlineAt'], 'Request preceded persisted retry deadline')
        custody, repair = one('external-commit-custody'), one('repair-complete')
        if custody:
            check(custody['state'] == 'live' and custody['elapsedMs'] <= 65000, 'External custody bound/state failure')
        if repair:
            check(repair['elapsedMs'] <= 65000, 'Lost-body repair exceeded original bound')
        one('stale-route-rejected')
        barrier = one('controlled-read-hold-barrier')
        if barrier:
            check(barrier['armed'] and barrier['traceReadsFromStartup'] and barrier['readTracingInstalled'] and
                  barrier['activeReads'] == [], 'Controlled startup tracking/no-active barrier missing')
            tickets = [ticket for ticket in barrier['status']['tickets'] if ticket['ticketId'] == barrier['ticketId']]
            check(len(tickets) == 1 and tickets[0]['state'] == 'complete' and tickets[0]['error'] is None,
                  'Barrier ticket did not complete without error')
        worker_start = one('child-started', lambda event: event.get('role') == 'worker')
        peer_start = one('child-started', lambda event: event.get('role') == 'peer')
        worker_ready = one('ready', lambda event: event.get('role') == 'worker')
        peer_ready = one('ready', lambda event: event.get('role') == 'peer')
        cleanup = one('cleanup')
        if cleanup:
            check(cleanup['failures'] == [] and cleanup['childrenReaped'] == 2, 'Process/listener cleanup failed')
            if worker_ready and peer_ready:
                check(len(cleanup['exactPorts']) == 2 and set(cleanup['exactPorts']) ==
                      {worker_ready['record']['controlOrigin'], peer_ready['url']}, 'Exact listener teardown identities mismatch')
        held = one('read-held')
        closed = one('worker-event', lambda event: event.get('role') == 'worker' and event.get('event') == 'closed')
        if not all([barrier, worker_start, peer_start, worker_ready, peer_ready, cleanup, held, closed]):
            raise ValueError('Missing prerequisite event; absent caller is not cause evidence')
        worker_pid = worker_start['pid']
        check(worker_ready['pid'] == worker_pid and peer_start['pid'] == peer_ready['pid'], 'Child identity mismatch')
        read_id, store_id = held['readId'], held['storeId']
        check(type(read_id) is int and read_id > 0 and type(store_id) is int and store_id > 0,
              'Missing valid process-local read/store IDs')
        check(held['role'] == 'worker' and held['pid'] == worker_pid and held['scriptStore'] is False,
              'Hold captured an unfamiliar process/store owner')
        caller = held.get('caller') or ''
        kind = caller_kind(caller, dist)
        check(bool(kind), 'Actual archived worker-owned caller is absent or unfamiliar')
        def has_selected(active):
            return any(read.get('readId') == read_id and read.get('storeId') == store_id and
                       read.get('scriptStore') is False for read in active)
        check(has_selected(held['activeReads']), 'Selected read was not active at hold')
        stops = [event for event in events if event.get('type') == 'stopping' and event.get('role') == 'worker']
        check(bool(stops) and all(event.get('pid') == worker_pid for event in stops), 'Missing or foreign stop event')
        if stops:
            check(has_selected(stops[0]['activeReads']) and held['monotonic'] <= stops[0]['monotonic'] <= closed['monotonic'],
                  'Selected read/stop/close ordering or active-state mismatch')
        check(closed['pid'] == worker_pid, 'Close came from another worker')
        arm_replies = [event for event in events if event.get('type') == 'reply' and event.get('role') == 'worker' and
                       isinstance(event.get('result'), dict) and event['result'].get('armed') and
                       event['result'].get('ticketId') == barrier['ticketId']]
        check(len(arm_replies) == 1 and arm_replies[0]['pid'] == worker_pid and
              arm_replies[0]['monotonic'] <= held['monotonic'], 'No atomic pre-hold arm proof on the same worker clock')
        releases = [event for event in events if event.get('type') == 'read-released']
        finishes = [event for event in events if event.get('type') == 'read-finished']
        for event in releases + finishes:
            check(event.get('role') == 'worker' and event.get('pid') == worker_pid and
                  event.get('readId') == read_id and event.get('storeId') == store_id, 'Release/finish identity mismatch')
        check(len(releases) <= 1 and len(finishes) <= 1, 'Duplicate selected-read release/finish')
        active_at_close = has_selected(closed['activeReads'])
        result.update(read_id=read_id, store_id=store_id, worker_pid=worker_pid, caller=caller, caller_kind=kind,
                      held=held, stop_events=stops, closed=closed, active_at_close=active_at_close,
                      release_events=releases, finish_events=finishes,
                      release_observation='observed' if releases else 'not-observed',
                      completion_observation='observed' if finishes else 'not-observed',
                      read_joined_before_close=None)
        failures = [event for event in events if event.get('type') == 'workload-failed']
        result['workload_failures'] = failures
        if row['exit'] == 0:
            check(not failures, 'Successful process emitted workload-failed')
            check(len(releases) == 1 and len(finishes) == 1, 'Successful case lacks actual release or completion')
            if len(releases) == len(finishes) == 1:
                release, finish = releases[0], finishes[0]
                check(release['reason'] == 'rpc' and finish['outcome'] == 'fulfilled' and
                      held['monotonic'] <= release['monotonic'] <= finish['monotonic'] <= closed['monotonic'],
                      'Read was not released/completed before successful close on the same worker clock')
            check(not active_at_close and closed['activeReads'] == [], 'Successful close retained pending reads')
            resources = one('shutdown-resources')
            if resources:
                check(resources['stopped'] is True, 'Shutdown resource reply did not confirm stop')
            one('pending-read-shutdown-joined')
            result.update(classification='routed-strict-control-passed', control_passed=True,
                          read_joined_before_close=not active_at_close)
        elif row['exit'] == 1 and role == 'parent':
            check(len(failures) == 1, 'Parent failure lacks a unique original workload error')
            error = failures[0].get('error', '') if len(failures) == 1 else ''
            targets = [str(Path(row['fixture']) / 'receiver/sync/worker' / name) for name in ['lifetime.lock', 'runtime.json']]
            known_error = any(error.startswith("Error: ENOENT: no such file or directory, lstat '" + target + "'") for target in targets)
            check(known_error and str(Path(state['manifest']['repo']) / state['manifest']['workload']) + ':' in error,
                  'Unfamiliar parent error; not the original strict ownership assertion')
            check(active_at_close, 'Strict parent failure lacks the selected read active at close')
            check(all(event['monotonic'] > closed['monotonic'] for event in releases + finishes),
                  'Selected read was released/completed before parent close')
            result.update(classification='newly-tagged-baseline-ownership-failure', control_passed=False,
                          read_joined_before_close=False,
                          failure_path_note='Ownership assertion precedes release RPC. Missing release/finish are retained as not-observed, never invented or joined.')
        else:
            errors.append('Unexpected workload exit; candidate must satisfy the unchanged strict control')
    except (KeyError, TypeError, ValueError, IndexError) as error:
        errors.append(f'Incomplete or malformed routed evidence: {error!r}')
    if errors:
        result['classification'] = 'unexpected-or-incomplete-evidence'
    write_json(result_file, result)
    for error in errors:
        remember('routed-setup-caller-contract-or-cleanup', error)
    require(state['first_unexpected'] is None, 'routed-result', 'Unexpected evidence stops the next invocation')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--grant-id', required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    out = Path(manifest['output'])
    out.mkdir(parents=True, exist_ok=False, mode=0o700)
    scratch = Path(tempfile.mkdtemp(prefix='html-inbox-issue95-routed-'))
    started = time.monotonic()
    application_deadline = started + 900
    final_deadline = application_deadline + 60
    state.update(out=out, scratch=scratch, started_monotonic=started, started_wall_ns=time.time_ns(),
                 application_deadline=application_deadline, final_deadline=final_deadline, grant_id=args.grant_id,
                 controller_identity=identity(os.getpid()), manifest=manifest,
                 node24_bin=str(Path(manifest['runtimes']['24.19.0']['path']).parent),
                 first_unexpected=None, issues=[], commands=[], cleanup=[], adopted_exits=[], signals=[],
                 regression_results=[], routed_results=[], identities={})
    def interrupt(signum, _frame):
        global interrupted
        interrupted = f'Received signal {signum}'
        state['signals'].append(dict(signal=signum, monotonic=time.monotonic()))
    try:
        require(bool(args.grant_id.strip()), 'grant-metadata', 'Grant identifier is empty')
        require(ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0, 'ownership', 'Could not become child subreaper')
        signal.signal(signal.SIGTERM, interrupt)
        signal.signal(signal.SIGINT, interrupt)
        require(hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == manifest['controller_sha256'], 'pin', 'Controller source mismatch')
        repo = Path(manifest['repo'])
        for filename, digest in manifest['accepted_source_sha256'].items():
            require(hashlib.sha256((repo / filename).read_bytes()).hexdigest() == digest, 'pin', filename)
        for filename, digest in manifest['compiler_dependency_sha256'].items():
            require(hashlib.sha256(Path(filename).read_bytes()).hexdigest() == digest, 'compiler-dependency', filename)
        for label in ['pin', 'status', 'production-frozen']:
            spec = manifest['commands'][label]
            _, output = run(spec['command'], label, spec['bound_seconds'], {}, repo)
            require(output.read_text().strip() == spec['expected_stdout'], 'pin', label)
        for version, runtime in manifest['runtimes'].items():
            require(hashlib.sha256(Path(runtime['path']).read_bytes()).hexdigest() == runtime['sha256'], 'runtime', version)
            _, output = run([runtime['path'], '--version'], 'node-' + version, 5, {}, repo)
            require(output.read_text().strip() == 'v' + version, 'runtime', version)
        builds = {}
        for role, revision in [('parent', manifest['parent']), ('candidate', manifest['candidate']), ('regression', manifest['source_pin'])]:
            build = scratch / ('build-' + role)
            build.mkdir()
            command = [manifest['git'], 'archive', revision, *manifest['archive_paths']]
            _, archive = run(command, 'archive-' + role, 15, {}, repo, stdout_name='archive-' + role + '.tar')
            with tarfile.open(archive) as tar:
                tar.extractall(build, filter='data')
            sources = tree_identity(build, '*')
            identities = dict(revision=revision, sources=sources, compiled=None,
                              archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
            state['identities'][role] = identities
            write_json(out / ('identities-' + role + '.json'), identities)
            actual_blobs = {name: data['git_blob_sha1'] for name, data in sources['files'].items()}
            require(actual_blobs == manifest['source_git_blobs'][role], 'archive-source-identity', role)
            if role == 'regression':
                previous = state['identities']['candidate']['sources']['files']
                changed = {name for name in set(previous) | set(sources['files']) if previous.get(name) != sources['files'].get(name)}
                require(changed == {manifest['allowed_source_delta']}, 'regression-source-isolation', sorted(changed))
            (build / 'node_modules').symlink_to(repo / 'node_modules', target_is_directory=True)
            command = [manifest['compiler'], '-p', str(build / 'packages/cli/tsconfig.json')]
            if role == 'regression':
                run(command + ['--noEmit'], 'typecheck-regression', 30, {}, build)
            run(command, 'build-' + role, 60, {}, build)
            dist = build / 'packages/cli/dist'
            compiled = tree_identity(dist, '*.js')
            identities['compiled'] = compiled
            write_json(out / ('identities-' + role + '.json'), identities)
            if role != 'regression':
                require(compiled['aggregate_sha256'] == manifest['expected_compiled_aggregate'][role], 'compiled-identity', role)
            else:
                previous = state['identities']['candidate']['compiled']['files']
                changed = {name for name in set(previous) | set(compiled['files']) if previous.get(name) != compiled['files'].get(name)}
                require(changed == {manifest['allowed_compiled_delta']}, 'regression-output-isolation', sorted(changed))
            builds[role] = dist
        for version, runtime in manifest['runtimes'].items():
            command = [runtime['path'], '--test', '--test-concurrency=1', '--test-reporter=tap',
                       '--test-name-pattern=' + manifest['regression_selection'], str(builds['regression'] / 'sync-worker-schedule.test.js')]
            row, output = run(command, 'regression-' + version, 30, {}, repo, defer_validation=True)
            parse_regression(row, output)
        workload = repo / manifest['workload']
        for role in ['parent', 'candidate']:
            command = [manifest['runtimes']['24.19.0']['path'], str(workload), str(builds[role]),
                       str(scratch / ('fixture-routed-' + role)), '0', 'inbound', '65000']
            row, output = run(command, 'routed-' + role, 240, {'ISSUE95_ROUTED_READ_DIAGNOSTIC': '1'}, repo,
                              stdout_name='routed-' + role + '.jsonl', defer_validation=True, setup_seconds=90)
            parse_routed(row, output, role, builds[role])
        state['diagnostic_complete'] = True
    except BaseException as error:
        if state['first_unexpected'] is None:
            remember('controller', repr(error))
    finally:
        if interrupted and state['first_unexpected'] is None:
            remember('interrupt', interrupted)
        try:
            joined = join_owned('final')
        except BaseException as error:
            joined = False
            remember('cleanup', f'Final cleanup failed {error!r}')
        state['remaining_owned'] = matching_live()
        state['scratch_removed'] = False
        if joined and time.monotonic() < state['final_deadline']:
            try:
                shutil.rmtree(scratch)
                state['scratch_removed'] = not scratch.exists()
            except BaseException as error:
                remember('fixture-cleanup', f'Final fixture removal failed {error!r}')
        state['finished_monotonic'] = time.monotonic()
        state['within_final_deadline'] = time.monotonic() <= state['final_deadline']
        state['unrun_commands'] = [name for name in manifest['commands'] if name not in {row['label'] for row in state['commands']}]
        state['qualification'] = False
        state['resource_gain_eligible'] = False
        write_json(out / 'receipt.json', serializable_state())
    raise SystemExit(1 if state['first_unexpected'] or not state['scratch_removed'] or not state['within_final_deadline'] else 0)


if __name__ == '__main__':
    main()
