import ctypes, hashlib, importlib.util, json, math, os, shutil, signal, stat, subprocess, time
from pathlib import Path

# Versioned adaptation of the executed parent-envelope sequence. Execution/ownership remain in the unchanged engine.
STARTED = time.monotonic()
APPLICATION_DEADLINE = STARTED + 1200
FIXED_FINAL_DEADLINE = STARTED + 1320
CLEANUP_DEADLINE = FIXED_FINAL_DEADLINE
OUT = Path(__file__).resolve().parent
MANIFEST_SHA256 = '39a8cdf3f4615237ef3b2a4ccb7155ca921e57be30440144029e0d3e04b07498'
manifest_bytes = (OUT / 'manifest.json').read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == MANIFEST_SHA256
manifest = json.loads(manifest_bytes)
assert str(OUT) == manifest['output'] and not OUT.is_symlink()
assert OUT.stat().st_uid == os.getuid() and stat.S_IMODE(OUT.stat().st_mode) == 0o700
assert manifest['application_seconds'] == 1200 and manifest['cleanup_seconds'] == 120 and manifest['final_seconds'] == 1320

# A separately issued exact-byte grant is required; preparation alone never authorizes a launch.
grant = json.loads(Path(manifest['grant_file']).read_text())
assert grant['state'] == 'APPROVED_FOR_ONE_OWNER_LAUNCH'
assert grant['grant_id'] == manifest['proposed_grant_id']
assert grant['expected_head'] == manifest['expected_head']
assert grant['manifest_sha256'] == MANIFEST_SHA256
assert grant['adapter_sha256'] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert grant['engine_sha256'] == manifest['engine_sha256']
assert grant['application_seconds'] == 1200 and grant['cleanup_seconds'] == 120
command_umask = next(line.split()[1] for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('Umask:'))
assert command_umask == manifest['command_umask'] == grant['command_umask'] == '0002'
assert hashlib.sha256((OUT / 'reused-execution.py').read_bytes()).hexdigest() == manifest['engine_sha256']
spec = importlib.util.spec_from_file_location('reused_execution', OUT / 'reused-execution.py')
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
REPO = Path(manifest['repo'])
BASELINE = Path(manifest['baseline_repo'])
SRC = REPO / manifest['readonly_source_root']
assert manifest['owned_roots'] == ['packages/cli/dist', 'packages/cli/bundle']
assert grant['final_seconds'] == manifest['final_seconds'] == 1320
scratch = OUT / 'owned-command-roots'
scratch.mkdir(mode=0o700)
metadata_home = OUT / 'metadata-home'
metadata_home.mkdir(mode=0o700)
engine.state.update(out=OUT, scratch=scratch, started_monotonic=STARTED, started_wall_ns=time.time_ns(),
    application_deadline=APPLICATION_DEADLINE, final_deadline=FIXED_FINAL_DEADLINE,
    grant_id=manifest['proposed_grant_id'], controller_identity=engine.identity(os.getpid()), command_umask=command_umask, manifest=manifest,
    node24_bin=manifest['node24_bin'], first_unexpected=None, issues=[], commands=[], cleanup=[], adopted_exits=[],
    signals=[], identities={}, steps=[], results={}, completed_invocations=[])
cache_modes = {}
candidate_saved = False
mutation_started = False
current_role = 'candidate'
tool_expected = dict(manifest['tools_sha256'])
cache_seals = {}


def remaining(cleanup=False, step_deadline=None, cap=None):
    deadline = min(FIXED_FINAL_DEADLINE, CLEANUP_DEADLINE) if cleanup else APPLICATION_DEADLINE
    if step_deadline is not None:
        deadline = min(deadline, step_deadline)
    seconds = deadline - time.monotonic()
    if seconds <= 0:
        raise TimeoutError('Fixed cleanup/restoration deadline exhausted' if cleanup else 'Application/step deadline exhausted')
    return min(seconds, cap) if cap is not None else seconds


def read_regular(file, cleanup=False, step_deadline=None):
    remaining(cleanup, step_deadline)
    before = file.lstat()
    assert stat.S_ISREG(before.st_mode), str(file)
    descriptor = os.open(file, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(descriptor)
        assert (opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino)
        chunks = []
        while True:
            remaining(cleanup, step_deadline)
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
        after = os.fstat(descriptor)
        assert (opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) == (after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    finally:
        os.close(descriptor)
    remaining(cleanup, step_deadline)
    return b"".join(chunks)


def owned_inventory(root=REPO, roots=None, cleanup=False, step_deadline=None):
    result = {}
    def visit(relative):
        remaining(cleanup, step_deadline)
        file = root / relative
        try:
            info = file.lstat()
        except FileNotFoundError:
            return
        kind = "file" if stat.S_ISREG(info.st_mode) else "directory" if stat.S_ISDIR(info.st_mode) else "unsupported"
        entry = dict(kind=kind, mode=stat.S_IMODE(info.st_mode), uid=info.st_uid, gid=info.st_gid,
            device=info.st_dev, inode=info.st_ino, links=info.st_nlink, size=info.st_size,
            mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns)
        entry["supported"] = kind != "unsupported" and info.st_uid == os.getuid() and (kind != "file" or info.st_nlink == 1)
        if kind == "file" and entry["supported"]:
            entry["sha256"] = digest(file, cleanup, step_deadline)
        result[relative] = entry
        if kind == "directory" and entry["supported"]:
            for child in sorted(file.iterdir()):
                visit(str(child.relative_to(root)))
    for folder in roots or manifest["owned_roots"]:
        if root == REPO:
            ensure_directory((root / folder).parent, cleanup, step_deadline)
        visit(folder)
    remaining(cleanup, step_deadline)
    return result


def ensure_directory(target, cleanup=False, step_deadline=None, create=False):
    boundary = REPO if target.is_relative_to(REPO) else OUT
    assert target.is_relative_to(boundary) and target != boundary.parent
    current = boundary
    boundary_info = current.lstat()
    assert stat.S_ISDIR(boundary_info.st_mode) and boundary_info.st_uid == os.getuid()
    for component in target.relative_to(boundary).parts:
        remaining(cleanup, step_deadline)
        current = current / component
        try:
            info = current.lstat()
        except FileNotFoundError:
            assert create and (current.is_relative_to(OUT) or any(current.is_relative_to(REPO / folder) for folder in manifest["owned_roots"])), "Outside-prefix parent retained"
            current.mkdir(mode=0o700)
            info = current.lstat()
        assert stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid(), str(current)
    remaining(cleanup, step_deadline)


def write_copy(source, target, mode, cleanup=False, step_deadline=None, expected_target=None, expected_source_sha256=None):
    remaining(cleanup, step_deadline)
    data = read_regular(source, cleanup, step_deadline)
    if expected_source_sha256 is not None:
        assert hashlib.sha256(data).hexdigest() == expected_source_sha256, "Saved/captured source bytes changed"
    assert target.is_relative_to(OUT) or any(target.is_relative_to(REPO / folder) for folder in manifest["owned_roots"])
    ensure_directory(target.parent, cleanup, step_deadline, create=True)
    try:
        current = target.lstat()
    except FileNotFoundError:
        current = None
    assert current is None or stat.S_ISREG(current.st_mode) and current.st_uid == os.getuid() and current.st_nlink == 1
    if current is not None:
        observed = owned_inventory(target.parent, [target.name], cleanup, step_deadline).get(target.name)
        assert observed == expected_target, "Entry changed since preserved snapshot: " + str(target)
    else:
        assert expected_target is None
    flags = os.O_WRONLY | os.O_NOFOLLOW | (os.O_CREAT | os.O_EXCL if current is None else 0)
    descriptor = os.open(target, flags, 0o600)
    try:
        opened = os.fstat(descriptor)
        assert current is None or (opened.st_dev, opened.st_ino) == (current.st_dev, current.st_ino)
        assert current is None or (opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) == (current.st_size, current.st_mtime_ns, current.st_ctime_ns)
        assert stat.S_ISREG(opened.st_mode) and opened.st_uid == os.getuid() and opened.st_nlink == 1
        os.ftruncate(descriptor, 0)
        view = memoryview(data)
        while view:
            remaining(cleanup, step_deadline)
            written = os.write(descriptor, view[:1024 * 1024])
            assert written > 0
            view = view[written:]
        os.fchmod(descriptor, mode)
    finally:
        os.close(descriptor)
    assert digest(target, cleanup, step_deadline) == hashlib.sha256(data).hexdigest()
    remaining(cleanup, step_deadline)


def snapshot(label, roots, cleanup=False, step_deadline=None):
    entries = owned_inventory(roots=roots, cleanup=cleanup, step_deadline=step_deadline)
    destination = OUT / label
    assert not destination.exists()
    destination.mkdir(parents=True, mode=0o700)
    engine.write_json(destination / "owned_inventory.json", entries)
    for name, item in entries.items():
        if item["kind"] == "file" and item["supported"]:
            assert digest(REPO / name, cleanup, step_deadline) == item["sha256"]
            write_copy(REPO / name, destination / name, 0o400 | (item["mode"] & 0o111), cleanup, step_deadline, expected_source_sha256=item["sha256"])
    assert owned_inventory(roots=roots, cleanup=cleanup, step_deadline=step_deadline) == entries, "Snapshot entry changed during capture"
    engine.state.setdefault("snapshots", {})[label] = entries
    remaining(cleanup, step_deadline)
    return entries


def note(kind, detail):
    # Keep the engine's first-failure record; adapter persistence occurs only at step_deadline-checked boundaries.
    issue = dict(kind=kind, detail=str(detail), monotonic=time.monotonic())
    engine.state["issues"].append(issue)
    if engine.state["first_unexpected"] is None:
        engine.state["first_unexpected"] = issue


def digest(file, cleanup=False, step_deadline=None):
    remaining(cleanup, step_deadline)
    assert file.is_file() and not file.is_symlink(), str(file)
    value = hashlib.sha256()
    with file.open('rb') as stream:
        while True:
            remaining(cleanup, step_deadline)
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            value.update(chunk)
    remaining(cleanup, step_deadline)
    return value.hexdigest()


def git(*args, cleanup=False, step_deadline=None, root=None):
    assert list(args) in manifest['metadata_git_argv']
    checkout = REPO if root is None else root
    assert checkout in [REPO, BASELINE]
    output = subprocess.check_output(['/usr/bin/git', *args], cwd=checkout,
        env=manifest['metadata_environment'], timeout=remaining(cleanup, step_deadline, 15))
    remaining(cleanup, step_deadline)
    return output.decode().rstrip('\n')


def file_map(root, cleanup=False, step_deadline=None):
    entries = owned_inventory(root, ['.'], cleanup, step_deadline)
    assert all(item['supported'] for item in entries.values()), 'Unsupported entry retained'
    return {name: item['sha256'] for name, item in entries.items() if item['kind'] == 'file'}


def entry_signature(entries):
    return {name: {key: item[key] for key in ['kind', 'mode', 'uid', 'gid']} for name, item in entries.items()}


def tracked(cleanup=False, step_deadline=None):
    names = git('ls-files', '-z', cleanup=cleanup, step_deadline=step_deadline).split('\0')
    return {name: digest(REPO / name, cleanup, step_deadline) if (REPO / name).exists() else None for name in names if name}


def output_hashes(root=REPO, cleanup=False, step_deadline=None):
    return {str(Path(folder) / name): value for folder in ['packages/cli/dist', 'packages/cli/bundle']
        for name, value in file_map(root / folder, cleanup, step_deadline).items()}


def save(cleanup=False, step_deadline=None):
    remaining(cleanup, step_deadline)
    engine.write_json(OUT / 'receipt.json', engine.serializable_state())
    remaining(cleanup, step_deadline)


def semantic_index(cleanup=False, step_deadline=None):
    actual = {}
    for entry in filter(None, git('ls-files', '--stage', '-z', cleanup=cleanup, step_deadline=step_deadline).split('\0')):
        fields, name = entry.split('\t', 1)
        mode, oid, stage = fields.split()
        assert stage == '0'
        actual[name] = {'mode': mode, 'object': oid}
    assert actual == manifest['expected_index_entries']
    assert git('rev-parse', 'HEAD^{tree}', cleanup=cleanup, step_deadline=step_deadline) == manifest['expected_index_tree']


def check_tools(cleanup=False, step_deadline=None):
    for file, expected in {**tool_expected, **manifest['runtime_sha256'], **manifest['provenance_files_sha256']}.items():
        assert digest(Path(file), cleanup, step_deadline) == expected, file
    tree = owned_inventory(Path(manifest['ncc']['root']), ['.'], cleanup, step_deadline)
    assert tree == manifest['ncc']['frozen_entry_inventory'], 'Strict NCC code/data/metadata changed; no cache window exists'
    for packages in manifest['external_packages'].values():
        for name, package in packages.items():
            logical = Path(package['logical_path']) if 'logical_path' in package else Path(packages['parse5']['real_path']).parent / 'entities'
            assert str(logical.resolve()) == package['real_path'], 'Scoped external package path changed'
            expected = {name: item['sha256'] for name, item in package['full_file_map'].items()}
            directory = Path(package['real_path'])
            assert owned_inventory(directory, ['.'], cleanup, step_deadline) == package['readonly_entry_inventory'], 'Read-only package entries changed'
            for name, value in expected.items():
                assert digest(directory / name, cleanup, step_deadline) == value, 'Read-only package file hash changed'
            assert owned_inventory(directory, ['.'], cleanup, step_deadline) == package['readonly_entry_inventory'], 'Read-only package changed during hashing'
    remaining(cleanup, step_deadline)


def check_baseline_origin(cleanup=False, step_deadline=None):
    assert git('rev-parse', 'HEAD', cleanup=cleanup, step_deadline=step_deadline, root=BASELINE) == manifest['original_baseline']
    assert git('status', '--porcelain', cleanup=cleanup, step_deadline=step_deadline, root=BASELINE) == ''
    names = git('ls-files', '-z', cleanup=cleanup, step_deadline=step_deadline, root=BASELINE).split('\0')
    actual = {name: digest(BASELINE / name, cleanup, step_deadline) if (BASELINE / name).exists() else None for name in names if name}
    source = owned_inventory(BASELINE, [manifest['readonly_source_root']], cleanup, step_deadline)
    generated = owned_inventory(BASELINE, manifest['owned_roots'], cleanup, step_deadline)
    engine.state['baseline_input_last'] = {'tracked_sha256': actual, 'source_inventory': source, 'generated_inventory': generated}
    assert actual == manifest['baseline']['tracked_sha256'], 'Read-only baseline tracked source changed'
    assert source == manifest['baseline']['source_entry_inventory'], 'Read-only baseline source entries changed'
    assert generated == manifest['baseline']['generated_entry_inventory'], 'Read-only baseline compiled bytes/entries changed'
    remaining(cleanup, step_deadline)


def verify_role(role, label, cleanup=False, step_deadline=None):
    remaining(cleanup, step_deadline)
    entries = owned_inventory(cleanup=cleanup, step_deadline=step_deadline)
    source_entries = owned_inventory(roots=[manifest['readonly_source_root']], cleanup=cleanup, step_deadline=step_deadline)
    actual_source = tracked(cleanup, step_deadline)
    actual_outputs = output_hashes(cleanup=cleanup, step_deadline=step_deadline)
    expected = manifest['roles'][role]
    proof = {'role': role, 'checkout_source_head': manifest['expected_head'], 'compiled_origin_source_pin': expected['compiled_origin_source_pin'],
        'tracked_sha256': actual_source, 'source_entry_inventory': source_entries, 'generated_sha256': actual_outputs, 'generated_entries': entries}
    engine.write_json(OUT / ('maps-' + label + '.json'), proof)
    assert all(item['supported'] for item in entries.values()), 'Unsupported compiled entry retained'
    assert entry_signature(entries) == expected['generated_entry_signature'], 'Complete per-role compiled entry set/type/mode drift'
    assert actual_outputs == expected['generated_sha256'], 'Compiled role drift: ' + role
    assert actual_source == manifest['checkout_tracked_sha256'], 'Read-only current checkout source drift'
    assert source_entries == manifest['source_entry_inventory'], 'Read-only source complete entry/metadata drift'
    semantic_index(cleanup, step_deadline)
    assert git('status', '--porcelain', cleanup=cleanup, step_deadline=step_deadline) == ''
    check_tools(cleanup, step_deadline)
    check_baseline_origin(cleanup, step_deadline)
    engine.state['verified_compiled_role'] = role
    remaining(cleanup, step_deadline)


def copy_tree(source, target, modes=None, cleanup=False, step_deadline=None, role=None):
    entries = owned_inventory(source, ['.'], cleanup, step_deadline)
    assert not target.exists() and not target.is_symlink()
    assert entries and all(item['supported'] for item in entries.values())
    for name, item in entries.items():
        destination = target / name
        if item['kind'] == 'directory':
            ensure_directory(destination, cleanup, step_deadline, create=True)
            mode = manifest['roles'][role]['generated_entry_signature'][str(destination.relative_to(REPO))]['mode'] if destination.is_relative_to(REPO) else 0o700
            destination.chmod(mode)
        else:
            mode = modes[name] if modes is not None else item['mode']
            write_copy(source / name, destination, mode, cleanup, step_deadline, expected_source_sha256=item['sha256'])
    assert owned_inventory(source, ['.'], cleanup, step_deadline) == entries, 'Copy source changed'
    remaining(cleanup, step_deadline)


def backup_role(role, deadline):
    expected = manifest['roles'][role]
    source_root = REPO if role == 'candidate' else BASELINE
    entries = owned_inventory(source_root, manifest['owned_roots'], step_deadline=deadline)
    assert all(item['supported'] for item in entries.values())
    assert entry_signature(entries) == expected['generated_entry_signature']
    assert output_hashes(source_root, step_deadline=deadline) == expected['generated_sha256']
    cache = OUT / 'roles' / role
    assert not cache.exists()
    cache_modes[role] = {}
    for folder in manifest['owned_roots']:
        source = source_root / folder
        modes = {str(p.relative_to(source)): stat.S_IMODE(p.stat().st_mode) for p in source.rglob('*') if p.is_file()}
        cache_modes[role][folder] = modes
        copy_tree(source, cache / folder, step_deadline=deadline)
    assert output_hashes(cache, step_deadline=deadline) == expected['generated_sha256']
    assert owned_inventory(source_root, manifest['owned_roots'], step_deadline=deadline) == entries, 'Original role input changed during backup'
    for file in cache.rglob('*'):
        remaining(step_deadline=deadline)
        if file.is_file():
            file.chmod(0o400 | (file.stat().st_mode & 0o111))
    cache_seals[role] = owned_inventory(cache, manifest['owned_roots'], step_deadline=deadline)
    engine.state['backup_modes'] = cache_modes
    engine.state.setdefault('verified_backups', {})[role] = str(cache)
    save(step_deadline=deadline)


def switch_role(role, label, cleanup=False, step_deadline=None):
    assert remaining(cleanup, step_deadline) >= 8, 'Insufficient remaining time to admit a joined switch'
    assert engine.join_owned('before-' + label) and not engine.matching_live()
    remaining(cleanup, step_deadline)
    cache = OUT / 'roles' / role
    expected = manifest['roles'][role]
    assert owned_inventory(cache, manifest['owned_roots'], cleanup, step_deadline) == cache_seals[role], 'Immutable role backup changed'
    assert output_hashes(cache, cleanup, step_deadline) == expected['generated_sha256']
    for folder in manifest['owned_roots']:
        try:
            target = REPO / folder
            actual = owned_inventory(roots=[folder], cleanup=cleanup, step_deadline=step_deadline)
            expected_entries = {name: item for name, item in expected['generated_entry_signature'].items() if name == folder or name.startswith(folder + '/')}
            actual_hashes = {name: item.get('sha256') for name, item in actual.items() if item['kind'] != 'directory'}
            wanted = {str(Path(folder) / name): value for name, value in file_map(cache / folder, cleanup, step_deadline).items()}
            if entry_signature(actual) == expected_entries and actual_hashes == wanted and all(item['supported'] for item in actual.values()):
                continue

            # Full entry preservation covers ignored/untracked files, metadata and unsupported objects BEFORE any removal.
            evidence = snapshot('replacements/' + label + '/' + folder, [folder], cleanup, step_deadline)
            assert evidence == actual, 'Owned entries changed while preserving replacement evidence'
            assert all(item['supported'] for item in evidence.values()), 'Unsupported entries retained; restoration incomplete'
            assert owned_inventory(roots=[folder], cleanup=cleanup, step_deadline=step_deadline) == actual
            remaining(cleanup, step_deadline)
            engine.state['mutation_started'] = True
            if target.exists():
                assert target.is_dir() and not target.is_symlink()
                shutil.rmtree(target)
            remaining(cleanup, step_deadline)
            copy_tree(cache / folder, target, cache_modes[role][folder], cleanup, step_deadline, role=role)
        except BaseException as error:
            if not cleanup:
                raise
            note('owned-prefix-restoration', folder + ': ' + repr(error))
    verify_role(role, label, cleanup, step_deadline)


def preserve_unexpected(cleanup=True):
    source = owned_inventory(roots=[manifest['readonly_source_root']], cleanup=cleanup)
    if source != manifest['source_entry_inventory']:
        snapshot('unexpected-readonly-source', [manifest['readonly_source_root']], cleanup=cleanup)
        engine.state['unexpected_source_preserved'] = str(OUT / 'unexpected-readonly-source')
        note('read-only-source-drift', 'Source evidence retained; no source restoration write is authorized')
    for ordinal, (name, expected) in enumerate(manifest['checkout_tracked_sha256'].items()):
        if name.startswith(manifest['readonly_source_root'] + '/'):
            continue
        try:
            item = owned_inventory(roots=[name], cleanup=cleanup).get(name)
            if item and item['supported'] and item['kind'] == 'file' and item['sha256'] == expected:
                continue
            snapshot('unexpected-readonly-tracked/' + str(ordinal), [name], cleanup=cleanup)
            note('read-only-tracked-drift', name + ': retained outside mutable output prefixes')
        except BaseException as error:
            note('read-only-preservation-limit', name + ': ' + repr(error))
    status = git('status', '--porcelain', cleanup=cleanup)
    if status:
        engine.state['unexpected_checkout_status'] = status
        note('checkout-status-drift', 'Checkout status retained; no source deletion or repair')
    entries = owned_inventory(cleanup=cleanup)
    hashes = {name: item.get('sha256') for name, item in entries.items() if item['kind'] != 'directory'}
    known = any(hashes == value['generated_sha256'] and entry_signature(entries) == value['generated_entry_signature']
        for value in manifest['roles'].values())
    if known and all(item['supported'] for item in entries.values()):
        return
    snapshot('unexpected-compiled-before-final-restoration', manifest['owned_roots'], cleanup=cleanup)
    engine.state['unexpected_outputs_preserved'] = str(OUT / 'unexpected-compiled-before-final-restoration')
    note('unexpected-compiled-drift', 'All supported bytes/metadata preserved; unsupported objects retained')


def validate_run(run, deadline):
    remaining(step_deadline=deadline)
    directory = Path(run['output'])
    metadata = json.loads((directory / 'environment.json').read_text())
    summary = json.loads((directory / 'summary.json').read_text())
    cleanup = json.loads((directory / 'cleanup.json').read_text())
    assert summary['success'] and 'performance_eligible' not in summary and 'diagnostics' not in metadata
    assert cleanup == {'fixture_root_removed': True, 'children_reaped': True}
    assert metadata['commit'] == manifest['expected_head'] and metadata['dirty'] == ''
    assert metadata['node'] == 'v' + run['runtime'] and metadata['counts'] == run['counts']
    assert metadata['sizes'] == [10240] and metadata['samples'] == 1 and metadata['limits'] == {'timeout_seconds': 360, 'concurrency': 1}
    assert metadata['fingerprints'] == manifest['roles'][run['role']]['fingerprints']
    raw = (directory / 'samples.jsonl').read_bytes()
    outer = [json.loads(line) for line in raw.decode().splitlines()]
    assert [row['label'] for row in outer] == run['expected_outer_labels'] and len(outer) == run['expected_outer_rows']
    nested = []
    for count, row in zip(run['counts'], outer):
        remaining(step_deadline=deadline)
        assert row['exit_code'] == 0 and 'performance_eligible' not in row
        assert len(row['command']) == 7 and row['command'][:3] == [run['node'], str(REPO / manifest['workload']), 'sync']
        assert row['command'][-3:] == [str(count), '10240', '1']
        assert 'issue97-sync-trace-v1' not in row['stderr']
        operations = [json.loads(line) for line in row['stdout'].splitlines()]
        for operation in operations:
            assert 'diagnostic' not in operation and 'performanceEligible' not in operation
            assert all(isinstance(operation[name], (float, int)) and not isinstance(operation[name], bool) and math.isfinite(operation[name])
                for name in ['wall_ms', 'cpu_ms', 'rss_bytes'])
        nested.extend(operations)
    assert [row['label'] for row in nested] == run['expected_nested_labels'] and len(nested) == run['expected_nested_rows']
    peer = {row['label']: row for row in nested if row['label'].startswith('peer/')}
    for count in run['counts']:
        for phase, transfers in [('initial', count), ('noop', 0)] + ([('repair', 1)] if count else []):
            row = peer[f'peer/{phase}/{count}']
            assert row['transferred'] == transfers
            for role in ['source', 'receiver']:
                assert type(row[role]['commits']) is int and row[role]['commits'] >= 0
                assert type(row[role]['ledgerReplacementBytes']) is int and row[role]['ledgerReplacementBytes'] >= 0
                if phase == 'noop':
                    assert all(row[role][name] == 0 for name in ['htmlOpens', 'htmlBytesRead', 'hashPasses', 'bodyTransfers'])
            if phase == 'repair':
                assert row['receiver']['bodyTransfers'] == 1 and row['receiver']['hashPasses'] == 1
    result = {'runtime': run['runtime'], 'role': run['role'], 'pair': run['pair'], 'case': run['case'],
        'samples_sha256': hashlib.sha256(raw).hexdigest(), 'metadata': metadata, 'operations': nested, 'peer': peer,
        'checkout_source_head': manifest['expected_head'], 'executed_compiled_origin': manifest['roles'][run['role']]['compiled_origin_source_pin']}
    engine.state['results'][run['label']] = result
    other = engine.state['results'].get(run['counterpart'])
    if other:
        for label, row in peer.items():
            counterpart = other['peer'][label]
            assert row['transferred'] == counterpart['transferred']
            result.setdefault('counterpart_vectors', {})[label] = {'wire_equal': row['wire'] == counterpart['wire'],
                'body_vectors_equal': all(row[role][name] == counterpart[role][name] for role in ['source', 'receiver']
                    for name in ['htmlOpens', 'htmlBytesRead', 'hashPasses', 'bodyTransfers'])}
            assert all(result['counterpart_vectors'][label].values()), 'Counterpart wire/body vector mismatch'
    remaining(step_deadline=deadline)


def interrupt(signum, _frame):
    engine.interrupted = 'Received signal ' + str(signum)
    engine.state['signals'].append({'signal': signum, 'monotonic': time.monotonic()})


try:
    assert ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0
    signal.signal(signal.SIGTERM, interrupt)
    signal.signal(signal.SIGINT, interrupt)
    preflight_deadline = min(APPLICATION_DEADLINE, time.monotonic() + manifest['preflight_cap_seconds'])
    assert git('rev-parse', 'HEAD', step_deadline=preflight_deadline) == manifest['expected_head']
    assert git('rev-parse', manifest['source_pin'] + '^', step_deadline=preflight_deadline) == manifest['base']
    for reference in manifest['roles'].values():
        receipt = reference['source_origin_receipt']
        assert digest(Path(receipt['path']), step_deadline=preflight_deadline) == receipt['sha256']
    index = Path(git('rev-parse', '--git-path', 'index', step_deadline=preflight_deadline))
    shutil.copyfile(index, OUT / 'raw-index-before.bin')
    verify_role('candidate', 'initial-candidate', step_deadline=preflight_deadline)
    for run in manifest['schedule']:
        assert not Path(run['output']).exists()
    engine.state['source_before'] = tracked(step_deadline=preflight_deadline)
    engine.state['qualified_candidate_outputs'] = manifest['roles']['candidate']['generated_sha256']
    save(step_deadline=preflight_deadline)
    runs = {run['label']: run for run in manifest['schedule']}
    for step in manifest['steps']:
        remaining()
        if engine.interrupted:
            raise InterruptedError(engine.interrupted)
        label = step['label']
        started = time.monotonic()
        proof = {'label': label, 'kind': step['kind'], 'started_monotonic': started}
        engine.state['steps'].append(proof)
        if step['kind'] == 'backup-candidate':
            backup_role('candidate', min(APPLICATION_DEADLINE, started + step['cap_seconds']))
            candidate_saved = True
        elif step['kind'] == 'backup-parent610':
            assert candidate_saved
            deadline = min(APPLICATION_DEADLINE, started + step['cap_seconds'])
            check_baseline_origin(step_deadline=deadline)
            backup_role('parent610', deadline)
        elif step['kind'] == 'switch-role':
            assert candidate_saved
            deadline = min(APPLICATION_DEADLINE, started + step['cap_seconds'])
            verify_role(current_role, 'before-' + label, step_deadline=deadline)
            switch_role(step['role'], label, step_deadline=deadline)
            current_role = step['role']
        else:
            command = manifest['commands'][label]
            assert step['kind'] in ['measurement', 'command']
            if step['kind'] == 'measurement':
                assert current_role == step['role']
            verify_role(current_role, 'before-' + label, step_deadline=min(APPLICATION_DEADLINE, time.monotonic() + 15))
            print('START ' + label, flush=True)
            row, output = engine.run(command['command'], label, command['bound_seconds'], command['environment'], REPO)
            print('END ' + label + ' exit=' + str(row['exit']), flush=True)
            audit_deadline = min(APPLICATION_DEADLINE, time.monotonic() + 15)
            if label.endswith('-version'):
                expected = 'v20.20.2' if label == 'node20-version' else 'v24.19.0'
                assert output.read_text().strip() == expected
            else:
                validate_run(runs[label], audit_deadline)
                engine.state['completed_invocations'].append(label)
            verify_role(current_role, 'after-' + label, step_deadline=audit_deadline)
        remaining()
        proof['finished_monotonic'] = time.monotonic()
        save()
    assert len(engine.state['completed_invocations']) == 4
    engine.state['completed'] = True
except BaseException as error:
    if engine.state['first_unexpected'] is None:
        note('sequence', repr(error))
finally:
    cleanup_started = time.monotonic()
    CLEANUP_DEADLINE = min(CLEANUP_DEADLINE, FIXED_FINAL_DEADLINE, cleanup_started + 120)
    engine.state['final_deadline'] = CLEANUP_DEADLINE
    engine.state['cleanup_restoration_deadline'] = CLEANUP_DEADLINE
    joined = False
    try:
        joined = engine.join_owned('final-before-restoration')
    except BaseException as error:
        note('cleanup-join', repr(error))
    if joined:
        try:
            assert not engine.matching_live()
            preserve_unexpected()
        except BaseException as error:
            note('cleanup-preservation', repr(error))
        try:
            assert not engine.matching_live()
            if candidate_saved:
                switch_role('candidate', 'final-candidate-restoration', cleanup=True)
            else:
                verify_role('candidate', 'final-candidate-invariant', cleanup=True)
        except BaseException as error:
            note('cleanup-restoration', repr(error))
    else:
        note('cleanup-restoration-not-admitted', 'Owned processes not joined; outputs/source retained')
    try:
        engine.state['outputs_after'] = output_hashes(cleanup=True)
        engine.state['qualified393_restored'] = engine.state['outputs_after'] == manifest['roles']['candidate']['generated_sha256']
        assert engine.state['qualified393_restored']
    except BaseException as error:
        note('compiled-output-final-audit', repr(error))
    try:
        engine.state['source_after'] = tracked(cleanup=True)
        source = owned_inventory(roots=[manifest['readonly_source_root']], cleanup=True)
        engine.state['source_unchanged'] = engine.state['source_after'] == manifest['checkout_tracked_sha256'] and source == manifest['source_entry_inventory']
        assert engine.state['source_unchanged'] and git('status', '--porcelain', cleanup=True) == ''
        semantic_index(cleanup=True)
        engine.state['semantic_index_unchanged'] = True
    except BaseException as error:
        note('read-only-source-index-final-audit', repr(error))
    try:
        check_tools(cleanup=True)
        check_baseline_origin(cleanup=True)
        engine.state['strict_tools_and_baseline_unchanged'] = True
    except BaseException as error:
        note('strict-input-final-audit', repr(error))
    try:
        index = Path(git('rev-parse', '--git-path', 'index', cleanup=True))
        remaining(cleanup=True)
        shutil.copyfile(index, OUT / 'raw-index-after.bin')
        engine.state['raw_index_snapshot_sha256'] = {name: digest(OUT / name, cleanup=True)
            for name in ['raw-index-before.bin', 'raw-index-after.bin'] if (OUT / name).exists()}
    except BaseException as error:
        note('raw-index-observation', repr(error))
    engine.state['remaining_owned'] = engine.matching_live()
    engine.state['unrun_commands'] = [name for name in manifest['commands'] if name not in {row['label'] for row in engine.state['commands']}]
    engine.state['incomplete_invocations'] = [run['label'] for run in manifest['schedule'] if run['label'] not in engine.state['completed_invocations']]
    engine.state['retained_command_roots'] = sorted(p.name for p in scratch.iterdir())
    try:
        if joined and not engine.state['retained_command_roots']:
            remaining(cleanup=True)
            scratch.rmdir()
    except BaseException as error:
        note('command-root-cleanup', repr(error))
    engine.state['command_roots_removed'] = not scratch.exists()
    engine.state['finished_monotonic'] = time.monotonic()
    engine.state['within_cleanup_allowance'] = time.monotonic() <= CLEANUP_DEADLINE
    engine.state['within_fixed_final_deadline'] = time.monotonic() <= FIXED_FINAL_DEADLINE
    engine.state['raw_index_byte_identity_or_cause_claim'] = False
    try:
        remaining(cleanup=True)
        engine.write_json(OUT / 'receipt.json', engine.serializable_state())
        engine.state['after_receipt_write_monotonic'] = time.monotonic()
        remaining(cleanup=True)
    except BaseException as error:
        engine.state['within_cleanup_allowance'] = False
        engine.state['within_fixed_final_deadline'] = time.monotonic() <= FIXED_FINAL_DEADLINE
        engine.state['final_receipt_or_deadline_incomplete'] = True
        note('cleanup-deadline-or-receipt', repr(error))
    print(json.dumps({key: engine.state.get(key) for key in ['completed', 'first_unexpected', 'completed_invocations', 'incomplete_invocations',
        'source_unchanged', 'semantic_index_unchanged', 'qualified393_restored', 'strict_tools_and_baseline_unchanged', 'command_roots_removed',
        'remaining_owned', 'within_cleanup_allowance', 'within_fixed_final_deadline', 'final_receipt_or_deadline_incomplete']}), flush=True)
raise SystemExit(1 if engine.state['first_unexpected'] or not engine.state['within_fixed_final_deadline'] or not engine.state['within_cleanup_allowance'] else 0)
