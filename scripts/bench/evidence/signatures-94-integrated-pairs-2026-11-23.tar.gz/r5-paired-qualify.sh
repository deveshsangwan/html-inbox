#!/usr/bin/env bash
# Grant pr119-2ba6ffb-paired-qualification-20261123: one exclusive local run, 2700 s inclusive.
set -uo pipefail

W=/home/agent/.t3/worktrees/html-inbox/perf-94-sigcache
R=$W/artifacts/94/r5-paired-2ba6ffb-20261123
CANDIDATE=2ba6ffb52c282c1eed7cd6cd497f6e68dd715ec0
PARENT=08d5b2b056515ad876ac8aec2a164eea82050fa0
N20=/home/agent/.local/share/fnm/node-versions/v20.20.2/installation/bin
N24=/home/agent/.local/share/fnm/node-versions/v24.19.0/installation/bin
TSC=$W/node_modules/tsc-rs/bin/tsc-rs
NCC=$W/artifacts/94/ncc-private-preparation-r2/ncc
NCC_NODE_PATH=$W/node_modules/.pnpm/@vercel+ncc@0.44.1/node_modules/@vercel/ncc/node_modules:$W/node_modules/.pnpm/@vercel+ncc@0.44.1/node_modules:$W/node_modules/.pnpm/node_modules
CHECK=/tmp/claude-1001/-home-agent--t3-worktrees-html-inbox-perf-94-sigcache/c9202830-f329-480f-ae91-423c5b44ff56/scratchpad/check-intended-operations.py
START=$(date +%s)

mkdir "$R" || exit 2
cd "$W" || exit 2

elapsed() { echo $(( $(date +%s) - START )); }
log() { echo "$(elapsed)s $*" | tee -a "$R/steps.log"; }
record() { local name=$1 code=$2; echo "{\"step\":\"$name\",\"exit_code\":$code,\"elapsed_s\":$(elapsed)}" >> "$R/steps.jsonl"; log "$name exit $code"; }
tree_hashes() { (cd "$1" && find . -type f -print0 | sort -z | xargs -0 sha256sum); }

restore_generated() {
  log "restore generated roots"
  rm -rf packages/cli/dist packages/cli/bundle
  cp -a "$R/generated-before/dist" packages/cli/dist
  cp -a "$R/generated-before/bundle" packages/cli/bundle
  tree_hashes packages/cli/dist > "$R/generated-restored-dist.sha256"
  tree_hashes packages/cli/bundle > "$R/generated-restored-bundle.sha256"
  cmp -s "$R/generated-before-dist.sha256" "$R/generated-restored-dist.sha256" && cmp -s "$R/generated-before-bundle.sha256" "$R/generated-restored-bundle.sha256"
  record restore-generated $?
}

# 0. Exact pins.
test "$(git rev-parse HEAD)" = "$CANDIDATE" || { log "HEAD mismatch"; exit 90; }
test -z "$(git status --porcelain)" || { log "dirty tree"; exit 91; }
test "$(git rev-parse origin/perf/89-bench)" = "$PARENT" || { log "parent pin mismatch"; exit 92; }
git diff --quiet "$PARENT" "$CANDIDATE" -- pnpm-lock.yaml package.json packages/cli/package.json packages/cli/tsconfig.json tsconfig.base.json
record matched-build-inputs $?
log "pins confirmed candidate=$CANDIDATE parent=$PARENT"

# 1. Back up generated roots and private ncc state.
mkdir -p "$R/generated-before"
cp -a packages/cli/dist "$R/generated-before/dist"
cp -a packages/cli/bundle "$R/generated-before/bundle"
tree_hashes "$R/generated-before/dist" > "$R/generated-before-dist.sha256"
tree_hashes "$R/generated-before/bundle" > "$R/generated-before-bundle.sha256"
tree_hashes "$NCC" > "$R/private-ncc-before.sha256"
trap restore_generated EXIT

# 2. Runtimes.
"$N20/node" --version > "$R/node20-version.log" 2>&1; record node20-version $?
"$N24/node" --version > "$R/node24-version.log" 2>&1; record node24-version $?

# 3. Candidate typecheck, fresh build and private-cache bundle.
(cd packages/cli && PATH="$N24:$PATH" "$N24/node" "$TSC" -p tsconfig.json --noEmit) > "$R/typecheck.log" 2>&1; record typecheck $?
rm -rf packages/cli/dist
(cd packages/cli && PATH="$N24:$PATH" "$N24/node" "$TSC" -p tsconfig.json) > "$R/candidate-build.log" 2>&1
BUILD=$?; record candidate-build $BUILD
mkdir -p "$R/bundle-cache" "$R/bundle-tmp"
(cd packages/cli && env PATH="$N24:$PATH" NODE_PATH="$NCC_NODE_PATH" XDG_CACHE_HOME="$R/bundle-cache" TMPDIR="$R/bundle-tmp" TMP="$R/bundle-tmp" TEMP="$R/bundle-tmp" \
  "$N24/node" "$NCC/dist/ncc/cli.js" build dist/index.js -o bundle) > "$R/candidate-bundle.log" 2>&1
BUNDLE=$?; record candidate-bundle $BUNDLE
tree_hashes "$NCC" > "$R/private-ncc-after.sha256"
mkdir -p "$R/builds/candidate" "$R/builds/parent"
cp -a packages/cli/dist "$R/builds/candidate/dist"

# 4. Parent fresh build from git archive, same tools and dependency tree, no install.
mkdir -p "$R/parent-src"
git archive "$PARENT" | tar -x -C "$R/parent-src"
ln -s "$W/node_modules" "$R/parent-src/node_modules"
ln -s "$W/packages/cli/node_modules" "$R/parent-src/packages/cli/node_modules"
(cd "$R/parent-src/packages/cli" && PATH="$N24:$PATH" "$N24/node" "$TSC" -p tsconfig.json) > "$R/parent-build.log" 2>&1
PARENT_BUILD=$?; record parent-build $PARENT_BUILD
cp -a "$R/parent-src/packages/cli/dist" "$R/builds/parent/dist"
rm -rf "$R/parent-src"
for label in candidate parent; do
  tree_hashes "$R/builds/$label/dist" > "$R/builds/$label-dist.sha256"
done
python3 - "$R" > "$R/builds/dist-graph-sha256.json" <<'EOF'
import hashlib, json, sys
from pathlib import Path
root = Path(sys.argv[1]) / 'builds'
result = {}
for label in ['candidate', 'parent']:
    digest = hashlib.sha256()
    dist = root / label / 'dist'
    for artifact in sorted(dist.rglob('*.js')):
        digest.update(str(artifact.relative_to(dist)).encode() + b'\0')
        digest.update(artifact.read_bytes())
    result[label] = digest.hexdigest()
print(json.dumps(result, indent=2))
EOF

if [ "$BUILD" -ne 0 ] || [ "$BUNDLE" -ne 0 ] || [ "$PARENT_BUILD" -ne 0 ]; then
  log "build failure; skipping tests and measurement"
  exit 3
fi

# 5. Focused correctness sets, TAP on both runtimes.
FOCUSED="packages/cli/dist/sync-signatures.test.js packages/cli/dist/sync-signature-integrity.test.js packages/cli/dist/sync-maintenance.test.js packages/cli/dist/sync-acquisition-deadline.test.js packages/cli/dist/sync-protocol.test.js packages/cli/dist/sync-worker-runtime.test.js"
READER="packages/cli/dist/sync-reader-compatibility.test.js packages/cli/dist/sync-ledger-read-race.test.js packages/cli/dist/hub-http.test.js packages/cli/dist/viewer-document-deletion.test.js"
for runtime in 20.20.2 24.19.0; do
  bin=$N20; [ "$runtime" = 24.19.0 ] && bin=$N24
  # shellcheck disable=SC2086
  PATH="$bin:$PATH" timeout 300 "$bin/node" --test --test-reporter=tap $FOCUSED > "$R/focused-$runtime.tap" 2>&1; record "focused-$runtime" $?
  # shellcheck disable=SC2086
  PATH="$bin:$PATH" timeout 300 "$bin/node" --test --test-reporter=tap $READER > "$R/reader-http-$runtime.tap" 2>&1; record "reader-http-$runtime" $?
done

# 6. Bench harness tests.
PATH="$N24:$PATH" timeout 300 python3 -m unittest discover -s scripts/bench -p 'test_*.py' > "$R/bench-tests.log" 2>&1; record bench-tests $?

# 7. One paired cell, 30 single-sample processes.
log "pairs start"
PATH="$N24:$PATH" timeout 1500 python3 scripts/bench/signature_pairs.py --parent-dist "$R/builds/parent/dist" --parent-ref "$PARENT" \
  --candidate-dist "$R/builds/candidate/dist" --candidate-ref "$CANDIDATE" --node "$N20/node" --node "$N24/node" \
  --cells 100:10240 --variants parent,keys,candidate --pairs 5 --out "$R/pairs" > "$R/pairs.log" 2>&1
record signature-pairs $?

# 8. Intended operations per raw block.
cp "$CHECK" "$R/check-intended-operations.py"
python3 -I "$R/check-intended-operations.py" "$R/pairs" 100 5 parent,keys,candidate v20.20.2 v24.19.0 > "$R/intended-operations.log" 2>&1
record intended-operations $?

log "measurement complete"
