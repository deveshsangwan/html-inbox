"""Receipt check: compare every planned block's raw labels and counts with the intended `signatures` operations.

Usage: python3 -I check-intended-operations.py <pairs-out-dir> <count> <pairs> <variants> <runtime>...
Exits nonzero unless every planned block has exactly the intended per-process operation counts.
"""
import json
import sys
from collections import Counter
from pathlib import Path


def intended(count):
    churn_rounds = -(-18_000 // count) if count >= 1000 else 3
    operations = {'snapshot-cold': 1, 'snapshot-warm': 5, 'list': 1, 'worker-startup': 1, 'worker-noop-validated-custody': 1,
                  'worker-idle': 1, 'worker-close': 1, 'churn-miss': churn_rounds, 'churn-repeat': churn_rounds, 'adversarial': 1}
    if count:
        operations['get'] = 1
    return Counter({f'signatures/{name}/{count}': times for name, times in operations.items()})


def main():
    out, count, pairs, variants, runtimes = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), sys.argv[4].split(','), sys.argv[5:]
    expected = intended(count)
    report = []
    for runtime in runtimes:
        for pair in range(pairs):
            for variant in variants:
                block = out / f'{runtime}-{count}-10240-pair{pair}-{variant}'
                observed = Counter()
                samples = block / 'samples.jsonl'
                if samples.exists():
                    for raw in samples.read_text().splitlines():
                        for line in json.loads(raw)['stdout'].splitlines():
                            observed[json.loads(line)['label']] += 1

                missing = {label: expected[label] - observed[label] for label in expected if observed[label] < expected[label]}
                unexpected = {label: observed[label] - expected[label] for label in observed if observed[label] > expected[label]}
                report.append(dict(block=block.name, present=samples.exists(), operations=sum(observed.values()),
                                   expected_operations=sum(expected.values()), missing=missing, unexpected=unexpected,
                                   complete=samples.exists() and not missing and not unexpected))

    (out / 'intended-operations-check.json').write_text(json.dumps(dict(expected=expected, blocks=report), indent=2) + '\n')
    incomplete = [row for row in report if not row['complete']]
    print(f'{len(report) - len(incomplete)}/{len(report)} blocks match the intended {sum(expected.values())} operations')
    for row in incomplete:
        print('INCOMPLETE', json.dumps(row))
    sys.exit(1 if incomplete else 0)


if __name__ == '__main__':
    main()
